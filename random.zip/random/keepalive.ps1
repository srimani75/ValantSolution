while ($true){
$obj = new-object -com wscript.shell
$obj.SendKeys([char]174)
$obj.SendKeys([char]175)
Start-Sleep -Seconds 180
}