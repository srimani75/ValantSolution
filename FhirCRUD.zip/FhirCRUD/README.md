# FhirCRUD
All FHIR related operations
