using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.Azure.EventHubs;

namespace FhirSave
{
    public class SoapNoteHPI
    {
        public static string EndpointURI = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBEndpoint");
        public static string databaseId = Utils.ReliantUtlity.GetEnvironmentVariable("RisksDatabase");
        public static string containerId = Utils.ReliantUtlity.GetEnvironmentVariable("HPIContainer");
        public static string PrimaryKey = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBKey");
        public static string Eventhubendpoint = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubEndpoint");
        public static string EventhubKey = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubKey");
        public static string env = Utils.ReliantUtlity.GetEnvironmentVariable("AGG_ID");

        //public static string Eventhubendpoint = "lp-cl-eastus-eventhub-07c73293.servicebus.windows.net/";
        //public static string EventhubKey = "+1tKqvZhKF5l2maA3+WoFmqJ2Bmt3JPtD4BEvrA0EIM=";

        //public static string databaseId = "cosmosdb-nonprod-sqldb";
        //public static string containerId = "HPIFactors";

        //public static string EndpointURI = "https://cosmosdb-stage.documents.azure.com:443/";
        //public static string PrimaryKey = "FOmkoMYKYjDieKcJB795BCvW57EfbQcfB2JDgIDs5vx8lOj2DMFCDEVVG7EqvD6A29I7YCER1DnULLE5CDHdLw==";
        //public static string env = "FHIRService-HPI";

        public static List<HPIObject> lsthpiobject = new List<HPIObject>();
        public static List<string> lstsymptoms = new List<string>();
        [FunctionName("SoapNoteHPI")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            HPIContent hpioutput = new HPIContent();

            var connectionStringBuilder = new EventHubsConnectionStringBuilder("Endpoint=sb://" + Eventhubendpoint + ";SharedAccessKeyName=lp-cl-auth-rule;SharedAccessKey=" + EventhubKey)
            {
                EntityPath = "application-logs"
            };

            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            try
            {                
                var content = new StreamReader(req.Body).ReadToEndAsync();
                if(content.Result.Contains('{'))
                {
                    var res = "{\"InfermedicaDiagnose\":" + content.Result + "}";
                    SoapNoteHPIBOdy reqdata = JsonConvert.DeserializeObject<SoapNoteHPIBOdy>(res);
                    List<string> AllIds = new List<string>();
                    string codes = "";
                    foreach (var record in reqdata.InfermedicaDiagnose)
                    {
                        AllIds.AddRange(record.id);
                    }
                    foreach (var id in AllIds)
                    {
                        codes = codes + "'" + id + "',";
                    }
                    codes = codes.TrimEnd(',');
                    await CosmosCall(codes, log, reqdata.InfermedicaDiagnose,eventHubClient);
                    if(lsthpiobject.Count>0)
                    {
                        hpioutput.HPIObject = lsthpiobject;
                        List<HPIObject> lsthpiobjectresult = new List<HPIObject>();
                        foreach (var symptom in lstsymptoms)
                        {
                            if (symptom != null)
                            {
                                HPIObject obj = new HPIObject();
                                if (lsthpiobjectresult.Count == 0)
                                {
                                    obj.Symptom = symptom;
                                    List<string> positives = new List<string>();
                                    List<string> negatives = new List<string>();
                                    foreach (var hpival in lsthpiobject)
                                    {
                                        if (hpival.Symptom == symptom)
                                        {
                                            if (hpival.Positive != null)
                                                positives.AddRange(hpival.Positive);
                                            if (hpival.Negative != null)
                                                negatives.AddRange(hpival.Negative);
                                        }
                                    }
                                    obj.Positive = positives;
                                    obj.Negative = negatives;
                                }
                                else
                                {
                                    bool symptomexists = false;
                                    foreach (var hobject in lsthpiobjectresult)
                                    {
                                        if (hobject.Symptom == symptom)
                                            symptomexists = true;
                                    }
                                    if (!symptomexists)
                                    {
                                        obj.Symptom = symptom;
                                        List<string> positives = new List<string>();
                                        List<string> negatives = new List<string>();
                                        foreach (var hpival in lsthpiobject)
                                        {
                                            if (hpival.Symptom == symptom)
                                            {
                                                if (hpival.Positive != null)
                                                    positives.AddRange(hpival.Positive);
                                                if (hpival.Negative != null)
                                                    negatives.AddRange(hpival.Negative);
                                            }
                                        }
                                        obj.Positive = positives;
                                        obj.Negative = negatives;
                                    }

                                }
                                if (obj.Symptom != null)
                                    lsthpiobjectresult.Add(obj);
                            }

                        }
                        hpioutput.HPIObject = lsthpiobjectresult;
                    }
                    else
                    {
                        var errorResonse = new Models.ErrorResponse();
                        //replace with actual id
                        errorResonse.error = Guid.NewGuid().ToString();
                        errorResonse.message = "HPI List from cosmos is empty";
                        errorResonse.detail = "Cosmos DB Calls is failing for HPI list";
                        var evehubresponse = new Models.EventHubErrorResponse();
                        var eventhubdata = new Models.Data();
                        eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                        evehubresponse.data = eventhubdata;
                        evehubresponse.agg = env+" SOAP Note HPI Service";
                        evehubresponse.type = "Error";
                        await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                        var result = new OkObjectResult(errorResonse);
                        result.StatusCode = StatusCodes.Status500InternalServerError;
                        return result;
                    }
                    
                }

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env+" SOAP Note HPI Service";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
            return new OkObjectResult(hpioutput);
        }

        public static async Task<List<HPIObject>> CosmosCall(string codes, ILogger log, List<InfermedicaDiagnose> Data, EventHubClient eventHubClient)
        {
            lsthpiobject.Clear();
            lstsymptoms.Clear();
            try
            {
                Stopwatch DBtimer = Stopwatch.StartNew();
                codes = codes.TrimEnd(',');
                //log.LogInformation("All codes: " + codes);
                var strQuery = "SELECT c.id,c.name,c.common_name,c.parent_name,c.parent_common_name FROM c IN t.InfermedicaDiagnosis WHERE c.id IN(" + codes + ") and (c.seriousness='Normal' or c.seriousness='Serious' or c.seriousness='Emergency care')";
                string key = PrimaryKey;
                var response = Utils.DBUtility.GetItemFromContainer(EndpointURI, key, strQuery, databaseId, containerId);

                if (response != null)
                {
                    var arrhpis = Utils.Extention.ConvertObjectToJson(response).TrimStart('[').TrimEnd(']').Split("},");
                    var arrdisthpis = arrhpis.Distinct().ToArray();
                    foreach (var diagData in Data)
                    {
                        HPIObject hobj = new HPIObject();
                        string id = "";
                        foreach (var ids in diagData.id)
                        {
                            id = ids + ",";
                        }
                        if (diagData.type == "single")
                        {
                            List<string> posneg = new List<string>();
                            foreach (var hpi in arrdisthpis)
                            {
                                var hpi1 = hpi.TrimEnd('}');
                                hpi1 = hpi1 + "}";
                                var hpiobj = JsonConvert.DeserializeObject<CosmosHPIData>(hpi1);

                                var lstIds = id.Split(",");
                                if (((lstIds.Where(i => i == hpiobj.id)).Count()) > 0)
                                {
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name != "")
                                        hobj.Symptom = hpiobj.parent_name;
                                    if (hpiobj.parent_common_name != "")
                                        hobj.Symptom = hpiobj.parent_common_name;
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name == "" && hpiobj.common_name != "")
                                        hobj.Symptom = hpiobj.common_name;
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name == "" && hpiobj.common_name == "")
                                        hobj.Symptom = hpiobj.name;

                                    lstsymptoms.Add(hobj.Symptom);
                                    if (diagData.evidence == "present")
                                    {
                                        posneg.Add(hpiobj.name);
                                        hobj.Positive = posneg;
                                        break;
                                    }
                                    else
                                    {
                                        posneg.Add(hpiobj.name);
                                        hobj.Negative = posneg;
                                        break;
                                    }

                                }
                            }
                        }

                        if (diagData.type == "group_single" && diagData.answer != "I don't know")
                        {
                            List<string> posneg = new List<string>();
                            foreach (var hpi in arrdisthpis)
                            {
                                var hpi1 = hpi.TrimEnd('}');
                                hpi1 = hpi1 + "}";
                                var hpiobj = JsonConvert.DeserializeObject<CosmosHPIData>(hpi1);

                                var lstIds = id.Split(",");
                                if (((lstIds.Where(i => i == hpiobj.id)).Count()) > 0)
                                {
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name != "")
                                        hobj.Symptom = hpiobj.parent_name;
                                    if (hpiobj.parent_common_name != "")
                                        hobj.Symptom = hpiobj.parent_common_name;
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name == "" && hpiobj.common_name != "")
                                        hobj.Symptom = hpiobj.common_name;
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name == "" && hpiobj.common_name == "")
                                        hobj.Symptom = hpiobj.name;

                                    lstsymptoms.Add(hobj.Symptom);
                                    if (diagData.evidence == "absent")
                                    {
                                        if (diagData.answer == "Yes" || diagData.answer == "No")
                                        {
                                            if (hpiobj.parent_common_name == "")
                                                posneg.Add(hpiobj.common_name);
                                            else
                                                posneg.Add(hpiobj.parent_common_name);

                                            hobj.Negative = posneg;
                                            break;
                                        }
                                        else
                                        {
                                            if (diagData.answer == "None of the above" && diagData.answer != "No answer")
                                            {
                                                posneg.Add(hpiobj.name);
                                                hobj.Negative = posneg;
                                                break;
                                            }
                                            else
                                            {
                                                if (diagData.answer != "No answer")
                                                {
                                                    posneg.Add(diagData.answer);
                                                    hobj.Negative = posneg;
                                                    break;
                                                }

                                            }
                                        }

                                    }
                                    else
                                    {
                                        if (diagData.answer == "Yes" || diagData.answer == "No")
                                        {
                                            if (hpiobj.parent_common_name == "")
                                                posneg.Add(hpiobj.common_name);
                                            else
                                                posneg.Add(hpiobj.parent_common_name);

                                            hobj.Positive = posneg;
                                            break;
                                        }
                                        else
                                        {
                                            if (diagData.answer == "None of the above")
                                            {
                                                posneg.Add(hpiobj.name);
                                                hobj.Positive = posneg;
                                                break;
                                            }
                                            else
                                            {
                                                posneg.Add(diagData.answer);
                                                hobj.Positive = posneg;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (diagData.type == "group_multiple")
                        {
                            List<string> posneg = new List<string>();
                            foreach (var hpi in arrdisthpis)
                            {
                                var hpi1 = hpi.TrimEnd('}');
                                hpi1 = hpi1 + "}";
                                    var hpiobj = JsonConvert.DeserializeObject<CosmosHPIData>(hpi1);                                

                                var lstIds = id.Split(",");
                                if (((lstIds.Where(i => i == hpiobj.id)).Count()) > 0)
                                {
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name != "")
                                        hobj.Symptom = hpiobj.parent_name;
                                    if (hpiobj.parent_common_name != "")
                                        hobj.Symptom = hpiobj.parent_common_name;
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name == "" && hpiobj.common_name != "")
                                        hobj.Symptom = hpiobj.common_name;
                                    if (hpiobj.parent_common_name == "" && hpiobj.parent_name == "" && hpiobj.common_name == "")
                                        hobj.Symptom = hpiobj.name;

                                    lstsymptoms.Add(hobj.Symptom);

                                    if (diagData.evidence == "absent")
                                    {
                                        posneg.Add(diagData.answer);
                                        hobj.Negative = posneg;
                                    }
                                    if (diagData.evidence == "present")
                                    {
                                        posneg.Add(diagData.answer);
                                        hobj.Positive = posneg;
                                    }
                                    if (diagData.evidence == "Unknown")
                                    {
                                        posneg.Add(diagData.answer);
                                        hobj.Negative = posneg;
                                    }
                                }
                            }
                        }
                        lsthpiobject.Add(hobj);
                    }
                }

                DBtimer.Stop();
                log.LogInformation("Database call Timer: " + DBtimer.Elapsed.TotalSeconds);
                Console.WriteLine("Database call Timer: " + DBtimer.Elapsed);
               
            }

            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env+" SOAP Note HPI Service";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
            }
            return lsthpiobject;
            //await System.Threading.Tasks.Task.Delay(500);
        }   
    }
    public class CosmosHPIData
    {
        public string id { get; set; }
        public string name { get; set; }
        public string common_name { get; set; }
        public string parent_name { get; set; }
        public string parent_common_name { get; set; }
    }

    public class HPIObject
    {
        public string Symptom { get; set; }
        public List<string> Positive { get; set; }
        public List<string> Negative { get; set; }
    }

    public class HPIContent
    {
        public List<HPIObject> HPIObject { get; set; }
    }

    public class InfermedicaDiagnose
    {
        public List<string> id { get; set; }
        public string question { get; set; }
        public string answer { get; set; }
        public string type { get; set; }
        public string evidence { get; set; }
    }

    public class SoapNoteHPIBOdy
    {
        public List<InfermedicaDiagnose> InfermedicaDiagnose { get; set; }
    }


}
