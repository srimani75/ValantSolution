//using System;
//using System.IO;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Azure.WebJobs;
//using Microsoft.Azure.WebJobs.Extensions.Http;
//using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Logging;
//using Hl7.Fhir.ElementModel;
//using Hl7.Fhir.Model;
//using Hl7.Fhir.Rest;
//using Hl7.Fhir.Serialization;
//using Hl7.Fhir.Validation;
//using Hl7.FhirPath;
//using System.Collections.Generic;
//using RestSharp;
//using Newtonsoft.Json;
//using Newtonsoft.Json.Linq;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Primitives;
//using System.Linq;
//using System.Runtime.InteropServices;
//using Hl7.Fhir.Utility;
//using System.Collections;
//using System.Globalization;

//namespace FhirSave
//{
//    public class SaveClinicalSummary
//    {
//        private readonly IConfiguration configuration;
//        public SaveClinicalSummary(IConfiguration config)
//        {
//            this.configuration = config;
//        }
//        [FunctionName("SaveClinicalSummary")]
//        public async Task<IActionResult> Run(
//            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req, ILogger log)
//        {
//            string responseMessage = string.Empty;
//            BadRequestResult badresult = new BadRequestResult();
//            try
//            {
//                var content = new StreamReader(req.Body).ReadToEndAsync();

//                Body reqdata = JsonConvert.DeserializeObject<Body>(content.Result);
//                var summarycontent = JsonConvert.DeserializeObject<Summary>(reqdata.summary);
//                //JObject data = JObject.Parse(requestBody);
//                var patientId= reqdata.patientId;
//                var patinfo = Utils.Utility.GetPatientData("12345", patientId).Result;
//                //var resource = Utils.Utility.GetEnvironmentVariable("resource");
//                var resource = "https://optum-fhirserver.azurehealthcareapis.com";
//                var bearerToken = FhirToken.GetBearerToken(log);
//                var messageHandler = new HttpClientEventHandler();
//                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
//                {
//                    e.RawRequest.Headers
//                    .Add("Authorization", $"Bearer {bearerToken}");
//                };

//                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
//                {
//                    PreferredFormat = ResourceFormat.Json
//                });
//                Patient fhirPatientId = CreatePatient(patinfo.getpatientinfo.FirstOrDefault(), client);

//                 //string requestBody = new StreamReader(req.Body).ReadToEndAsync(); 
//                 JObject data = JObject.Parse(content.Result);
//                var clinicalSummary = JObject.Parse(data["summary"].Value<string>());
//                //var clinicalSummary = reqdata.summary.Replace("\"", "");
//                //JObject Summary = JObject.Parse(clinicalSummary);
//                SavePatientClinicalSummary(fhirPatientId, summarycontent, client, resource);
//                responseMessage = fhirPatientId.Id;

//            }
//            catch (Exception ex)
//            {
//                var errorResonse = new Models.ErrorResponse();
//                //replace with actual id
//                errorResonse.error = Guid.NewGuid().ToString();
//                errorResonse.message = ex.Message;
//                errorResonse.detail = ex;

//                var result = new OkObjectResult(errorResonse);
//                result.StatusCode = StatusCodes.Status500InternalServerError;
//                return result;
//            }
            
//            return new OkObjectResult(responseMessage);

//        }

//        private Patient CreatePatient(Models.PatientModel.Getpatientinfo PatientDemoData, FhirClient client)
//        {
            
//            var pat = new Patient();
//            pat.Id = PatientDemoData.enterprisemrn;
//           // pat.Identifier.Add(new Identifier("allscriptsId", PatientDemoData.ID));
//            pat.Identifier.Add(new Identifier("mrn", PatientDemoData.enterprisemrn));
//            switch (PatientDemoData.BirthSex)
//            {
//                case "Female":
//                    pat.Gender = AdministrativeGender.Female;
//                    break;
//                case "Male":
//                    pat.Gender = AdministrativeGender.Male;
//                    break;
//                case "Other":
//                    pat.Gender = AdministrativeGender.Other;
//                    break;
//                default:
//                    pat.Gender = AdministrativeGender.Unknown;                   
//                    break;
//            }
//            HumanName phyname = new HumanName();
//            List<HumanName> lsthumannames = new List<HumanName>();
//            phyname.Text = PatientDemoData.PhysFirstName +" "+ PatientDemoData.PhysLastName;
//            phyname.Family = PatientDemoData.PhysLastName;
//            List<FhirString> lstphygivenname = new List<FhirString>();
//            FhirString phygn = new FhirString();
//            phygn.SetStringExtension("https://www.hl7.org/fhir/datatypes.html#HumanName", PatientDemoData.PhysFirstName);
//            lstphygivenname.Add(phygn);
//            phyname.GivenElement = lstphygivenname;

//            lsthumannames.Add(phyname);
//            HumanName name = new HumanName();
//            name.Text = PatientDemoData.Firstname + " " + PatientDemoData.middlename + " " + PatientDemoData.LastName;
//            name.Family = PatientDemoData.LastName;
//            List<FhirString> lstgivenname = new List<FhirString>();
//            FhirString gn = new FhirString();
//            gn.SetStringExtension("https://www.hl7.org/fhir/datatypes.html#HumanName", PatientDemoData.Firstname);
//            lstgivenname.Add(gn);
//            name.GivenElement = lstgivenname;

            
//            lsthumannames.Add(phyname);
//            lsthumannames.Add(name);
//            pat.Name = lsthumannames;                      
            
//            pat.BirthDate = DateTime.Parse(PatientDemoData.dateofbirth).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture); 

//            CodeableConcept cdmaritalstatus = new CodeableConcept();
//            cdmaritalstatus.Text = PatientDemoData.MaritalStatus;
//            pat.MaritalStatus = cdmaritalstatus;

//            Address pataddress = new Address();
//            pataddress.Text = PatientDemoData.Addressline1 + ";" + PatientDemoData.AddressLine2 + ";";
//            pataddress.PostalCode = PatientDemoData.ZipCode;
//            List<Address> lstpataddr = new List<Address>();
//            lstpataddr.Add(pataddress);
//            pat.Address = lstpataddr;

//            List<Patient.CommunicationComponent> lstpatcomm = new List<Patient.CommunicationComponent>();
//            Patient.CommunicationComponent patcomm = new Patient.CommunicationComponent();
//            CodeableConcept cdlanuage = new CodeableConcept();
//            cdlanuage.Text = PatientDemoData.PreferredPronoun;
//            patcomm.Language = cdlanuage;
//            lstpatcomm.Add(patcomm);
//            pat.Communication = lstpatcomm;
            

//            List<ContactPoint> lstcontact = new List<ContactPoint>();
//            ContactPoint patMcontact = new ContactPoint();
//            patMcontact.Value = PatientDemoData.PhoneNumber;
//            patMcontact.Use = ContactPoint.ContactPointUse.Mobile;
//            ContactPoint patHcontact = new ContactPoint();
//            patHcontact.Value = PatientDemoData.HomePhone;
//            patHcontact.Use = ContactPoint.ContactPointUse.Home;

//            lstcontact.Add(patMcontact);
//            lstcontact.Add(patHcontact);
//            pat.Telecom = lstcontact;

//            var created_pat = client.Create(pat);

//            return created_pat;
//        }
//        private void SavePatientClinicalSummary(Patient fhirPatientId, Summary clinicalSummary, FhirClient client,string resource)
//        {
            
//                List<Problemdetail> lstProblems = clinicalSummary.Problemdetail;
//                List<Vitalsdetail> lstVitals = clinicalSummary.Vitalsdetail;
//                List<SurgicalHistorydetail> lstsurgical = clinicalSummary.SurgicalHistorydetail;
//                List<SocialHistorydetail> lstSocial = clinicalSummary.SocialHistorydetail;
//                List<Allergiesdetail> lstAllergies = clinicalSummary.Allergiesdetail;
//                List<FamilyHistorydetail> lstFamilies = clinicalSummary.FamilyHistorydetail;
//                List<HackMedication> lstMedications = clinicalSummary.Medicationhistory;
//                SaveVitals(fhirPatientId, lstVitals, client, resource);
//                SaveMedication(fhirPatientId, lstMedications, client, resource);
//                SaveProblems(fhirPatientId, lstProblems, client, resource);
//                SaveSurgicalHistory(fhirPatientId, lstsurgical, client, resource);
//                SaveSociallHistory(fhirPatientId, lstSocial, client, resource);
//                SaveFamilyHistory(fhirPatientId, lstFamilies, client, resource);
//                SaveAllergyDetails(fhirPatientId, lstAllergies, client, resource);
            
           

//        }

//        private void SaveVitals(Patient fhirPatientId, List<Vitalsdetail> Vitals, FhirClient client, string resource)
//        {
//            try
//            {
                
//                //var vitals = (JArray)clinicalSummary["Vitalsdetail"];
//                Bundle vitalsBundle = new Bundle();
//                vitalsBundle.Type = Bundle.BundleType.Collection;
//                //if (vitals != null)
//                //{
//                    foreach (var item in Vitals)
//                    {                        

//                        var entryCode = item.entrycode;
//                        var code = item.code;
//                        var status = item.status;
//                        var displayDate = item.displaydate;
//                        var displaydateTime = Convert.ToDateTime(displayDate);
//                        var formatteddate = displaydateTime.ToString("YYYY-MM-DD");
//                        var description = item.description;
//                        var detail = item.detail;
//                        string[] details = detail.Split(' ');
//                        var IcdCode = item.ICDCode;

//                            var vital = new Observation();
//                            vital.Subject = new ResourceReference(string.Format(resource + "/Patient/", fhirPatientId.Id));
//                            vital.Status = ObservationStatus.Final;

//                            vital.Meta = new Meta { Profile = new List<string> { "http://hl7.org/fhir/StructureDefinition/daf-vitalsigns" } };

//                            var ccCat = new CodeableConcept();
//                            ccCat.Coding.Add(new Coding { Code = entryCode, Display = "Vital Signs", System = "http://hl7.org/fhir/observation-category" });
//                            ccCat.Text = "Vitals Signs";
//                            vital.Category.Add(ccCat);

//                            var ccCode = new CodeableConcept();
//                            ccCode.Coding.Add(new Coding { Code = "ICDCodes", Display = description, System = "http://loinc.org" });

//                        if (IcdCode!=null)
//                        {
//                            var IcdCodes = (JArray)IcdCode;
//                            foreach (var icd in IcdCodes.Children())
//                            {
//                                var prop = icd.Children<JProperty>();
//                                var icd9 = prop.FirstOrDefault(x => x.Name == "icd9").Value.ToString();
//                                ccCode.Coding.Add(new Coding { Code = icd9, Display = "IcdCode9", System = "http://hl7.org/fhir/sid/icd-9-us" });
//                                var icd10 = prop.FirstOrDefault(x => x.Name == "icd10").Value.ToString();
//                                ccCode.Coding.Add(new Coding { Code = icd10, Display = "icd10", System = "http://hl7.org/fhir/sid/icd-10-us" });

//                            }
//                        }
//                        ccCode.Text = "weight:"+"170 lbs";
//                        vital.Code = ccCode;
//                        vital.Id = code;
//                        vital.Performer = new List<Hl7.Fhir.Model.ResourceReference> { new ResourceReference { Display = status } };
//                        vital.Value = new Quantity { Value = Convert.ToDecimal(details[0]),Unit = details.Count()>1?details[1] :""};
                        
//                        vital.Effective = new FhirDateTime(displaydateTime);
//                        var obs=client.Create(vital);
//                        vitalsBundle.AddResourceEntry(vital, "Observation/" + obs.Id);
//                    }
//                    var bundleId=client.Create(vitalsBundle);
//                fhirPatientId.Identifier.Add(new Identifier("vitalsBundle", bundleId.Id));
//                var updated_pat = client.Update(fhirPatientId);
//                //}
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//        }

//        private void SaveMedication(Patient fhirPatientId, List<HackMedication> Medications, FhirClient client, string resource)
//        {
//            try
//            {
//                Bundle MedicationBundle = new Bundle();
//                MedicationBundle.Type = Bundle.BundleType.Collection;
//                foreach (var item in Medications)
//                {
                   
//                    var Medicationval = new MedicationStatement();
                    
//                    Medicationval.Subject = new ResourceReference(string.Format(resource+"/Patient/"+fhirPatientId.Id));
//                    Identifier iden = new Identifier();
//                    iden.ElementId = item.drugcharacterization;
//                    List<Identifier> lstiden = new List<Identifier>();
//                    lstiden.Add(iden);
//                    Medicationval.Status = MedicationStatement.MedicationStatusCodes.Active;
//                    Medicationval.Identifier = lstiden;

//                    Medication mdpatienttie = new Medication();
//                    mdpatienttie.Id = item.drugcharacterization;
//                    mdpatienttie.Status = Medication.MedicationStatusCodes.Active;
//                    Medication.IngredientComponent ingcomp = new Medication.IngredientComponent();
//                    ingcomp.AddAnnotation(item.generic_name);                    
//                    mdpatienttie.Ingredient.Add(ingcomp);

//                    var medid=client.Create(mdpatienttie);
//                    Medicationval.Medication = new ResourceReference(resource + "/Medication/" + medid.Id);
//                    //Medicationval.med  

//                    // Medicationval.StatusElement = MedicationStatement.MedicationStatusCodes.Active;
                    

//                    Annotation Annmedicationname = new Annotation();
//                    Markdown mrkmedicinename = new Markdown();
//                    mrkmedicinename.Value = item.medicinalproduct;
//                    Annmedicationname.Text = mrkmedicinename;
//                    Annmedicationname.SetStringExtension("https://www.hl7.org/fhir/medication.html", item.generic_name);                    

//                    Medicationval.Note.Add(Annmedicationname);
//                    var medicate=client.Create(Medicationval);
//                    MedicationBundle.AddResourceEntry(Medicationval, "Medications/" + medicate.Id);

//                }
//                var bundleId = client.Create(MedicationBundle);
//                fhirPatientId.Identifier.Add(new Identifier("MedicationsBundle", bundleId.Id));
//                var updated_pat = client.Update(fhirPatientId);
//                //}
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//        }
//        private void SaveProblems(Patient fhirPatientId, List<Problemdetail> Problems, FhirClient client, string resource)
//        {
//            try
//            {
//                Bundle ProblemsBundle = new Bundle();
//                ProblemsBundle.Type = Bundle.BundleType.Collection;
//                //var problems = (JArray)clinicalSummary["Problemdetail"];
//                //if (problems!=null)
//                //{
//                foreach (var item in Problems)
//                    {
//                       // var itemProperties = item.Children<JProperty>();
//                        var detail = item.detail;
//                        var entryCode = item.entrycode;
//                        var code = item.code;
//                        var status = item.status;
//                        var displayDate = item.displaydate;
//                        var displaydateTime = Convert.ToDateTime(displayDate);
//                        var formatteddate = displaydateTime.ToString("yyyy-MM-dd");
//                        var IcdCode = item.ICDCode;

//                        var condition = new Condition();
//                        condition.Subject = new ResourceReference(string.Format(resource+"/Patient/", fhirPatientId.Id));
//                        condition.Meta = new Meta { Profile = new List<string> { "http://hl7.org/fhir/StructureDefinition/daf-condition" } };                        
//                        var ccCat = new CodeableConcept();
//                        ccCat.Coding.Add(new Coding { Code = entryCode, Display = "Problem Details", System = "http://hl7.org/fhir/condition-category" });
//                        ccCat.Text = "Problem Details";
//                        condition.Category.Add(ccCat);

//                        var ccCode = new CodeableConcept();
//                        ccCode.Coding.Add(new Coding { Code = "Details", Display = detail,System= "http://loinc.org" });
//                        ccCode.Coding.Add(new Coding { Code = code });

//                        if (IcdCode!=null)
//                        {
//                           // var IcdCodes = (JArray)(IcdCode);
//                            foreach (var icd in IcdCode)
//                            {
//                                //var prop = icd.Children<JProperty>();
//                                var icd9 = icd.icd9;
//                                ccCode.Coding.Add(new Coding { Code = icd9, Display = "IcdCode9", System = "http://hl7.org/fhir/sid/icd-9-us" });
//                                var icd10 = icd.icd10;
//                                ccCode.Coding.Add(new Coding { Code = icd10, Display = "icd10", System = "http://hl7.org/fhir/sid/icd-10-us" });

//                            }
//                        }

//                        ccCode.Text = detail;
//                        condition.Code = ccCode;

//                        var cStatus = new CodeableConcept();
//                        cStatus.Coding.Add(new Coding { Code = status, System = "http://terminology.hl7.org/CodeSystem/condition-clinical" });
//                        condition.ClinicalStatus = cStatus;

//                        var vStatus = new CodeableConcept();
//                        vStatus.Coding.Add(new Coding { Code = status, System = "http://hl7.org/fhir/ValueSet/condition-ver-status" });
//                        condition.VerificationStatus = vStatus;

//                        condition.RecordedDate = formatteddate;
//                        var con=client.Create(condition);
//                    ProblemsBundle.AddResourceEntry(condition, "condition/" + con.Id);
//                }
//                //client.Create(ProblemsBundle);
//                var bundleId = client.Create(ProblemsBundle);
//                fhirPatientId.Identifier.Add(new Identifier("ProblemsBundle", bundleId.Id));
//                var updated_pat = client.Update(fhirPatientId);
//                //}
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//        }
//        private void SaveSurgicalHistory(Patient fhirPatientId, List<SurgicalHistorydetail> SurgicalHistory, FhirClient client, string resource)
//        {
//            Bundle SurgicalHistoryBundle = new Bundle();
//            SurgicalHistoryBundle.Type = Bundle.BundleType.Collection;
           
//            foreach (var item in SurgicalHistory)
//                {
                   
//                var detail = item.detail;
//                var entryCode = item.entrycode;
//                var status = item.status;
//                var displayDate = item.displaydate;
//                var displaydateTime = Convert.ToDateTime(displayDate);
//                var formatteddate = displaydateTime.ToString("yyyy-MM-dd");
//                var IcdCode = item.ICDCode;

//                var surgicalHistory = new Procedure();
//                    surgicalHistory.Subject = new ResourceReference(string.Format(resource + "/Patient/"+ fhirPatientId.Id));
//                    surgicalHistory.Status = EventStatus.Completed;
                    
//                    var ccCode = new CodeableConcept();
//                    ccCode.Coding.Add(new Coding { Code = entryCode, Display = detail,System = "http://loinc.org" });
//                    if (IcdCode!=null)
//                    {
//                        var IcdCodes = (JArray)(IcdCode);
//                        foreach (var icd in IcdCodes.Children())
//                        {
//                            var prop = icd.Children<JProperty>();
//                            var icd9 = prop.FirstOrDefault(x => x.Name == "icd9").Value.ToString();
//                            ccCode.Coding.Add(new Coding { Code = icd9, Display = "IcdCode9", System = "http://hl7.org/fhir/sid/icd-9-us" });
//                            var icd10 = prop.FirstOrDefault(x => x.Name == "icd10").Value.ToString();
//                            ccCode.Coding.Add(new Coding { Code = icd10, Display = "icd10", System = "http://hl7.org/fhir/sid/icd-10-us" });
//                        }
//                    }
//                    ccCode.Text = status;
//                    surgicalHistory.Code = ccCode;
//                    surgicalHistory.Performed = new FhirString(displayDate);
//                    var proc=client.Create(surgicalHistory);
//                SurgicalHistoryBundle.AddResourceEntry(surgicalHistory, "Procedure/" + proc.Id);
//            }
//            //client.Create(SurgicalHistoryBundle);
//            var bundleId = client.Create(SurgicalHistoryBundle);
//            fhirPatientId.Identifier.Add(new Identifier("SurgicalHistoryBundle", bundleId.Id));
//            var updated_pat = client.Update(fhirPatientId);
//            //}
//        }        
//        private void SaveSociallHistory(Patient fhirPatientId, List<SocialHistorydetail> SocialHistory, FhirClient client, string resource)
//        {
           
//            Bundle SociallHistoryBundle = new Bundle();
//            SociallHistoryBundle.Type = Bundle.BundleType.Collection;
//            foreach (var item in SocialHistory)
//                {
                    
//                var detail = item.detail;
//                var entryCode = item.entrycode;
//                var status =item.status;
//                var displayDate = item.displaydate;
//                var displaydateTime = Convert.ToDateTime(displayDate);
//                var formatteddate = displaydateTime.ToString("yyyy-MM-dd");
//                var IcdCode = item.ICDCode;
//                var socialHistory = new Observation();
//                    socialHistory.Subject = new ResourceReference(string.Format(resource+"/Patient/"+fhirPatientId.Id));

//                    socialHistory.Status = ObservationStatus.Final;
                    
//                    var ccCat = new CodeableConcept();
//                    ccCat.Coding.Add(new Coding { Code = entryCode, Display = "Social History", System = "http://hl7.org/fhir/observation-category" });
//                    ccCat.Text = entryCode;
//                    socialHistory.Category.Add(ccCat);

//                    var ccCode = new CodeableConcept();
//                    ccCode.Coding.Add( new Coding { Code = "Details", Display = detail , System = "http://loinc.org" });

//                    if (IcdCode!=null)
//                    {
//                        //var IcdCodes = (JArray)(IcdCode);
//                        foreach (var icd in IcdCode)
//                        {
//                            //var prop = icd.Children<JProperty>();
//                            var icd9 =icd.icd9;
//                            ccCode.Coding.Add(new Coding { Code = icd9, Display = "IcdCode9", System = "http://hl7.org/fhir/sid/icd-9-us" });
//                            var icd10 = icd.icd10;
//                            ccCode.Coding.Add(new Coding { Code = icd10, Display = "icd10", System = "http://hl7.org/fhir/sid/icd-10-us" });

//                        }
//                    }
//                    ccCode.Text = status;
//                    socialHistory.Code = ccCode;
//                    socialHistory.Effective = new FhirDateTime(displaydateTime);
//                    var socid=client.Create(socialHistory);
//                SociallHistoryBundle.AddResourceEntry(socialHistory, "Observation/"+socid.Id);
//            }
//            var bundleId = client.Create(SociallHistoryBundle);
//            fhirPatientId.Identifier.Add(new Identifier("SociallHistoryBundle", bundleId.Id));
//            var updated_pat = client.Update(fhirPatientId);
//            //}
//        }
//        private void SaveFamilyHistory(Patient fhirPatientId, List<FamilyHistorydetail> FamilyHistory, FhirClient client, string resource)
//        {
//            Bundle FamilyHistoryBundle = new Bundle();
//            FamilyHistoryBundle.Type = Bundle.BundleType.Collection;
//            try { 
               
//                    foreach (var item in FamilyHistory)
//                    {
                    
//                    var detail = item.detail;
//                    var entryCode = item.entrycode;
//                    var status = item.status;
//                    var relations = item.relations;
//                    var displayDate = item.displaydate;
//                    var displaydateTime = Convert.ToDateTime(displayDate);
//                    var formatteddate = displaydateTime.ToString("yyyy-MM-dd");
//                    var IcdCode = item.ICDCode;

//                    var familyHistory = new FamilyMemberHistory();
//                        familyHistory.Patient = new ResourceReference(string.Format(resource+"/Patient/"+ fhirPatientId.Id));
//                        familyHistory.Status = FamilyMemberHistory.FamilyHistoryStatus.Completed;
//                        familyHistory.Name = entryCode;
//                        var condition = new FamilyMemberHistory.ConditionComponent();
//                        var ccCode = new CodeableConcept();
//                        ccCode.Coding.Add(new Coding { Code = "Details", Display = detail, System = "http://loinc.org" });

//                        if (IcdCode!=null)
//                        {
//                            //var IcdCodes = (JArray)(IcdCode);
//                            foreach (var icd in IcdCode)
//                            {
//                            //var prop = icd.Children<JProperty>();
//                            var icd9 = icd.icd9;
//                                ccCode.Coding.Add(new Coding { Code = icd9, Display = "IcdCode9", System = "http://hl7.org/fhir/sid/icd-9-us" });
//                            var icd10 = icd.icd10;
//                                ccCode.Coding.Add(new Coding { Code = icd10, Display = "icd10", System = "http://hl7.org/fhir/sid/icd-10-us" });

//                            }
//                        }

//                        ccCode.Text = detail;
//                        condition.Code = ccCode;
//                        familyHistory.Condition.Add(condition);

//                        var relCode = new CodeableConcept();
//                        if (relations!=null)
//                        {
//                            //var relationList = relations.Split(',');
//                            foreach (string relationItem in relations)
//                            {
//                                relCode.Coding.Add(new Coding { Code = relationItem, Display = relationItem, System = "http://terminology.hl7.org/CodeSystem/v3-RoleCode" });
//                            }
                           
//                        }
//                        else //required
//                        {
//                            relCode.Coding.Add(new Coding { Code = "default", Display = "default", System = "http://terminology.hl7.org/CodeSystem/v3-RoleCode" });
//                        }
//                        familyHistory.Relationship = relCode;
//                        familyHistory.Date = formatteddate;
//                        var famhist=client.Create(familyHistory);
//                    FamilyHistoryBundle.AddResourceEntry(familyHistory, "FamilyMemberHistory/" + famhist.Id);
//                }
//                var bundleId = client.Create(FamilyHistoryBundle);
//                fhirPatientId.Identifier.Add(new Identifier("FamilyHistoryBundle", bundleId.Id));
//                var updated_pat = client.Update(fhirPatientId);

//            }
//            //}
//            catch(Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }
//        }
//        private void SaveAllergyDetails(Patient fhirPatientId, List<Allergiesdetail> Allergies, FhirClient client, string resource)
//        {
            
//            Bundle AllergiesBundle = new Bundle();
//            AllergiesBundle.Type = Bundle.BundleType.Collection;
//            foreach (var item in Allergies)
//                {
                   
//                    var detail = item.detail;
//                    var entryCode = item.entrycode;
//                    var status = item.status;
//                    var description = item.description;
//                    var reactiontype = item.reactiontype;
//                    var reactions = item.reactions;
//                    var IcdCode = item.ICDCode;
//                    AllergyIntolerance allergy = new AllergyIntolerance();
//                    allergy.Patient = new ResourceReference(string.Format(resource+"/Patient/"+fhirPatientId.Id));
//                    allergy.Meta = new Meta { Profile = new List<string> { "http://hl7.org/fhir/StructureDefinition/daf-allergyintolerance" } };                

//                    var cStatus = new CodeableConcept();
//                    cStatus.Coding.Add(new Coding { Code = status, System = "http://terminology.hl7.org/CodeSystem/condition-clinical" });
//                    allergy.ClinicalStatus = cStatus;                    
//                    var ccCode = new CodeableConcept();
//                    ccCode.Coding.Add(new Coding { Code = entryCode, Display = detail , System = "http://loinc.org" });

//                    if (IcdCode!=null)
//                    {
//                        var IcdCodes = (JArray)IcdCode;
//                        foreach (var icd in IcdCodes.Children())
//                        {
//                            var prop = icd.Children<JProperty>();
//                            var icd9 = prop.FirstOrDefault(x => x.Name == "icd9").Value.ToString();
//                            ccCode.Coding.Add(new Coding { Code = icd9, Display = "IcdCode9", System = "http://hl7.org/fhir/sid/icd-9-us" });
//                            var icd10 = prop.FirstOrDefault(x => x.Name == "icd10").Value.ToString();
//                            ccCode.Coding.Add(new Coding { Code = icd10, Display = "icd10", System = "http://hl7.org/fhir/sid/icd-10-us" });

//                        }
//                    }
//                    allergy.Code = ccCode;
//                    var reactionList = new List<AllergyIntolerance.ReactionComponent>();
//                    AllergyIntolerance.ReactionComponent component = new AllergyIntolerance.ReactionComponent();

//                    var menifestationList = new List<CodeableConcept>();                    
                   
//                    //if (!string.IsNullOrEmpty(reactions))
//                    //{
//                    //    var reactionItems = reactions.Split(',');
//                        foreach (string reactionItem in reactions)
//                        {
//                            var rCode = new CodeableConcept();
//                            rCode.Coding.Add(new Coding { Code = reactionItem, Display = reactionItem, System = "http://snomed.info/"});
//                            rCode.Text = reactionItem;
//                            menifestationList.Add(rCode);
//                        }
//                        component.Manifestation = menifestationList;
//                    //}

//                    var substance = new CodeableConcept();
//                    substance.Coding.Add(new Coding { Code = description, Display = description, System = "http://snomed.info/" });
//                    substance.Text = description;

//                    component.Substance = substance;
//                    component.Severity = reactiontype == "Urgent" ? AllergyIntolerance.AllergyIntoleranceSeverity.Severe: AllergyIntolerance.AllergyIntoleranceSeverity.Moderate;
//                    reactionList.Add(component);
//                    allergy.Reaction = reactionList;
//                    var allintol=client.Create(allergy);
//                AllergiesBundle.AddResourceEntry(allergy, "AllergyIntolerance/" + allintol.Id);
//            }
          
//            var bundleId = client.Create(AllergiesBundle);
//            fhirPatientId.Identifier.Add(new Identifier("AllergiesBundle", bundleId.Id));
//            var updated_pat = client.Update(fhirPatientId);
//            //}            
//        }
      
//    }
//    public class Body
//    {
//        public string patientId { get; set; }
//        public string summary { get; set; }
//    }
//    public class ICDCode
//    {
//        public string icd9 { get; set; }
//        public string icd10 { get; set; }
//    }

//    public class Problemdetail
//    {
//        public string detail { get; set; }
//        public string entrycode { get; set; }
//        public string code { get; set; }
//        public string section { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//        public List<ICDCode> ICDCode { get; set; }
//    }

//    public class Allergiesdetail
//    {
//        public string detail { get; set; }
//        public string entrycode { get; set; }
//        public string description { get; set; }
//        public string section { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//        public string reactiontype { get; set; }
//        public List<string> reactions { get; set; }
//        public object ICDCode { get; set; }
//    }

//    public class SurgicalHistorydetail
//    {
//        public string detail { get; set; }
//        public string entrycode { get; set; }
//        public string section { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//        public object ICDCode { get; set; }
//    }

//    public class ICDCode2
//    {
//        public string icd9 { get; set; }
//        public string icd10 { get; set; }
//    }

//    public class FamilyHistorydetail
//    {
//        public string detail { get; set; }
//        public string entrycode { get; set; }
//        public string section { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//        public List<ICDCode2> ICDCode { get; set; }
//        public List<string> relations { get; set; }
//    }

//    public class ICDCode3
//    {
//        public string icd9 { get; set; }
//        public string icd10 { get; set; }
//    }

//    public class SocialHistorydetail
//    {
//        public string detail { get; set; }
//        public string entrycode { get; set; }
//        public string section { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//        public List<ICDCode3> ICDCode { get; set; }
//    }

//    public class Vitalsdetail
//    {
//        public string section { get; set; }
//        public string entrycode { get; set; }
//        public string code { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//        public string description { get; set; }
//        public string detail { get; set; }
//        public object ICDCode { get; set; }
//    }

//    public class Orderhistory
//    {
//        public string detail { get; set; }
//        public string entrycode { get; set; }
//        public string section { get; set; }
//        public string status { get; set; }
//        public string displaydate { get; set; }
//    }
//    public class HackMedication
//    {
//        public string drugcharacterization { get; set; }
//        public string medicinalproduct { get; set; }
//        public string generic_name { get; set; }
//    }
//    public class Summary
//    {
//        public List<Problemdetail> Problemdetail { get; set; }
//        public List<Allergiesdetail> Allergiesdetail { get; set; }
//        public List<SurgicalHistorydetail> SurgicalHistorydetail { get; set; }
//        public List<FamilyHistorydetail> FamilyHistorydetail { get; set; }
//        public List<SocialHistorydetail> SocialHistorydetail { get; set; }
//        public List<Vitalsdetail> Vitalsdetail { get; set; }
//        public List<Orderhistory> Orderhistory { get; set; }
//        public List<HackMedication> Medicationhistory { get; set; }
//    }


//}
