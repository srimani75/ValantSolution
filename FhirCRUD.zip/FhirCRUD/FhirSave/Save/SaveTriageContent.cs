using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace FhirSave
{
    public class SaveTriageContent
    {        

        [FunctionName("SaveTriageContent")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req, ILogger log)
        {
            string responseMessage = string.Empty;
            BadRequestResult badresult = new BadRequestResult();
            try
            {
                var content = new StreamReader(req.Body).ReadToEndAsync();
                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                var mrn = query.Get("MRN");
                Models.TriagePayload reqdata = JsonConvert.DeserializeObject<Models.TriagePayload>(content.Result);
               
                //var resource = "https://optum-fhirserver.azurehealthcareapis.com";
                var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
                var bearerToken = FhirToken.GetBearerToken(log);
                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
                                

                Patient patresource= GetPatient(client,resource,mrn);

                SaveTriageBotCauses(patresource, reqdata, client, resource);
                SaveTriageBotPatientResponses(patresource, reqdata.qna, client,resource);
                SaveTriageBotCC(patresource, reqdata.chief_complaints, reqdata.secondary_complaints,reqdata.denials,reqdata.serious_symptoms, client, resource);
               
                responseMessage = patresource.Id;                

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
            return new OkObjectResult(responseMessage);
        }
       
        private Patient GetPatient(FhirClient client, string resource, string mrn)
        {
            var pat = new Patient();
            //Patient pat = null;
            var conditions = new SearchParams();
            conditions.Add("identifier", mrn);
            //Bundle results = client.Search<Patient>(new string[] { "family:exact="+familyname.Split(" ")[1] });
            Bundle results = client.Search<Patient>(conditions);
            if (results.Entry.Count > 0)
            {
                var fhirpatientId = results.Entry[0].Resource.Id;
                var location = new Uri(resource + "/Patient/" + fhirpatientId);
                pat = client.Read<Patient>(location);
            }
            return pat;
        }
        private void SaveTriageBotCC(Patient FHIRPatient, List<string> CCcontent, List<string> SecondaryComplaints,List<string> Denials, List<Models.SeriousSymptom> serioussymptoms, FhirClient client, string resource)
        {
            
            Bundle CCBundle = new Bundle();
            CCBundle.Type = Bundle.BundleType.Collection;
            if (CCcontent != null)
            {
                var TriageCondition = new Condition();
                TriageCondition.Subject= new ResourceReference(string.Format(resource + "/Patient/"+FHIRPatient.Id));
                CodeableConcept cdcCondition = new CodeableConcept();
                cdcCondition.AddAnnotation(Condition.ConditionClinicalStatusCodes.Active);
                TriageCondition.ClinicalStatus = cdcCondition;
                List<Annotation> lstcc = new List<Annotation>();
                foreach(var complaint in CCcontent)
                {
                    Annotation AnChiefComplaint = new Annotation();
                    Markdown mkcomplaint = new Markdown();
                    mkcomplaint.Value = complaint;
                    AnChiefComplaint.Text = mkcomplaint;
                    lstcc.Add(AnChiefComplaint);
                }
                TriageCondition.Note = lstcc;
                List<Condition.EvidenceComponent> lstsecondarycomplaints = new List<Condition.EvidenceComponent>();              
               
                foreach(var secondcomplaint in SecondaryComplaints)
                {
                    List<CodeableConcept> lstcodeablesecondarycomplaints = new List<CodeableConcept>();
                    Condition.EvidenceComponent secondarycomplaints = new Condition.EvidenceComponent();
                    var ccCat = new CodeableConcept();
                    ccCat.Coding.Add(new Coding { Code = secondcomplaint, Display = "SecondaryComplaint", System = "https://www.hl7.org/fhir/condition.html" });
                    lstcodeablesecondarycomplaints.Add(ccCat);
                    secondarycomplaints.Code = lstcodeablesecondarycomplaints;
                    lstsecondarycomplaints.Add(secondarycomplaints);
                }
                int denialcount = 0;
                foreach (var item in Denials)
                {
                    var denial = new Extension();
                    denial.ElementId = "Denials";
                    denialcount=denialcount+1;
                    string ID = "denial" + Convert.ToString(denialcount);
                    denial.Value = new CodeableConcept { Text = item, ElementId = ID, TextElement = new Hl7.Fhir.Model.FhirString { Value = item } };                    
                    TriageCondition.Extension.Add(denial);
                }


                foreach (var item in serioussymptoms)
                {
                    var sersymptoms = new Extension();
                    sersymptoms.Value = new CodeableConcept { Text = item.common_name, ElementId = item.id, TextElement = new Hl7.Fhir.Model.FhirString { Value = item.name } };
                    sersymptoms.SetBoolExtension("https://www.hl7.org/fhir/symptomlevel", item.is_emergency);
                    TriageCondition.Extension.Add(sersymptoms);
                }
                
                TriageCondition.Evidence = lstsecondarycomplaints;
                var conditionres=client.Create(TriageCondition);
                CCBundle.AddResourceEntry(TriageCondition, "ComplaintsBundle/" + conditionres.Id);
                var bundleid = client.Create(CCBundle);
                FHIRPatient.Identifier.Add(new Identifier("Complaints", bundleid.Id));
                client.Update(FHIRPatient);
            }

            
        }      
        private void SaveTriageBotCauses(Patient FHIRPatient, Models.TriagePayload payload, FhirClient client, string resource)
        {
            List<Models.PossibleCaus> lstPossiblecauses = new List<Models.PossibleCaus>();
            
            List<string> lstcare = new List<string>();
            List<string> lstrisks = new List<string>();

            Bundle possiblecausesBundle = new Bundle();
                possiblecausesBundle.Type = Bundle.BundleType.Collection;

                if (payload != null)
                {
                    lstPossiblecauses = payload.possible_causes;                   
                    lstcare = payload.care_options;
                    lstrisks = payload.present_risk_factors;
                    var bsresource = new Basic();
                   
                    bsresource.Identifier.Add(new Identifier("AsyncPatientInfermedica",""));
                    bsresource.Created = DateTime.Now.ToString("yyyy-MM-dd"); 

                    List<Extension> lstTriageCauses = new List<Extension>();
                    bsresource.Subject= new ResourceReference(string.Format(resource + "/Patient/"+ FHIRPatient.Id));
                    Narrative nrBasicResource = new Narrative();
                    nrBasicResource.Status = Narrative.NarrativeStatus.Generated;
                    nrBasicResource.Div = " <div xmlns=\"http://www.w3.org/1999/xhtml\"><p>This is a Basic resource for Asynch Patient Infermedica data </p></div> ";
                    bsresource.Text = nrBasicResource;

                    CodeableConcept ccConsultation = new CodeableConcept();
                    ccConsultation.Coding.Add(new Coding { Display = "teleconsultation",UserSelected =payload.teleconsultation_applicable, System = "http://loinc.org" });
                    ccConsultation.Coding.Add(new Coding { Display = "triagelevel", Code =payload.triage_level, System = "http://loinc.org" });
                    bsresource.Code = ccConsultation;

                    foreach (var item in lstPossiblecauses)
                    {
                        
                        var posscauses = new Extension();
                        
                        CodeableConcept ccposscauses = new CodeableConcept();
                        ccposscauses.ElementId = item.id;
                        ccposscauses.Coding.Add(new Coding { Display = item.name, System = "http://loinc.org" });
                        ccposscauses.Text = item.common_name;
                        posscauses.Value = ccposscauses;
                        if (item.sex_filter != null)
                        {
                            var sexfilter = new Extension();
                            var ffilter = new Hl7.Fhir.Model.FhirString();
                            ffilter.Value= item.sex_filter;
                            sexfilter.Value= ffilter;
                            posscauses.Extension.Add(sexfilter);
                        }
                       // posscauses.AddAnnotation(ccposscauses);

                        var category = new Extension();
                        var ccCat = new CodeableConcept();
                        if(item.categories!=null)
                            ccCat.Coding.Add(new Coding { Display = "Category", Code = item.categories[0], System = "http://hl7.org/fhir/Extensions" });

                        ccCat.Coding.Add(new Coding { Display = "Prevalence",Code=item.prevalence, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "acuteness",Code=item.acuteness, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "severity", Code = item.severity, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "triage_level", Code = item.triage_level, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "recommended_channel", Code = item.recommended_channel, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "probability", Code = item.probability.ToString(), System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "short_description", Code = item.short_description, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "medline_url", Code = item.medline_url, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "common_medline_name", Code = item.common_medline_name, System = "http://hl7.org/fhir/Extensions" });
                        category.Value = new Hl7.Fhir.Model.FhirString { Value = item.categories[0] };
                        category.Value=ccCat;
                        posscauses.Extension.Add(category);

                        var extras = new Extension();
                        extras.ElementId = "extras";
                        var ccextras = new CodeableConcept();
                        ccextras.Coding.Add(new Coding { Display = "ICDCodes", Code = item.extras.icd10_code, System = "http://hl7.org/fhir/Extensions" });
                        ccextras.Coding.Add(new Coding { Display = "hint", Code = item.extras.hint, System = "http://hl7.org/fhir/Extensions" });
                        extras.Value=ccextras;

                        posscauses.Extension.Add(extras);
                        lstTriageCauses.Add(posscauses);
                    }

                    var careoptions = new Extension();
                    careoptions.ElementId = "careoptions";
                    if(lstcare.Count>0)
                    {
                        var cccareoptions = new CodeableConcept();
                        foreach (var item in lstcare)
                        {  
                            cccareoptions.Coding.Add(new Coding { Display = item, Code = item, System = "http://hl7.org/fhir/Extensions" });
                        }
                        careoptions.Value = cccareoptions;
                    }
                    lstTriageCauses.Add(careoptions);

                    var riskfactors = new Extension();
                riskfactors.ElementId = "RiskFactors";
                    if (lstrisks.Count > 0)
                    {
                        var ccriskfactors = new CodeableConcept();
                        foreach (var item in lstrisks)
                        {
                            ccriskfactors.Coding.Add(new Coding { Display = item, Code = item, System = "http://hl7.org/fhir/Extensions" });
                        }
                        riskfactors.Value = ccriskfactors;
                    }
                    lstTriageCauses.Add(riskfactors);

                    bsresource.Extension = lstTriageCauses;    
                
                    //nrBasicResource.Extension = lstTriageCauses;
                    var poss = client.Create(bsresource);
                    possiblecausesBundle.AddResourceEntry(bsresource,resource+"/Basic/" + poss.Id);
                    var bundleid=client.Create(possiblecausesBundle);

                    FHIRPatient.Identifier.Add(new Identifier("AsyncPatientInfermedica", bundleid.Id));
                    client.Update(FHIRPatient);        
                }
            
        }
        private void SaveTriageBotPatientResponses(Patient FHIRPatient, List<Models.Qna> patientresponses, FhirClient client,string resource)
        {
                Bundle patientresponsesBundle = new Bundle();
                patientresponsesBundle.Type = Bundle.BundleType.Collection;

                if (patientresponses != null)
                {
                    var Questionnaireresponseval = new QuestionnaireResponse();
                    Questionnaireresponseval.Source = new ResourceReference(string.Format(resource+"/Patient/", FHIRPatient.Id));
                    Questionnaireresponseval.Status = QuestionnaireResponse.QuestionnaireResponseStatus.Completed;
                    List<QuestionnaireResponse.ItemComponent> lstQuesResponseItems = new List<QuestionnaireResponse.ItemComponent>();
                    foreach (var item in patientresponses)
                    {
                        QuestionnaireResponse.ItemComponent QuesResponseItem = new QuestionnaireResponse.ItemComponent();
                        QuesResponseItem.Text = item.question;
                        List<QuestionnaireResponse.AnswerComponent> lstAnswerComponent = new List<QuestionnaireResponse.AnswerComponent>();        QuestionnaireResponse.AnswerComponent QuesResponseAnswerItem = new QuestionnaireResponse.AnswerComponent();

                        QuestionnaireResponse.ItemComponent QuesResponseAnsItem = new QuestionnaireResponse.ItemComponent();
                        QuesResponseAnsItem.Text = item.answer;

                        List<QuestionnaireResponse.ItemComponent> lstQuesItems = new List<QuestionnaireResponse.ItemComponent>();
                        lstQuesItems.Add(QuesResponseAnsItem);

                        QuesResponseAnswerItem.Item = lstQuesItems;
                        lstAnswerComponent.Add(QuesResponseAnswerItem);

                        QuesResponseItem.Answer = lstAnswerComponent;
                            
                        lstQuesResponseItems.Add(QuesResponseItem);
                    }
                    Questionnaireresponseval.Item = lstQuesResponseItems;
                    var quest = client.Create(Questionnaireresponseval);
                    patientresponsesBundle.AddResourceEntry(Questionnaireresponseval, "QuestionnaireResponse/" + quest.Id);                   
                    var bundleid=client.Create(patientresponsesBundle);
                    FHIRPatient.Identifier.Add(new Identifier("QuestionnaireResponseBundle", bundleid.Id));
                   client.Update(FHIRPatient);
                }
           
        }
    }
   
}
