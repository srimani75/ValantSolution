using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;

namespace FhirSave
{
    public static class UpsertNotesData
    {
        public static string EndpointURI = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBEndpoint");
        public static string databaseId = Utils.ReliantUtlity.GetEnvironmentVariable("RisksDatabase");
        public static string containerId = Utils.ReliantUtlity.GetEnvironmentVariable("NotesContainer");
        public static string PrimaryKey = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBKey");
        public static string Eventhubendpoint = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubEndpoint");
        public static string EventhubKey = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubKey");
        public static string env = Utils.ReliantUtlity.GetEnvironmentVariable("AGG_ID");

        //public static string EndpointURI = "https://cosmosdb-stage.documents.azure.com:443/";
        //public static string PrimaryKey = "IpmKSMKNYA6sYK03MSLFsO0tPvCSUVUDggGlps6dAdTvaSeQT95PyfmdRMjWhxBqPZE4Rm7zGmSOEyTarVrEpw==";
        //public static string databaseId = "cosmosdb-nonprod-sqldb";
        //public static string containerId = "NotesData";
        //public static string Eventhubendpoint = "lp-cl-eastus-eventhub-07c73293.servicebus.windows.net/";
        //public static string EventhubKey = "+1tKqvZhKF5l2maA3+WoFmqJ2Bmt3JPtD4BEvrA0EIM=";
        //public static string env = "FHIRService-Dev";
        [FunctionName("UpsertNotesData")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            log.LogInformation("Bodydata:" + requestBody);
            PatientNote data = JsonConvert.DeserializeObject<PatientNote>(requestBody);
            var connectionStringBuilder = new EventHubsConnectionStringBuilder("Endpoint=sb://" + Eventhubendpoint + ";SharedAccessKeyName=lp-cl-auth-rule;SharedAccessKey=" + EventhubKey)
            {
                EntityPath = "application-logs"
            };
            log.LogInformation(connectionStringBuilder.ToString());
            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            try
            {
                if(data.PatientID==null||data.PatientID=="null")
                {
                    var errorResonse = new Models.ErrorResponse();
                    //replace with actual id
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = "Upserting function failure!!";
                    errorResonse.detail = "PatientID is NULL";
                    log.LogError(errorResonse.error);
                    log.LogInformation(errorResonse.error);
                    var evehubresponse = new Models.EventHubErrorResponse();
                    var eventhubdata = new Models.Data();
                    eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                    evehubresponse.data = eventhubdata;
                    evehubresponse.agg = env + "-NotesData";
                    evehubresponse.type = "Error";
                    var message = JsonConvert.SerializeObject(evehubresponse);
                    await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, message);
                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }
                else
                {
                    var container = Utils.DBUtility.GetCosmosContainer(EndpointURI, PrimaryKey, databaseId, containerId);
                    var dataval = Utils.DBUtility.GetItemFromContainer(EndpointURI, PrimaryKey, "select * from c where c.id='" + data.sessionID + data.PatientID.Replace("-", "") + "'", databaseId, containerId);

                    if (dataval != null)
                    {
                        var datatest = Utils.Extention.ConvertObjectToJson(dataval).TrimStart('[').TrimEnd(']');

                        var upsertrecorddata = JsonConvert.DeserializeObject<PatientNote>(datatest);
                        if (upsertrecorddata.IsNoteGenerated)
                        {
                            data.IsNoteGenerated = upsertrecorddata.IsNoteGenerated;
                            data.IsProcessed = upsertrecorddata.IsProcessed;
                            data.Trycount = upsertrecorddata.Trycount;
                        }
                    }
                    var upsertResult = await Utils.DBUtility.UpsertCosmosItemAsync(data, container, log, eventHubClient);

                    return new OkObjectResult(upsertResult);
                }
                
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = "Upserting function failure!!";
                errorResonse.detail = "ID:" + data.id.ToString();
                log.LogError(errorResonse.error);
                log.LogInformation(errorResonse.error);
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env + "-NotesData";
                evehubresponse.type = "Error";
                var message = JsonConvert.SerializeObject(evehubresponse);
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, message);
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }

        }
    }

    public class PatientNote
    {
        public string id { get; set; }
        public string PatientID { get; set; }
        public string sessionID { get; set; }
        public string AccessToken { get; set; }
        public string Consenttimestamp { get; set; }
        public bool isInterrupted { get; set; }
        public string HPI { get; set; }
        public string TreatmentPlan { get; set; }
        public string CallBackPhone { get; set; }
        public string IsOkMsg { get; set; }
        public string ProviderID { get; set; }
        public bool AppointmentType { get; set; }
        public int Trycount { get; set; }
        public string IsProcessed { get; set; }
        public string Updatedtime { get; set; }
        public bool IsNoteGenerated { get; set; }
        public string AsyncHBID { get; set; }
        public string CDO { get; set; }
        public void SetId()
        {
            id = $"{sessionID + PatientID.Replace("-","")}";
        }
    }
}
