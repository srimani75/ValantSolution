using FhirSave.Processors;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Optum.Fhir.Models;
using System.IO;
using System.Threading.Tasks;

namespace FhirSave.Save
{
    public static class SaveInsurance
    {
        [FunctionName("SaveInsurance")]

        public static async Task<IActionResult> Run(
           [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.1/SaveInsurance")] HttpRequest req,
           ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");


            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            InsuranceInfo data = JsonConvert.DeserializeObject<InsuranceInfo>(requestBody);

            log.LogInformation("Save Demographics : ");
            log.LogInformation(requestBody);
            Patient pat = await CoverageProcessor.SavePatientInsurance(data, log);

            return pat == null ? new OkObjectResult("Patient Not Found..") : new OkObjectResult(pat);
        }

    }
}
