using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace FhirSave
{
    public class SaveTriageContent10
    {
        public static string EventhubKey = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubKey");
        public static string env = Utils.ReliantUtlity.GetEnvironmentVariable("AGG_ID");
        public static string Eventhubendpoint = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubEndpoint");
        //public static string Eventhubendpoint = "lp-cl-eastus-eventhub-07c73293.servicebus.windows.net/";
        //public static string EventhubKey = "+1tKqvZhKF5l2maA3+WoFmqJ2Bmt3JPtD4BEvrA0EIM=";
        //public static string env = "Dev";
        [FunctionName("SaveTriageContent10")]
        public async Task<IActionResult> Run(
           [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1.0/Triageload")] HttpRequest req, ILogger log)
        {
            string responseMessage = string.Empty;
            BadRequestResult badresult = new BadRequestResult();

            var connectionStringBuilder = new EventHubsConnectionStringBuilder("Endpoint=sb://" + Eventhubendpoint + ";SharedAccessKeyName=lp-cl-auth-rule;SharedAccessKey=" + EventhubKey)
            {
                EntityPath = "application-logs"
            };

            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            var content = new StreamReader(req.Body).ReadToEndAsync();
            var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
            var mrn = query.Get("patientID");
            var Product = query.Get("CDO");
            log.LogInformation(mrn + ":" + Product);
            try
            {
                
                Models.TriagePayload reqdata = JsonConvert.DeserializeObject<Models.TriagePayload>(content.Result);
                if (mrn!="null")
                {     
                    if(content.Result == "" || content.Result == "{}" || string.IsNullOrEmpty(content.Result))
                    {

                        var errorResonse = new Models.ErrorResponse();
                        //replace with actual id
                        errorResonse.error = "Request data is coming to Triage load as NULL";
                        errorResonse.message = "Request data is coming to Triage load as NULL";
                        errorResonse.detail = "Request data is coming to Triage load as NULL";
                        var evehubresponse = new Models.EventHubErrorResponse();
                        var eventhubdata = new Models.Data();
                        eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                        evehubresponse.data = eventhubdata;
                        evehubresponse.agg = env + " Triage load service";
                        evehubresponse.type = "Error";
                        await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                        var result = new OkObjectResult(errorResonse);
                        result.StatusCode = StatusCodes.Status500InternalServerError;
                        return result;



                    }
                    else
                    {

                        //var resource = "https://optum-fhirserver-stage.azurehealthcareapis.com";
                        var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
                        var bearerToken = FhirToken.GetBearerToken(log);
                        var messageHandler = new HttpClientEventHandler();
                        messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                        {
                            e.RawRequest.Headers
                            .Add("Authorization", $"Bearer {bearerToken}");
                        };

                        FhirClient client = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                        {
                            PreferredFormat = ResourceFormat.Json
                        });

                        Patient patresource = GetPatient(client, resource, mrn);
                        if (Product == "Async")
                        {
                            Patient patresource1 = GetPatient(client, resource, mrn);
                            if (patresource1.Id != null)
                            {
                                await SaveTriageBotCauses(patresource1, log, reqdata, client, resource, eventHubClient);
                                await SaveTriageBotPatientResponses(patresource1, log, reqdata.qna, client, resource, eventHubClient);
                                await SaveTriageBotCC(patresource1, log, reqdata.chief_complaints, reqdata.secondary_complaints, reqdata.denials, reqdata.serious_symptoms, client, resource, eventHubClient);
                            }
                            else
                            {
                                var pat = DirectUpsertPatient(mrn, client, log, eventHubClient);

                                if (pat.Id != null)
                                {
                                    await SaveTriageBotCauses(pat, log, reqdata, client, resource, eventHubClient);
                                    await SaveTriageBotPatientResponses(pat, log, reqdata.qna, client, resource, eventHubClient);
                                    await SaveTriageBotCC(pat, log, reqdata.chief_complaints, reqdata.secondary_complaints, reqdata.denials, reqdata.serious_symptoms, client, resource, eventHubClient);
                                }
                                else
                                {
                                    var errorResonse = new Models.ErrorResponse();
                                    //replace with actual id
                                    errorResonse.error = Guid.NewGuid().ToString();
                                    errorResonse.message = "Patient resource not existing in FHIR";
                                    errorResonse.detail = "ID:" + mrn;
                                    var evehubresponse = new Models.EventHubErrorResponse();
                                    var eventhubdata = new Models.Data();
                                    eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                                    evehubresponse.data = eventhubdata;
                                    evehubresponse.agg = env + " Async Triage load service";
                                    evehubresponse.type = "Error";
                                    await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                                    var result = new OkObjectResult(errorResonse);
                                    result.StatusCode = StatusCodes.Status500InternalServerError;
                                    return result;
                                }

                            }
                        }
                        else
                        {
                            if (patresource != null)
                            {
                                await SaveTriageBotCauses(patresource, log, reqdata, client, resource, eventHubClient);
                                await SaveTriageBotPatientResponses(patresource, log, reqdata.qna, client, resource, eventHubClient);
                                await SaveTriageBotCC(patresource, log, reqdata.chief_complaints, reqdata.secondary_complaints, reqdata.denials, reqdata.serious_symptoms, client, resource, eventHubClient);
                            }
                            else
                            {
                                var errorResonse = new Models.ErrorResponse();
                                //replace with actual id
                                errorResonse.error = Guid.NewGuid().ToString();
                                errorResonse.message = "Patient resource not existing in FHIR";
                                errorResonse.detail = "ID:" + mrn;
                                var evehubresponse = new Models.EventHubErrorResponse();
                                var eventhubdata = new Models.Data();
                                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                                evehubresponse.data = eventhubdata;
                                evehubresponse.agg = env + " Triage load service";
                                evehubresponse.type = "Error";
                                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                                var result = new OkObjectResult(errorResonse);
                                result.StatusCode = StatusCodes.Status500InternalServerError;
                                return result;
                            }
                        }


                        responseMessage = patresource.Id;
                    }

                }
                else
                {
                    var errorResonse = new Models.ErrorResponse();
                    //replace with actual id
                    errorResonse.error = "PatientID is coming to Triage load as NULL";
                    errorResonse.message = "PatientID is coming to Triage load as NULL";
                    errorResonse.detail = "PatientID is coming to Triage load as NULL";
                    var evehubresponse = new Models.EventHubErrorResponse();
                    var eventhubdata = new Models.Data();
                    eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                    evehubresponse.data = eventhubdata;
                    evehubresponse.agg = env + " Triage load service";
                    evehubresponse.type = "Error";
                    await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail ="ID"+ mrn+"#"+ ex;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env+" Triage load service";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
            return new OkObjectResult(responseMessage);
        }
        private static Patient DirectUpsertPatient(string patientID, FhirClient client, ILogger log, EventHubClient eventhubclient)
        {

            var pat = new Patient();
            var upsertpat = new Patient();
            try
            {
                var Newpat = client.Create(pat);
                Newpat.Identifier.Add(new Identifier("AsyncPatientID", patientID));
                upsertpat = client.Update(Newpat);
                log.LogInformation("Patient resource through Async:"+upsertpat.Id);
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;
                //ErrorVal = "Patient Create or Update: " + ex.Message;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env + "AsyncTriage service";
                evehubresponse.type = "Error";
                Utils.ReliantUtlity.SendMessagesToEventHub(eventhubclient, log, JsonConvert.SerializeObject(evehubresponse));
                //SendingRandomMessagesAsync(log, errorResonse);               
            }
            return upsertpat;
        }
        private Patient GetPatient(FhirClient client, string resource, string mrn)
        {
            var pat = new Patient();
            //Patient pat = null;
            var conditions = new SearchParams();
            conditions.Add("identifier", mrn);
            //Bundle results = client.Search<Patient>(new string[] { "family:exact="+familyname.Split(" ")[1] });
            Bundle results = client.Search<Patient>(conditions);
            if (results.Entry.Count > 0)
            {
                var fhirpatientId = results.Entry[0].Resource.Id;
                var location = new Uri(resource + "/Patient/" + fhirpatientId);
                pat = client.Read<Patient>(location);
            }
            return pat;
        }
        public async Task<IActionResult> SaveTriageBotCC(Patient FHIRPatient,ILogger log, List<string> CCcontent, List<string> SecondaryComplaints, List<string> Denials, List<Models.SeriousSymptom> serioussymptoms, FhirClient client, string resource,EventHubClient eventHubClient)
        {
            Bundle CCBundle = new Bundle();
            CCBundle.Type = Bundle.BundleType.Collection;
            var val = new Patient();
            try
            {
                if (CCcontent != null)
                {
                    var TriageCondition = new Condition();
                    TriageCondition.Subject = new ResourceReference(string.Format(resource + "/Patient/" + FHIRPatient.Id));
                    CodeableConcept cdcCondition = new CodeableConcept();
                    cdcCondition.AddAnnotation(Condition.ConditionClinicalStatusCodes.Active);
                    TriageCondition.ClinicalStatus = cdcCondition;
                    List<Annotation> lstcc = new List<Annotation>();
                    foreach (var complaint in CCcontent)
                    {
                        Annotation AnChiefComplaint = new Annotation();
                        Markdown mkcomplaint = new Markdown();
                        mkcomplaint.Value = complaint;
                        AnChiefComplaint.Text = mkcomplaint;
                        lstcc.Add(AnChiefComplaint);
                    }
                    TriageCondition.Note = lstcc;
                    List<Condition.EvidenceComponent> lstsecondarycomplaints = new List<Condition.EvidenceComponent>();

                    foreach (var secondcomplaint in SecondaryComplaints)
                    {
                        List<CodeableConcept> lstcodeablesecondarycomplaints = new List<CodeableConcept>();
                        Condition.EvidenceComponent secondarycomplaints = new Condition.EvidenceComponent();
                        var ccCat = new CodeableConcept();
                        ccCat.Coding.Add(new Coding { Code = secondcomplaint, Display = "SecondaryComplaint", System = "https://www.hl7.org/fhir/condition.html" });
                        lstcodeablesecondarycomplaints.Add(ccCat);
                        secondarycomplaints.Code = lstcodeablesecondarycomplaints;
                        lstsecondarycomplaints.Add(secondarycomplaints);
                    }
                    int denialcount = 0;
                    foreach (var item in Denials)
                    {
                        var denial = new Extension();
                        denial.ElementId = "Denials";
                        denialcount = denialcount + 1;
                        string ID = "denial" + Convert.ToString(denialcount);
                        denial.Value = new CodeableConcept { Text = item, ElementId = ID, TextElement = new Hl7.Fhir.Model.FhirString { Value = item } };
                        TriageCondition.Extension.Add(denial);
                    }


                    foreach (var item in serioussymptoms)
                    {
                        var sersymptoms = new Extension();
                        sersymptoms.ElementId = item.common_name;
                        sersymptoms.Value = new CodeableConcept { Text = item.common_name, ElementId = item.id, TextElement = new Hl7.Fhir.Model.FhirString { Value = item.name } };
                        sersymptoms.SetBoolExtension("https://www.hl7.org/fhir/symptomlevel", item.is_emergency);
                        TriageCondition.Extension.Add(sersymptoms);
                    }

                    TriageCondition.Evidence = lstsecondarycomplaints;
                    var conditionres = client.Create(TriageCondition);
                    CCBundle.AddResourceEntry(TriageCondition, "ComplaintsBundle/" + conditionres.Id);
                    var bundleid = client.Create(CCBundle);
                    FHIRPatient.Identifier.Add(new Identifier("Complaints", bundleid.Id));
                    val=client.Update(FHIRPatient);
                    return new OkObjectResult(val);
                }
            }
            catch(Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.InnerException.Message;
                errorResonse.detail = ex;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env +" Triage load service";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return new OkObjectResult(result);
            }
            return new OkObjectResult(val);
        }
        public async Task<IActionResult> SaveTriageBotCauses(Patient FHIRPatient, ILogger log, Models.TriagePayload payload, FhirClient client, string resource,EventHubClient eventHubClient)
        {
            var val = new Patient();
            try
            {
                List<Models.PossibleCaus> lstPossiblecauses = new List<Models.PossibleCaus>();

                List<string> lstcare = new List<string>();
                List<string> lstrisks = new List<string>();

                Bundle possiblecausesBundle = new Bundle();
                possiblecausesBundle.Type = Bundle.BundleType.Collection;
                if (payload != null)
                {
                    lstPossiblecauses = payload.possible_causes;
                    lstcare = payload.care_options;
                    lstrisks = payload.present_risk_factors;
                    var bsresource = new Basic();

                    bsresource.Identifier.Add(new Identifier("AsyncPatientInfermedica", ""));
                    bsresource.Created = DateTime.Now.ToString("yyyy-MM-dd");

                    List<Extension> lstTriageCauses = new List<Extension>();
                    bsresource.Subject = new ResourceReference(string.Format(resource + "/Patient/" + FHIRPatient.Id));
                    Narrative nrBasicResource = new Narrative();
                    nrBasicResource.Status = Narrative.NarrativeStatus.Generated;
                    nrBasicResource.Div = " <div xmlns=\"http://www.w3.org/1999/xhtml\"><p>This is a Basic resource for Asynch Patient Infermedica data </p></div> ";
                    bsresource.Text = nrBasicResource;

                    CodeableConcept ccConsultation = new CodeableConcept();
                    ccConsultation.Coding.Add(new Coding { Display = "teleconsultation", UserSelected = payload.teleconsultation_applicable, System = "http://loinc.org" });
                    ccConsultation.Coding.Add(new Coding { Display = "triagelevel", Code = payload.triage_level, System = "http://loinc.org" });
                    ccConsultation.Coding.Add(new Coding { Display = "NPS", Code = payload.nps_score.ToString() });
                    bsresource.Code = ccConsultation;

                    foreach (var item in lstPossiblecauses)
                    {

                        var posscauses = new Extension();

                        CodeableConcept ccposscauses = new CodeableConcept();
                        ccposscauses.ElementId = item.id;
                        ccposscauses.Coding.Add(new Coding { Display = item.name, System = "http://loinc.org" });
                        ccposscauses.Text = item.common_name;
                        posscauses.Value = ccposscauses;
                        if (item.sex_filter != null)
                        {
                            var sexfilter = new Extension();
                            var ffilter = new Hl7.Fhir.Model.FhirString();
                            ffilter.Value = item.sex_filter;
                            sexfilter.Value = ffilter;
                            posscauses.Extension.Add(sexfilter);
                        }
                        // posscauses.AddAnnotation(ccposscauses);

                        var category = new Extension();
                        var ccCat = new CodeableConcept();
                        if (item.categories != null)
                            ccCat.Coding.Add(new Coding { Display = "Category", Code = item.categories[0], System = "http://hl7.org/fhir/Extensions" });

                        ccCat.Coding.Add(new Coding { Display = "Prevalence", Code = item.prevalence, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "acuteness", Code = item.acuteness, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "severity", Code = item.severity, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "triage_level", Code = item.triage_level, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "recommended_channel", Code = item.recommended_channel, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "probability", Code = item.probability.ToString(), System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "short_description", Code = item.short_description, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "medline_url", Code = item.medline_url, System = "http://hl7.org/fhir/Extensions" });
                        ccCat.Coding.Add(new Coding { Display = "common_medline_name", Code = item.common_medline_name, System = "http://hl7.org/fhir/Extensions" });
                        category.Value = new Hl7.Fhir.Model.FhirString { Value = item.categories[0] };
                        category.Value = ccCat;
                        posscauses.Extension.Add(category);

                        var extras = new Extension();
                        extras.ElementId = "extras";
                        var ccextras = new CodeableConcept();
                        ccextras.Coding.Add(new Coding { Display = "ICDCodes", Code = item.extras.icd10_code, System = "http://hl7.org/fhir/Extensions" });
                        ccextras.Coding.Add(new Coding { Display = "hint", Code = item.extras.hint, System = "http://hl7.org/fhir/Extensions" });
                        extras.Value = ccextras;

                        posscauses.Extension.Add(extras);
                        lstTriageCauses.Add(posscauses);
                    }

                    var careoptions = new Extension();
                    careoptions.ElementId = "careoptions";
                    if (lstcare.Count > 0)
                    {
                        var cccareoptions = new CodeableConcept();
                        foreach (var item in lstcare)
                        {
                            cccareoptions.Coding.Add(new Coding { Display = item, Code = item, System = "http://hl7.org/fhir/Extensions" });
                        }
                        careoptions.Value = cccareoptions;
                    }
                    lstTriageCauses.Add(careoptions);

                    var riskfactors = new Extension();
                    riskfactors.ElementId = "RiskFactors";
                    if (lstrisks.Count > 0)
                    {
                        var ccriskfactors = new CodeableConcept();
                        foreach (var item in lstrisks)
                        {
                            ccriskfactors.Coding.Add(new Coding { Display = item, Code = item, System = "http://hl7.org/fhir/Extensions" });
                        }
                        riskfactors.Value = ccriskfactors;
                    }

                    lstTriageCauses.Add(riskfactors);

                    bsresource.Extension = lstTriageCauses;

                    //nrBasicResource.Extension = lstTriageCauses;
                    var poss = client.Create(bsresource);
                    possiblecausesBundle.AddResourceEntry(bsresource, resource + "/Basic/" + poss.Id);
                    var bundleid = client.Create(possiblecausesBundle);

                    FHIRPatient.Identifier.Add(new Identifier("AsyncPatientInfermedica", bundleid.Id));
                    val= client.Update(FHIRPatient);
                }
            }
            catch(Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.InnerException.Message;
                errorResonse.detail = ex;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env+" Triage load service";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return new OkObjectResult(result);
            }

            return new OkObjectResult(val);  
        }
        public async Task<IActionResult> SaveTriageBotPatientResponses(Patient FHIRPatient, ILogger log, List<Models.Qna> patientresponses, FhirClient client, string resource,EventHubClient eventHubClient)
        {
            var val = new Patient();
            try
            {
                Bundle patientresponsesBundle = new Bundle();
                patientresponsesBundle.Type = Bundle.BundleType.Collection;
                if (patientresponses != null)
                {
                    var Questionnaireresponseval = new QuestionnaireResponse();
                    Questionnaireresponseval.Source = new ResourceReference(string.Format(resource + "/Patient/", FHIRPatient.Id));
                    Questionnaireresponseval.Status = QuestionnaireResponse.QuestionnaireResponseStatus.Completed;
                    List<QuestionnaireResponse.ItemComponent> lstQuesResponseItems = new List<QuestionnaireResponse.ItemComponent>();
                    foreach (var item in patientresponses)
                    {
                        QuestionnaireResponse.ItemComponent QuesResponseItem = new QuestionnaireResponse.ItemComponent();
                        QuesResponseItem.Text = item.question;
                        List<QuestionnaireResponse.AnswerComponent> lstAnswerComponent = new List<QuestionnaireResponse.AnswerComponent>(); QuestionnaireResponse.AnswerComponent QuesResponseAnswerItem = new QuestionnaireResponse.AnswerComponent();

                        QuestionnaireResponse.ItemComponent QuesResponseAnsItem = new QuestionnaireResponse.ItemComponent();
                        //QuesResponseAnsItem.SetStringExtension("https://evidenceoperation", item.evidence);
                        if(item.evidence== "present" && item.type== "group_multiple")
                            QuesResponseAnsItem.Text = item.answer+" (Yes)";
                        else if(item.evidence == "present" && item.type != "group_multiple")
                            QuesResponseAnsItem.Text = item.answer;

                        if (item.evidence=="absent" && item.type == "group_multiple")
                            QuesResponseAnsItem.Text = item.answer + " (No)";
                        else if (item.evidence == "absent" && item.type != "group_multiple")
                            QuesResponseAnsItem.Text = item.answer;

                        if ((item.evidence == "Unknown" || item.evidence== "unknown") && item.type == "group_multiple")
                            QuesResponseAnsItem.Text = item.answer + " (I don't know)";
                        else if (item.evidence == "unknown" && item.type != "group_multiple")
                            QuesResponseAnsItem.Text = item.answer;

                        List<QuestionnaireResponse.ItemComponent> lstQuesItems = new List<QuestionnaireResponse.ItemComponent>();
                        lstQuesItems.Add(QuesResponseAnsItem);

                        QuesResponseAnswerItem.Item = lstQuesItems;
                        lstAnswerComponent.Add(QuesResponseAnswerItem);

                        QuesResponseItem.Answer = lstAnswerComponent;

                        lstQuesResponseItems.Add(QuesResponseItem);
                    }
                    Questionnaireresponseval.Item = lstQuesResponseItems;
                    var quest = client.Create(Questionnaireresponseval);
                    patientresponsesBundle.AddResourceEntry(Questionnaireresponseval, "QuestionnaireResponse/" + quest.Id);
                    var bundleid = client.Create(patientresponsesBundle);
                    FHIRPatient.Identifier.Add(new Identifier("QuestionnaireResponseBundle", bundleid.Id));
                    val=client.Update(FHIRPatient);
                }
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.InnerException.Message;
                errorResonse.detail = ex;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env+" Triage load service";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return new OkObjectResult(result);
            }
            return new OkObjectResult(val);
          

           

        }
    }
}

