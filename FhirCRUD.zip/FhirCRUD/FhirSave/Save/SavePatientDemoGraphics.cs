using FhirCronService.Models;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.IO;
using System.Threading.Tasks;

namespace FhirCronService.Processors
{
    public static class SavePatientDemoGraphics
    {
        [FunctionName("SavePatientDemoGraphics")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.1/SavePatientDemoGraphics")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            PatientDemographics data = JsonConvert.DeserializeObject<PatientDemographics>(requestBody);

            log.LogInformation("Save Demographics : ");
            log.LogInformation(requestBody);
            Patient pat = await PatientDemoGraphicsProcessor.SavePatientDemographics(data, log);

            return pat == null ? new OkObjectResult("Patient Not Found..") : new OkObjectResult(pat);
        }
    }
}
