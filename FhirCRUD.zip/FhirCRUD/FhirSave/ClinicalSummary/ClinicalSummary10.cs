using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Hl7.Fhir.Model;
using System.Collections.Generic;
using System;
using System.Globalization;
using System.Threading;
using Newtonsoft.Json;
using System.Diagnostics;


namespace FhirSave
{
    public class ClinicalSummary10
    {
        public static string lstcodes = "";
        public static List<Models.RiskFactors> lstMappedIDs = new List<Models.RiskFactors>();
        public static Models.ClinicalResponse clresponse=new Models.ClinicalResponse();
        public static string EndpointURI = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBEndpoint");
        public static string PrimaryKey = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBKey");

        public static string databaseId = Utils.ReliantUtlity.GetEnvironmentVariable("RisksDatabase");
        public static string containerId = Utils.ReliantUtlity.GetEnvironmentVariable("RisksContainer");

        //public static string databaseId = "cosmosdb-nonprod-sqldb";
        //public static string containerId = "RiskFactors";

        //public static string EndpointURI = "https://cosmosdb-nonprod.documents.azure.com:443/";
        //public static string PrimaryKey = "Jf3i20jv421s3z31W8JWoTJR2JJn9O8uvkcMfAKWXxhVyouZxLXJyl9oipbTTa3cdC4dJM2FvBDauqxjJKs9tg==";

        static readonly TaskCompletionSource<bool> s_tcs = new TaskCompletionSource<bool>();

        [FunctionName("ClinicalSummary10")]
        public async Task<IActionResult> Run(
             [HttpTrigger(AuthorizationLevel.Function, "post", Route = "v1.0/ClinicalSummary")] HttpRequest req,
             ILogger log)
        {
            string responseMessage = string.Empty;
            BadRequestResult badresult = new BadRequestResult();
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            try
            {
                cancellationTokenSource.CancelAfter(9000);
                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                lstcodes = "";
                var patientId = query.Get("patientId");
                var accesstoken = query.Get("accesstoken");
                Stopwatch timer = Stopwatch.StartNew();
                Utils.ReliantUtlity relutil = new Utils.ReliantUtlity();
                var sessIDResponse = relutil.GetSessionID(accesstoken, patientId, log, cancellationTokenSource.Token);
                timer.Stop();
                log.LogInformation($"SessionCall: {timer.Elapsed}");
                // clresponse.SessionID = sessIDResponse.sessionID;
                if (sessIDResponse.SessionID != "" && sessIDResponse.SessionID != "0")
                {
                    
                    clresponse.SessionID = sessIDResponse.SessionID;
                    int i = 0;
                    List<Models.Provider> lstprv = new List<Models.Provider>();
                    foreach (var id in sessIDResponse.ProviderID)
                    {
                        Models.Provider prv = new Models.Provider();
                        prv.ID = id;
                        prv.Providername = sessIDResponse.ProviderDisplayName[i];
                        i++;
                        lstprv.Add(prv);
                    }
                    clresponse.Providers = lstprv;
                    
                    //var resource = "https://optum-fhirserver.azurehealthcareapis.com";
                    var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
                    var bearerToken = FhirToken.GetBearerToken(log);
                    var messageHandler = new HttpClientEventHandler();
                    messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                    {
                        e.RawRequest.Headers
                        .Add("Authorization", $"Bearer {bearerToken}");
                    };
                    FhirClient client = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                    {
                        PreferredFormat = ResourceFormat.Json
                    });                   

                    Stopwatch pattimer = Stopwatch.StartNew();
                    var Patientrecord = Utils.ReliantUtlity.GetReliantPatient(accesstoken, patientId, log, cancellationTokenSource.Token);
                    pattimer.Stop();
                    log.LogInformation("Get EPIC Patient Call: " + pattimer.Elapsed);  
                    Patient fhirPatient = UpsertPatient(resource, Patientrecord.Result, client);
                    log.LogInformation("FHIR Patient:" + fhirPatient.Id);
                    Stopwatch sumtimer = Stopwatch.StartNew();
                    await SavePatientClinicalSummary(fhirPatient, patientId, client, accesstoken, resource,log, cancellationTokenSource.Token, messageHandler);
                    
                    sumtimer.Stop();
                    log.LogInformation("Clinical Summary call: "+ sumtimer.Elapsed.TotalSeconds);
                    await CosmosCall(lstcodes, log);
                }
                else
                {
                    var errorResonse = new Models.ErrorResponse();
                    //replace with actual id
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = "Session initiating failed";
                    errorResonse.detail = "Reliant session webservice did not return any session";
                    log.LogInformation(errorResonse.error);
                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }

            return new OkObjectResult(clresponse);
        }

        private static Patient UpsertPatient(string resource, Models.ReliantPatientModel.Patientinfo PatientDemoData, FhirClient client)
        {
            var pat = new Patient();
            var upsertpat = new Patient();
            
                string codes = "";
                

                switch (PatientDemoData.gender)
                {
                    case "Female":
                    case "female":
                        pat.Gender = AdministrativeGender.Female;
                        codes = codes + "\"" + "F" + "\"" + ",";
                        lstcodes = lstcodes + "\"" + "F" + "\"" + ",";
                        break;
                    case "Male":
                    case "male":
                        pat.Gender = AdministrativeGender.Male;
                        codes = codes + "\"" + "M" + "\"" + ",";
                        lstcodes = lstcodes + "\"" + "M" + "\"" + ",";
                        break;
                    case "Other":
                    case "other":
                        pat.Gender = AdministrativeGender.Other;
                        break;
                    default:
                        pat.Gender = AdministrativeGender.Unknown;
                        break;
                }
                HumanName phyname = new HumanName();
                List<HumanName> lsthumannames = new List<HumanName>();
                phyname.Text = PatientDemoData.name.FirstOrDefault().text;
                phyname.Family = PatientDemoData.name.FirstOrDefault().family.FirstOrDefault();
                List<FhirString> lstphygivenname = new List<FhirString>();
                FhirString phygn = new FhirString();
                phygn.SetStringExtension("https://www.hl7.org/fhir/datatypes.html#HumanName", PatientDemoData.name.FirstOrDefault().given.FirstOrDefault());
                lstphygivenname.Add(phygn);
                phyname.GivenElement = lstphygivenname;

                lsthumannames.Add(phyname);

                pat.Name = lsthumannames;

                pat.BirthDate = DateTime.Parse(PatientDemoData.birthDate).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                DateTime now = DateTime.Now;
                DateTime givenDate = DateTime.Parse(pat.BirthDate);
                int days = now.Subtract(givenDate).Days;
                int age = (int)Math.Floor(days / 365.24219);
                if (age > 5 && age < 17)
                    codes = codes + "\"" + "school" + "\"" + ",";
                lstcodes = lstcodes + "\"" + "school" + "\"" + ",";

                Address pataddress = new Address();
                switch (PatientDemoData.address.FirstOrDefault().use)
                {
                    case "Home":
                    case "home":
                        pataddress.Use = Address.AddressUse.Home;
                        break;
                    case "Billing":
                    case "billing":
                        pataddress.Use = Address.AddressUse.Billing;
                        break;
                    case "Old":
                    case "old":
                        pataddress.Use = Address.AddressUse.Old;
                        break;
                    case "Temp":
                    case "temp":
                        pataddress.Use = Address.AddressUse.Temp;
                        break;
                    case "Work":
                    case "work":
                        pataddress.Use = Address.AddressUse.Work;
                        break;
                    default:
                        pataddress.Use = Address.AddressUse.Home;
                        break;
                }

                pataddress.Text = PatientDemoData.address.FirstOrDefault().line.FirstOrDefault();
                pataddress.City = PatientDemoData.address.FirstOrDefault().city;
                pataddress.State = PatientDemoData.address.FirstOrDefault().state;
                pataddress.Country = PatientDemoData.address.FirstOrDefault().country;
                pataddress.PostalCode = PatientDemoData.address.FirstOrDefault().postalCode;
                List<Address> lstpataddr = new List<Address>();
                lstpataddr.Add(pataddress);
                pat.Address = lstpataddr;

                List<ContactPoint> lstcontact = new List<ContactPoint>();

                foreach (var tel in PatientDemoData.telecom)
                {
                    ContactPoint patMcontact = new ContactPoint();
                    //patMcontact.Value = tel.System.Value;
                    switch (tel.system)
                    {
                        case "Phone":
                        case "phone":
                            patMcontact.System = ContactPoint.ContactPointSystem.Phone;
                            patMcontact.Value = tel.value;
                            break;
                        case "email":
                        case "Email":
                            patMcontact.System = ContactPoint.ContactPointSystem.Email;
                            patMcontact.Value = tel.value;
                            break;
                        case "fax":
                        case "Fax":
                            patMcontact.System = ContactPoint.ContactPointSystem.Fax;
                            patMcontact.Value = tel.value;
                            break;
                        case "pager":
                        case "Pager":
                            patMcontact.System = ContactPoint.ContactPointSystem.Pager;
                            patMcontact.Value = tel.value;
                            break;
                        case "url":
                        case "URL":
                            patMcontact.System = ContactPoint.ContactPointSystem.Url;
                            patMcontact.Value = tel.value;
                            break;
                        default:
                            patMcontact.System = ContactPoint.ContactPointSystem.Other;
                            patMcontact.Value = tel.value;
                            break;
                    }
                    switch (tel.use)
                    {
                        case "Home":
                        case "home":
                            patMcontact.Use = ContactPoint.ContactPointUse.Home;
                            break;
                        case "Old":
                        case "old":
                            patMcontact.Use = ContactPoint.ContactPointUse.Old;
                            break;
                        case "Temp":
                        case "temp":
                            patMcontact.Use = ContactPoint.ContactPointUse.Temp;
                            break;
                        case "Work":
                        case "work":
                            patMcontact.Use = ContactPoint.ContactPointUse.Work;
                            break;
                        default:
                            patMcontact.Use = ContactPoint.ContactPointUse.Home;
                            break;
                    }

                    lstcontact.Add(patMcontact);
                }

                pat.Telecom = lstcontact;
                //Patient pat = null;
                var conditions = new SearchParams();
                conditions.Add("identifier", PatientDemoData.id);
                //Bundle results = client.Search<Patient>(new string[] { "family:exact="+familyname.Split(" ")[1] });
                Bundle results = client.Search<Patient>(conditions);
                if (results.Entry.Count > 0)
                {

                    var fhirpatientId = results.Entry[0].Resource.Id;
                    var location = new Uri(resource + "/Patient/" + fhirpatientId);
                    pat = client.Read<Patient>(location);

                    upsertpat = client.Update(pat);
                }
                else
                {
                    pat.Identifier.Add(new Identifier("RelientPatientID", PatientDemoData.id));
                    upsertpat = client.Create(pat);
                }
                //codes = codes.TrimEnd(',');
                //var strQuery = "SELECT c.Name,c.InfermedicaID FROM c IN t.ResourceType[6][\"Patient\"] WHERE c.Code IN(" + codes + ")";
                //var response = Utils.DBUtility.GetItemFromContainer(EndpointURI, PrimaryKey, strQuery, databaseId, containerId);
                //if (response.Result != null)
                //{
                //    var arrrisks = Utils.Extention.ConvertObjectToJson(response.Result).TrimStart('[').TrimEnd(']').Split("},");
                //    foreach (var val in arrrisks)
                //    {
                //        if (val.Contains("}"))
                //        {
                //            var riskobj = JsonConvert.DeserializeObject<Models.RiskFactors>(val);
                //            lstMappedIDs.Add(riskobj);
                //        }
                //        else
                //        {
                //            var riskobj = JsonConvert.DeserializeObject<Models.RiskFactors>(val + "}");
                //            lstMappedIDs.Add(riskobj);
                //        }

                //    }
                //}
                
          
            return upsertpat;
        }      
        public static async System.Threading.Tasks.Task CosmosCall(string codes,ILogger log)
        {
           //await System.Threading.Tasks.Task.Delay(500);
            Stopwatch DBtimer = Stopwatch.StartNew();
            codes = codes.TrimEnd(',');
            //log.LogInformation("All codes: " + codes);
            var strQuery = "SELECT c.Name,c.InfermedicaID FROM c IN t.Resource WHERE c.Code IN(" + codes + ")";

            var response = Utils.DBUtility.GetItemFromContainer(EndpointURI, PrimaryKey, strQuery, databaseId, containerId);

            if (response != null)
            {
                var arrrisks = Utils.Extention.ConvertObjectToJson(response).TrimStart('[').TrimEnd(']').Split("},");
                foreach (var val in arrrisks)
                {
                    if (val.Contains("}"))
                    {
                        var riskobj = JsonConvert.DeserializeObject<Models.RiskFactors>(val);
                        var existingcount = lstMappedIDs.Where(i => i.InfermedicaID == riskobj.InfermedicaID).Select(c => c.InfermedicaID).ToList().Count;
                        if (existingcount == 0)
                            lstMappedIDs.Add(riskobj);
                    }
                    else
                    {
                        var riskobj = JsonConvert.DeserializeObject<Models.RiskFactors>(val + "}");
                        var existingcount = lstMappedIDs.Where(i => i.InfermedicaID == riskobj.InfermedicaID).Select(c => c.InfermedicaID).ToList().Count;
                        if (existingcount == 0)
                            lstMappedIDs.Add(riskobj);
                    }

                }
            }

            clresponse.RiskFactors = lstMappedIDs;
            DBtimer.Stop();
            log.LogInformation("Database call Timer: " + DBtimer.Elapsed.TotalSeconds);
            Console.WriteLine("Database call Timer: " + DBtimer.Elapsed);
        }
        public static async Task<object> SavePatientClinicalSummary(Patient fhirPatient, string patientId, FhirClient client ,string token, string resource,ILogger log, CancellationToken cantoken,HttpClientEventHandler messageHandler)
        {
            //Task<bool> secondHandlerFinished = s_tcs.Task;
            
                         
                System.Threading.Tasks.Task t1 = System.Threading.Tasks.Task.Run(() => saveReliantAllergyDetails(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t2 = System.Threading.Tasks.Task.Run(() => SaveVitals(fhirPatient, patientId, client, "8310-5", token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t3 = System.Threading.Tasks.Task.Run(() => SaveLabs(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t4 = System.Threading.Tasks.Task.Run(() => SaveMedication(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t5 = System.Threading.Tasks.Task.Run(() => SaveSocialHistory(fhirPatient, patientId, client, "social-history", token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t6 = System.Threading.Tasks.Task.Run(() => saveImmunizations(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t7 = System.Threading.Tasks.Task.Run(() => SaveProblems(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));
                System.Threading.Tasks.Task t8 = System.Threading.Tasks.Task.Run(() => SaveFamilyHistory(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));
               // System.Threading.Tasks.Task t9 = System.Threading.Tasks.Task.Run(() => SaveSurgicalHistory(fhirPatient, patientId, client, token, resource, log, cantoken, messageHandler));

                await System.Threading.Tasks.Task.WhenAll(t1, t2, t3, t4, t5, t6, t7, t8);

            return new OkResult();
        }
                
        private static async Task<Models.ReliantAllergiesModel.ReliantAllergies> saveReliantAllergyDetails(Patient fhirPatient, string reliantPatientId, FhirClient client, string token, string resource,ILogger log,CancellationToken cantoken,HttpClientEventHandler messageHandler)
        {           
                Stopwatch Allergytimer = Stopwatch.StartNew();               
                FhirClient Allergyclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
                //Console.WriteLine("patient id"+fhirPatient.Id);
                Models.ReliantAllergiesModel.ReliantAllergies reliantAllergiesData = Utils.ReliantUtlity.getRelaintAllergies(reliantPatientId, token).Result;
            try
            {
                if(reliantAllergiesData != null)
                {
                    Bundle AllergiesBundle = new Bundle();
                    AllergiesBundle.Type = Bundle.BundleType.Collection;

                    foreach (var item in reliantAllergiesData.entry)
                    {
                        if (item.search.mode != "outcome")
                        {
                            AllergyIntolerance allergy = new AllergyIntolerance();
                            allergy.Patient = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            allergy.Meta = new Hl7.Fhir.Model.Meta { Profile = new List<string> { "http://hl7.org/fhir/StructureDefinition/daf-allergyintolerance" } };

                            if (item.resource.clinicalStatus.coding != null)
                            {
                                var cStatus = new CodeableConcept();
                                cStatus.Coding.Add(new Coding { Code = item.resource.clinicalStatus.coding[0].code, System = item.resource.clinicalStatus.coding[0].system, Version = item.resource.clinicalStatus.coding[0].version, Display = item.resource.clinicalStatus.coding[0].display });
                                allergy.ClinicalStatus = cStatus;
                            }
                            if (item.resource.verificationStatus.coding != null)
                            {
                                var cStatus = new CodeableConcept();
                                cStatus.Coding.Add(new Coding { Code = item.resource.verificationStatus.coding[0].code, System = item.resource.verificationStatus.coding[0].system, Version = item.resource.verificationStatus.coding[0].version, Display = item.resource.verificationStatus.coding[0].display });
                                allergy.ClinicalStatus = cStatus;
                            }
                            switch (item.resource.category[0])
                            {
                                case "food":
                                    allergy.CategoryElement.Add(new Code<AllergyIntolerance.AllergyIntoleranceCategory>(AllergyIntolerance.AllergyIntoleranceCategory.Food));
                                    break;

                                case "medication":
                                    allergy.CategoryElement.Add(new Code<AllergyIntolerance.AllergyIntoleranceCategory>(AllergyIntolerance.AllergyIntoleranceCategory.Medication));
                                    break;

                                case "environment":
                                    allergy.CategoryElement.Add(new Code<AllergyIntolerance.AllergyIntoleranceCategory>(AllergyIntolerance.AllergyIntoleranceCategory.Environment));
                                    break;

                                case "biologic":
                                    allergy.CategoryElement.Add(new Code<AllergyIntolerance.AllergyIntoleranceCategory>(AllergyIntolerance.AllergyIntoleranceCategory.Biologic));
                                    break;

                                default:
                                    allergy.CategoryElement.Add(new Code<AllergyIntolerance.AllergyIntoleranceCategory>(AllergyIntolerance.AllergyIntoleranceCategory.Medication));
                                    break;
                            }
                            var cCodes = new CodeableConcept();

                            foreach (var cdcode in item.resource.code.coding)
                            {
                                cCodes.Coding.Add(new Coding { Code = cdcode.code, Display = cdcode.display });
                                lstcodes = lstcodes + "\"" + cdcode.code + "\"" + ",";
                            }
                            allergy.Code = cCodes;
                            allergy.Code.Text = item.resource.code.text;

                            var manifestationList = new List<CodeableConcept>();
                            var reactionList = new List<AllergyIntolerance.ReactionComponent>();
                            AllergyIntolerance.ReactionComponent component = new AllergyIntolerance.ReactionComponent();
                            if (item.resource.reaction != null)
                            {
                                foreach (var mani in item.resource.reaction[0].manifestation)
                                {
                                    var rCode = new CodeableConcept();
                                    rCode.Text = mani.text;
                                    manifestationList.Add(rCode);
                                }

                            }
                            component.Manifestation = manifestationList;
                            component.Description = item.resource.reaction[0].description;
                            switch (item.resource.reaction[0].severity)
                            {
                                case "mild":
                                    component.Severity = AllergyIntolerance.AllergyIntoleranceSeverity.Mild;
                                    break;

                                case "moderate":
                                    component.Severity = AllergyIntolerance.AllergyIntoleranceSeverity.Moderate;
                                    break;

                                case "severe":
                                    component.Severity = AllergyIntolerance.AllergyIntoleranceSeverity.Severe;
                                    break;

                                default:
                                    component.Severity = AllergyIntolerance.AllergyIntoleranceSeverity.Mild;
                                    break;
                            }
                            reactionList.Add(component);
                            allergy.Reaction = reactionList;
                            allergy.RecordedDate = item.resource.recordedDate;
                            await System.Threading.Tasks.Task.Delay(150);
                            var allintol = Allergyclient.Create(allergy);
                            //s_tcs.SetResult(true);
                            //Console.WriteLine("allintol.Id->" + allintol.Id);
                            AllergiesBundle.AddResourceEntry(allergy, resource + "/AllergyIntolerance/" + allintol.Id);
                            //Console.WriteLine("AllergiesBundle" + AllergiesBundle);

                        }

                    }
                    var bundleId = Allergyclient.Create(AllergiesBundle);
                    //Console.WriteLine("bundleId->"+ bundleId);
                    fhirPatient.Identifier.Add(new Identifier("AllergiesBundle", bundleId.Id));
                    var updated_pat = Allergyclient.Update(fhirPatient);
                    Allergytimer.Stop();
                    log.LogInformation("Allergy call: " + Allergytimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
            }
             catch(Exception ex)
            {
                log.LogInformation("Allergy call: "+ex.Message);
            }
            

            return reliantAllergiesData; 
        }


        private static async Task<Models.ReliantVitalsResponse.ReliantVitalsDetail> SaveVitals(Patient fhirPatient, string reliantPatientId, FhirClient client, string code, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {
            Stopwatch Vitalstimer = Stopwatch.StartNew();
            FhirClient Vitalsclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
            {
                PreferredFormat = ResourceFormat.Json
            });

            Models.ReliantVitalsResponse.ReliantVitalsDetail data = Utils.ReliantUtlity.GetReliantVitals(code, reliantToken, reliantPatientId,cantoken,log).Result;
            try
            {
                Bundle vitalsBundle = new Bundle();
                vitalsBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var item in data.entry)
                    {

                        if (item.search.mode != "outcome")
                        {
                            var vital = new Observation();
                            vital.Subject = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            vital.Status = ObservationStatus.Final;
                            vital.Meta = new Meta { Profile = new List<string> { "http://hl7.org/fhir/StructureDefinition/daf-vitalsigns" } };

                            List<Observation.ComponentComponent> lstobservecmp = new List<Observation.ComponentComponent>();
                            if (item.resource.component != null)
                            {
                                Observation.ComponentComponent observecmp = new Observation.ComponentComponent();
                                var ccComponents = new CodeableConcept();
                                foreach (var comp in item.resource.component)
                                {
                                    foreach (var val in comp.code.coding)
                                    {
                                        ccComponents.Coding.Add(new Coding { Code = val.code, System = val.system, Display = val.display });
                                    }
                                    if (item.resource.code.text == "Temperature")
                                        observecmp.Value = new Quantity { Value = comp.valueQuantity.value, Unit = comp.valueQuantity.unit, System = comp.valueQuantity.system, Code = comp.valueQuantity.code };
                                    else
                                        observecmp.Value = new Quantity { Value = Convert.ToDecimal(comp.valueQuantity.value), Unit = comp.valueQuantity.unit, System = comp.valueQuantity.system, Code = comp.valueQuantity.code };
                                }
                                observecmp.Code = ccComponents;
                                lstobservecmp.Add(observecmp);
                            }
                            vital.Component = lstobservecmp;
                            var ccCode = new CodeableConcept();
                            foreach (var val in item.resource.code.coding)
                            {
                                ccCode.Coding.Add(new Coding { Code = val.code, System = val.system, Display = val.display });
                                lstcodes = lstcodes + "\"" + val.code + "\"" + ",";
                            }
                            ccCode.Text = item.resource.code.text;
                            vital.Code = ccCode;

                            //vital.Value = new Quantity { Value = Convert.ToDecimal(item.resource.valueQuantity.value), Unit = item.resource.valueQuantity.unit };
                            var performer = new List<Hl7.Fhir.Model.ResourceReference>();
                            foreach (var dis in item.resource.performer)
                            {
                                performer.Add(new ResourceReference { Display = dis.display });
                            }
                            vital.Performer = performer;
                            vital.Effective = new FhirDateTime(Convert.ToDateTime(item.resource.effectiveDateTime));
                            vital.Issued = Convert.ToDateTime(item.resource.issued);
                            await System.Threading.Tasks.Task.Delay(150);
                            var obs = Vitalsclient.Create(vital);
                            //s_tcs.SetResult(true);
                            vitalsBundle.AddResourceEntry(vital, "Observation/" + obs.Id);
                        }
                    }
                    var bundleId = Vitalsclient.Create(vitalsBundle);
                    fhirPatient.Identifier.Add(new Identifier("vitalsBundle", bundleId.Id));
                    var updated_pat = Vitalsclient.Update(fhirPatient);

                    Vitalstimer.Stop();
                    log.LogInformation("Vitals call: " + Vitalstimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
               
            }           
           catch (Exception ex)
            {
                log.LogInformation("Vitals call: " +ex.Message);
            }
           
            
            return data;
        }

        private static async Task<Models.ReliantLabsModel.ReliantLabsResponse> SaveLabs(Patient fhirPatient, string reliantPatientId, FhirClient client, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {
           
                Stopwatch Labsstimer = Stopwatch.StartNew();
                FhirClient Labsclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
                //Console.WriteLine("pid->" + reliantPatientId);
                Models.ReliantLabsModel.ReliantLabsResponse data = Utils.ReliantUtlity.GetReliantLabs(reliantPatientId, reliantToken).Result;
            try
            {
                Bundle labsBundle = new Bundle();
                labsBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var item in data.entry)
                    {
                        if (item.search.mode != "outcome")
                        {
                            Observation labs = new Observation();
                            labs.Subject = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            //if (item.resource.status == "final") labs.Status = ObservationStatus.Final;

                            switch (item.resource.status)
                            {
                                case "final":
                                    labs.Status = ObservationStatus.Final;
                                    break;

                                case "registered":
                                    labs.Status = ObservationStatus.Registered;
                                    break;

                                case "preliminary":
                                    labs.Status = ObservationStatus.Preliminary;
                                    break;

                                case "amended":
                                    labs.Status = ObservationStatus.Amended;
                                    break;
                            }

                            var cat = new CodeableConcept();

                            foreach (var c in item.resource.category.coding)
                            {
                                cat.Coding.Add(new Coding { Code = c.code, System = c.system, Display = c.display });
                            }
                            cat.Text = item.resource.category.text;
                            labs.Category.Add(cat);

                            if (item.resource.code.text != null)
                            {
                                var ccode = new CodeableConcept();
                                ccode.Text = item.resource.code.text;
                                labs.Code = ccode;
                            }

                            labs.Effective = new FhirDateTime(Convert.ToDateTime(item.resource.effectiveDateTime));

                            if (item.resource.valueString != null)
                            {
                                labs.Value = new FhirString(item.resource.valueString);
                            }
                            else
                            {
                                labs.Value = new Quantity { Value = Convert.ToDecimal(item.resource.valueQuantity.value), Unit = item.resource.valueQuantity.unit != null ? item.resource.valueQuantity.unit : "" };
                            }

                            if (item.resource.interpretation != null)
                            {
                                var icode = new CodeableConcept();
                                icode.Coding.Add(new Coding { System = item.resource.interpretation.coding[0].system, Code = item.resource.interpretation.coding[0].code, Display = item.resource.interpretation.coding[0].display });
                                icode.Text = item.resource.interpretation.text;
                                labs.Interpretation.Add(icode);
                            }
                            await System.Threading.Tasks.Task.Delay(150);
                            var labsObs = Labsclient.Create(labs);
                            //s_tcs.SetResult(true);
                            labsBundle.AddResourceEntry(labs, resource + "/Observation/" + labsObs.Id);
                        }

                    }
                    var bundleId = Labsclient.Create(labsBundle);
                    fhirPatient.Identifier.Add(new Identifier("labsBundle", bundleId.Id));
                    var updated_pat = Labsclient.Update(fhirPatient);
                    Labsstimer.Stop();
                    log.LogInformation("LabsTimer: " + Labsstimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
                
            }
            catch(Exception ex)
            {
                log.LogInformation("Labs call: "+ex.Message);
            }
            
            return data;
        }

        private static async Task<Models.MedicationStatementModel.MedicationStatementDetails> SaveMedication(Patient fhirPatient, string reliantPatientId, FhirClient client, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {

           
                Stopwatch Medicationtimer = Stopwatch.StartNew();
                FhirClient Medicationclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
               
                //Console.WriteLine("pid->" + reliantPatientId);
                Models.MedicationStatementModel.MedicationStatementDetails data = Utils.ReliantUtlity.GetReliantMedicationStatement(reliantPatientId, reliantToken,cantoken).Result;
            try
            {
                Bundle MedicationBundle = new Bundle();
                MedicationBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var item in data.entry)
                    {
                        if (item.search.mode != "outcome")
                        {
                            MedicationStatement ReliantMedStatement = new MedicationStatement();
                            ReliantMedStatement.Subject = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            List<Identifier> lstiden = new List<Identifier>();
                            foreach (var idents in item.resource.identifier)
                            {
                                Identifier iden = new Identifier();
                                switch (idents.use)
                                {
                                    case "usual":
                                    case "Usual":
                                        iden.Use = Identifier.IdentifierUse.Usual;
                                        break;
                                    case "Old":
                                    case "old":
                                        iden.Use = Identifier.IdentifierUse.Old;
                                        break;
                                    case "official":
                                    case "Official":
                                        iden.Use = Identifier.IdentifierUse.Official;
                                        break;
                                    case "secondary":
                                    case "Secondary":
                                        iden.Use = Identifier.IdentifierUse.Secondary;
                                        break;
                                    case "temp":
                                    case "Temp":
                                        iden.Use = Identifier.IdentifierUse.Temp;
                                        break;
                                    default:
                                        iden.Use = Identifier.IdentifierUse.Old;
                                        break;
                                }
                                iden.Value = idents.value;
                                lstiden.Add(iden);
                            }
                            ReliantMedStatement.Identifier = lstiden;
                            switch (item.resource.status)
                            {
                                case "active":
                                case "Active":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.Active;
                                    break;
                                case "completed":
                                case "Completed":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.Completed;
                                    break;
                                case "stopped":
                                case "Stopped":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.Stopped;
                                    break;
                                case "intended":
                                case "Intended":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.Intended;
                                    break;
                                case "Entered-In-Error":
                                case "entered-in-error":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.EnteredInError;
                                    break;
                                case "on-hold":
                                case "On-Hold":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.OnHold;
                                    break;
                                case "not-taken":
                                case "Not-Taken":
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.NotTaken;
                                    break;
                                default:
                                    ReliantMedStatement.Status = MedicationStatement.MedicationStatusCodes.Unknown;
                                    break;
                            }

                            CodeableConcept ccMedication = new CodeableConcept();
                            ccMedication.Text = item.resource.medicationCodeableConcept.text;
                            ccMedication.Coding.Add(new Coding { System = item.resource.medicationCodeableConcept.coding.FirstOrDefault().system, Code = item.resource.medicationCodeableConcept.coding[0].code, Display = item.resource.medicationCodeableConcept.coding[0].display });

                            lstcodes = lstcodes + "\"" + item.resource.medicationCodeableConcept.coding[0].code + "\"" + ",";

                            ReliantMedStatement.Medication = ccMedication;
                            List<Dosage> lstReliantDosage = new List<Dosage>();
                            foreach (var doses in item.resource.dosage)
                            {
                                Dosage dose = new Dosage();
                                Extension extdose = new Extension();
                                extdose.Url = item.resource.dosage.FirstOrDefault().extension.FirstOrDefault().url;
                                Quantity quan = new Quantity();
                                quan.Unit = item.resource.dosage.FirstOrDefault().extension.FirstOrDefault().valueQuantity.unit;
                                quan.Value = item.resource.dosage.FirstOrDefault().extension.FirstOrDefault().valueQuantity.value;
                                extdose.Value = quan;
                                dose.Extension.Add(extdose);

                                dose.Text = item.resource.dosage.FirstOrDefault().text;
                                Timing dosetime = new Timing();
                                Timing.RepeatComponent timerepeat = new Timing.RepeatComponent();

                                timerepeat.Frequency = item.resource.dosage.FirstOrDefault().timing.repeat.frequency;
                                timerepeat.Period = item.resource.dosage.FirstOrDefault().timing.repeat.period;

                                switch (item.resource.dosage.FirstOrDefault().timing.repeat.periodUnits)
                                {
                                    case "A":
                                    case "a":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.A;
                                        break;
                                    case "s":
                                    case "S":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.S;
                                        break;
                                    case "h":
                                    case "H":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.H;
                                        break;
                                    case "d":
                                    case "D":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.D;
                                        break;
                                    case "Min":
                                    case "min":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.Min;
                                        break;
                                    case "WK":
                                    case "wk":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.Wk;
                                        break;
                                    case "Mo":
                                    case "mo":
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.Mo;
                                        break;
                                    default:
                                        timerepeat.PeriodUnit = Timing.UnitsOfTime.H;
                                        break;
                                }
                                CodeableConcept cddosetime = new CodeableConcept();
                                cddosetime.Text = item.resource.dosage.FirstOrDefault().timing.code.text;
                                dosetime.Code = cddosetime;

                                dosetime.Repeat = timerepeat;
                                dose.Timing = dosetime;

                                FhirBoolean asNeededBoolean = new FhirBoolean();
                                asNeededBoolean.Value = item.resource.dosage.FirstOrDefault().asNeededBoolean;
                                dose.AsNeeded = asNeededBoolean;


                                CodeableConcept ccRoute = new CodeableConcept();
                                ccRoute.Text = item.resource.dosage.FirstOrDefault().route.text;
                                ccRoute.Coding.Add(new Coding { Code = item.resource.dosage.FirstOrDefault().route.coding[0].code, Display = item.resource.dosage.FirstOrDefault().route.coding[0].display });

                                dose.Route = ccRoute;
                                if (item.resource.dosage.FirstOrDefault().method != null)
                                {
                                    CodeableConcept ccmethod = new CodeableConcept();
                                    ccmethod.Text = item.resource.dosage.FirstOrDefault().method.text;
                                    ccmethod.Coding.Add(new Coding { Code = item.resource.dosage.FirstOrDefault().method.coding[0].code, Display = item.resource.dosage.FirstOrDefault().method.coding[0].display });

                                    dose.Method = ccmethod;
                                }

                                lstReliantDosage.Add(dose);
                            }
                            ReliantMedStatement.Dosage = lstReliantDosage;
                            await System.Threading.Tasks.Task.Delay(150);
                            var MedState = Medicationclient.Create(ReliantMedStatement);
                            //s_tcs.SetResult(true);
                            MedicationBundle.AddResourceEntry(ReliantMedStatement, resource + "/MedicationStatement/" + MedState.Id);
                        }
                    }

                    var bundleId = Medicationclient.Create(MedicationBundle);
                    fhirPatient.Identifier.Add(new Identifier("MedicationBundle", bundleId.Id));
                    var updated_pat = Medicationclient.Update(fhirPatient);
                    Medicationtimer.Stop();
                    log.LogInformation("Medicationtimer call: " + Medicationtimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
               
            }
             catch(Exception ex)
            {
                log.LogInformation("Medication call:"+ ex.Message);
            }
            
            return data;
        }

        private static async Task<Models.ReliantSocialHistoryResponse.ReliantSocial> SaveSocialHistory(Patient fhirPatient, string reliantPatientId, FhirClient client, string code, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {
           
                Stopwatch SocialHistorytimer = Stopwatch.StartNew();
                FhirClient SocialHistoryclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
               
                Models.ReliantSocialHistoryResponse.ReliantSocial data = Utils.ReliantUtlity.GetReliantSocial(code, reliantToken, reliantPatientId).Result;
            try
            {
                Bundle SocialHistoryBundle = new Bundle();
                SocialHistoryBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var item in data.entry)
                    {
                        if (item.search.mode != "outcome")
                        {
                            var social = new Observation();
                            social.Status = ObservationStatus.Final;
                            var category = new CodeableConcept();
                            if (item.resource.category[0].coding != null)
                            {
                                foreach (var val in item.resource.category[0].coding)
                                {
                                    category.Coding.Add(new Coding { System = val.system, Code = val.code, Display = val.display });

                                }
                            }
                            category.Text = item.resource.category[0].text;
                            social.Category.Add(category);
                            var ccCode = new CodeableConcept();
                            if (item.resource.code.coding != null)
                            {
                                foreach (var val in item.resource.code.coding)
                                {
                                    ccCode.Coding.Add(new Coding { System = val.system, Code = val.code, Display = val.display });
                                    lstcodes = lstcodes + "\"" + val.code + "\"" + ",";
                                }
                            }
                            ccCode.Text = item.resource.code.text;
                            social.Code = ccCode;
                            social.Subject = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            var eff = new Period();
                            eff.Start = item.resource.effectivePeriod.start;

                            social.Effective = eff;
                            var valCC = new CodeableConcept();
                            foreach (var val in item.resource.valueCodeableConcept.coding)
                            {
                                valCC.Coding.Add(new Coding { System = val.system, Code = val.code, Display = val.display });
                                lstcodes = lstcodes + "\"" + val.code + "\"" + ",";
                            }
                            valCC.Text = item.resource.valueCodeableConcept.text;
                            social.Value = valCC;
                            await System.Threading.Tasks.Task.Delay(150);
                            var obs = SocialHistoryclient.Create(social);
                            // s_tcs.SetResult(true);
                            SocialHistoryBundle.AddResourceEntry(social, "Observation/" + obs.Id);
                        }
                    }

                    var bundleId = SocialHistoryclient.Create(SocialHistoryBundle);
                    fhirPatient.Identifier.Add(new Identifier("SocialHistoryBundle", bundleId.Id));
                    var updated_pat = SocialHistoryclient.Update(fhirPatient);

                    SocialHistorytimer.Stop();
                    log.LogInformation("SocialHistory call: " + SocialHistorytimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
                
            }
            catch(Exception ex)
            {
                log.LogInformation("Social call:" + ex.Message);
            }                
            
            return data;
        }

        private static async Task<Models.ReliantFamilyHistoryModel.FamilyHistory> SaveFamilyHistory(Patient fhirPatient, string reliantPatientId, FhirClient client, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {
           
                Stopwatch FamilyHistorytimer = Stopwatch.StartNew();
                FhirClient FamilyHistoryclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
               
                Models.ReliantFamilyHistoryModel.FamilyHistory data = Utils.ReliantUtlity.GetFamilyHistory(reliantToken, reliantPatientId).Result;
            try
            {
                Bundle famBundle = new Bundle();
                famBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var item in data.entry)
                    {
                        if (item.search.mode != "outcome")
                        {
                            var fam = new FamilyMemberHistory();

                            fam.DateElement = new FhirDateTime(Convert.ToDateTime(item.resource.date));
                            switch (item.resource.status)
                            {
                                case "completed":
                                    fam.Status = FamilyMemberHistory.FamilyHistoryStatus.Completed;
                                    break;
                                case "partial":
                                    fam.Status = FamilyMemberHistory.FamilyHistoryStatus.Partial;
                                    break;

                            }
                            fam.Patient = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));

                            fam.Name = item.resource.name;

                            var relation = new CodeableConcept();
                            if (item.resource.relationship.coding != null)
                            {
                                foreach (var cc in item.resource.relationship.coding)
                                {
                                    relation.Coding.Add(new Coding { Code = cc.code, Display = cc.display });
                                }
                            }
                            relation.Text = item.resource.relationship.text;
                            fam.Relationship = relation;

                            fam.Deceased = new FhirBoolean(item.resource.deceasedBoolean);

                            if (item.resource.condition != null)
                            {
                                if (item.resource.condition.Count == 1)
                                {
                                    var condition = new FamilyMemberHistory.ConditionComponent();
                                    var cond = item.resource.condition[0];

                                    var ccCode = new CodeableConcept();
                                    ccCode.Text = cond.code.text;

                                    lstcodes = lstcodes + "\"" + cond.code.text + "\"" + ",";
                                    condition.Code = ccCode;

                                    var note = new Annotation();
                                    note.Text = new Markdown(cond.code.text);
                                    condition.Note.Add(note);

                                    condition.Onset = new FhirString(cond.onsetString);

                                    fam.Condition.Add(condition);
                                }

                            }
                            await System.Threading.Tasks.Task.Delay(150);
                            var famId = FamilyHistoryclient.Create(fam);
                            //s_tcs.SetResult(true);
                            famBundle.AddResourceEntry(fam, resource + "/FamilyMemberHistory/" + famId.Id);
                        }

                    }
                    var bundleId = FamilyHistoryclient.Create(famBundle);
                    fhirPatient.Identifier.Add(new Identifier("FamilyHistoryBundle", bundleId.Id));
                    var updated_pat = FamilyHistoryclient.Update(fhirPatient);
                    FamilyHistorytimer.Stop();
                    log.LogInformation("FamilyHistory call: " + FamilyHistorytimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }

               
            }
            catch(Exception ex)
            {
                log.LogInformation("Family call:" + ex.Message);
            }
           
            return data;
        }

        private static async Task<Models.ReliantImmunizationsModel.Immunizations> saveImmunizations(Patient fhirPatient, string reliantPatientId, FhirClient client, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {
           
                Stopwatch Immunizationstimer = Stopwatch.StartNew();
                FhirClient Immunizationsclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });                

                Models.ReliantImmunizationsModel.Immunizations data = Utils.ReliantUtlity.GetReliantImmunizations(reliantPatientId, reliantToken,log).Result;
            try
            {
                Bundle immBundle = new Bundle();
                immBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var item in data.entry)
                    {
                        if (item.search.mode != "outcome")
                        {
                            Immunization imm = new Immunization();
                            imm.Patient = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            if (item.resource.identifier[0].use != null)
                            {
                                switch (item.resource.identifier[0].use.ToLower())
                                {
                                    case "official":
                                        imm.Identifier.Add(new Identifier { Use = Hl7.Fhir.Model.Identifier.IdentifierUse.Official, Value = item.resource.identifier[0].value });
                                        break;

                                    case "usual":
                                        imm.Identifier.Add(new Identifier { Use = Hl7.Fhir.Model.Identifier.IdentifierUse.Usual, Value = item.resource.identifier[0].value });
                                        break;

                                    case "old":
                                        imm.Identifier.Add(new Identifier { Use = Hl7.Fhir.Model.Identifier.IdentifierUse.Old, Value = item.resource.identifier[0].value });
                                        break;

                                    case "temp":
                                        imm.Identifier.Add(new Identifier { Use = Hl7.Fhir.Model.Identifier.IdentifierUse.Temp, Value = item.resource.identifier[0].value });
                                        break;

                                    case "secondary":
                                        imm.Identifier.Add(new Identifier { Use = Hl7.Fhir.Model.Identifier.IdentifierUse.Secondary, Value = item.resource.identifier[0].value });
                                        break;
                                }
                            }


                            if (item.resource.status != null)
                            {
                                switch (item.resource.status.ToLower())
                                {
                                    case "completed":
                                        imm.Status = Immunization.ImmunizationStatusCodes.Completed;
                                        break;

                                    case "entered-in-error":
                                        imm.Status = Immunization.ImmunizationStatusCodes.EnteredInError;
                                        break;

                                    case "not-done":
                                        imm.Status = Immunization.ImmunizationStatusCodes.NotDone;
                                        break;
                                }
                            }

                            DateTime now = DateTime.Now;
                            DateTime givenDate = DateTime.Parse(item.resource.occurrenceDateTime);
                            int days = now.Subtract(givenDate).Days;
                            int tetanusyears = (int)Math.Floor(days / 365.24219);
                            if (tetanusyears > 5)
                                lstcodes = lstcodes + "\"" + "5 y" + "\"" + ",";

                            if (item.resource.occurrenceDateTime != null) imm.Occurrence = new FhirDateTime(Convert.ToDateTime(item.resource.occurrenceDateTime));

                            if (item.resource.vaccineCode != null)
                            {
                                var cc = new CodeableConcept();
                                if (item.resource.vaccineCode.text != null)
                                {
                                    cc.Text = item.resource.vaccineCode.text;

                                    lstcodes = lstcodes + "\"" + item.resource.vaccineCode.text + "\"" + ",";
                                }
                                if (item.resource.vaccineCode.coding != null)
                                {
                                    cc.Coding.Add(new Coding { Code = item.resource.vaccineCode.coding[0].code, System = item.resource.vaccineCode.coding[0].system, Display = item.resource.vaccineCode.coding[0].display });

                                    lstcodes = lstcodes + "\"" + item.resource.vaccineCode.coding[0].code + "\"" + ",";
                                }
                                imm.VaccineCode = cc;
                            }

                            imm.PrimarySource = item.resource.primarySource;
                            await System.Threading.Tasks.Task.Delay(150);
                            var immResource = Immunizationsclient.Create(imm);
                            //s_tcs.SetResult(true);
                            immBundle.AddResourceEntry(imm, resource + "/Immunization/" + immResource.Id);

                        }
                    }

                    var bundleId = Immunizationsclient.Create(immBundle);
                    fhirPatient.Identifier.Add(new Identifier("ImmunizationBundle", bundleId.Id));
                    var updated_pat = Immunizationsclient.Update(fhirPatient);
                    Immunizationstimer.Stop();
                    log.LogInformation("Immunizations call: " + Immunizationstimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
               
            }
             catch(Exception ex)
            {
                log.LogInformation("Immunizations call:" + ex.Message);
            }

                return data;
            }
       
        private static async Task<Models.ReliantProblemsModel.ReliantProblemsResponse> SaveProblems(Patient fhirPatient, string reliantPatientId, FhirClient client, string reliantToken, string resource, ILogger log, CancellationToken cantoken, HttpClientEventHandler messageHandler)
        {
           
                Stopwatch Problemstimer = Stopwatch.StartNew();
                FhirClient Problemsclient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });
                
                Models.ReliantProblemsModel.ReliantProblemsResponse data = Utils.ReliantUtlity.GetReliantProblems(reliantPatientId, reliantToken).Result;
            try
            {
                Bundle ProblemsBundle = new Bundle();
                ProblemsBundle.Type = Bundle.BundleType.Collection;
                if(data!=null)
                {
                    foreach (var entry in data.entry)
                    {
                        if (entry.search.mode != "outcome")
                        {
                            Condition problem = new Condition();
                            problem.Subject = new ResourceReference(string.Format(resource + "/Patient/" + fhirPatient.Id));
                            problem.RecordedDate = entry.resource.recordedDate;

                            var ccClinicalStatus = new CodeableConcept();
                            foreach (var coding in entry.resource.clinicalStatus.coding)
                            {
                                ccClinicalStatus.Coding.Add(new Coding { Code = coding.code, Display = coding.display });
                            }
                            ccClinicalStatus.Text = entry.resource.clinicalStatus.text;
                            problem.ClinicalStatus = ccClinicalStatus;


                            var ccVerificationStatus = new CodeableConcept();
                            foreach (var coding in entry.resource.verificationStatus.coding)
                            {
                                ccVerificationStatus.Coding.Add(new Coding { Code = coding.code, Display = coding.display });
                            }
                            ccVerificationStatus.Text = entry.resource.verificationStatus.text;
                            problem.VerificationStatus = ccVerificationStatus;


                            var ccCode = new CodeableConcept();
                            foreach (var coding in entry.resource.code.coding)
                            {
                                if (coding.system == "urn:oid:2.16.840.1.113883.6.90")
                                {
                                    ccCode.Coding.Add(new Coding { Code = coding.code, Display = "ICDCode" });
                                    lstcodes = lstcodes + "\"" + coding.code + "\"" + ",";
                                }

                                if (coding.system == "urn:oid:2.16.840.1.113883.6.96")
                                {
                                    ccCode.Coding.Add(new Coding { Code = coding.code, Display = "RxNorm" });
                                    lstcodes = lstcodes + "\"" + coding.code + "\"" + ",";
                                }

                            }
                            ccCode.Text = entry.resource.code.text;
                            problem.Code = ccCode;


                            var ccCatList = new List<CodeableConcept>();
                            foreach (var category in entry.resource.category)
                            {
                                var ccCat = new CodeableConcept();
                                foreach (var coding in category.coding)
                                {
                                    if (coding.system.Contains("loinc"))
                                        ccCat.Coding.Add(new Coding { Code = coding.code, Display = "Loinc" });

                                    lstcodes = lstcodes + "\"" + coding.code + "\"" + ",";
                                }
                                ccCat.Text = category.text;

                                ccCatList.Add(ccCat);

                            }
                            problem.Category = ccCatList;

                            await System.Threading.Tasks.Task.Delay(150);
                            var conditionObj = Problemsclient.Create(problem);
                            //s_tcs.SetResult(true);
                            ProblemsBundle.AddResourceEntry(problem, resource + "/Condition/" + conditionObj.Id);
                        }
                    }
                    var bundleId = Problemsclient.Create(ProblemsBundle);
                    fhirPatient.Identifier.Add(new Identifier("ProblemsBundle", bundleId.Id));
                    var updated_pat = Problemsclient.Update(fhirPatient);
                    Problemstimer.Stop();
                    log.LogInformation("Problems call: " + Problemstimer.Elapsed.TotalSeconds);
                }
                else
                {
                    log.LogInformation("Data coming back from epic as null");
                }
                
            }
             catch(Exception ex)
            {
                log.LogInformation("Problems call:" + ex.Message);
            }
            
            return data;
        }
    }
}

