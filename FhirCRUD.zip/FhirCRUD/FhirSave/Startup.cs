﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

//[assembly: FunctionsStartup(typeof(FhirCRUD.Startup))]
namespace FhirCRUD
{
    public class Startup : FunctionsStartup
    {
        //public IConfiguration Configuration { get; set; }
        public override void Configure(IFunctionsHostBuilder builder)
        {
            //var executioncontextoptions = builder.Services.BuildServiceProvider().GetService<IOptions<ExecutionContextOptions>>().Value;
            //_ = executioncontextoptions.AppDirectory;
            //Configuration = new ConfigurationBuilder()
            //             .SetBasePath(currentDirectory)
            //             .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            //             .AddEnvironmentVariables()                        
            //             .Build();
            builder.Services.AddLogging();
            //builder.Services.AddSingleton(typeof(IConfiguration), Configuration);
        }
    }
}
