﻿using RestSharp;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace FhirSave
{

		public static string GetBearerToken(ILogger log)
		{
			//return GetBearerTokenDirect(log);

			var clientSecret = Utils.ReliantUtlity.GetEnvironmentVariable("Client_Secret");
            var clientId = Utils.ReliantUtlity.GetEnvironmentVariable("Client_Id");
            var grantType = Utils.ReliantUtlity.GetEnvironmentVariable("Grant_Type");
            var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
            var tenantId = Utils.ReliantUtlity.GetEnvironmentVariable("Tenant_Id");


            //var tenantId = "db05faca-c82a-4b9d-b9c5-0f64b6755421";

            log.LogInformation(clientSecret);

			var authUrl = string.Format("https://login.microsoftonline.com/{0}/oauth2/token", tenantId);
			var client = new RestClient(authUrl);
			var request = new RestRequest(Method.POST);

			request.AddParameter("grant_type", grantType);
			request.AddParameter("client_id", clientId);
			request.AddParameter("client_secret", clientSecret);
			request.AddParameter("resource", resource);

			IRestResponse fhirTokenResponse = client.Execute(request);
			//var fhirTokenResponse = fhirTokenClient.Execute<FhirBearerToken>(request);		

			//string jsonData = JsonConvert.DeserializeObject<string>(fhirTokenResponse.Content);
			var jObject = JsonConvert.DeserializeObject<FhirBearerToken>(fhirTokenResponse.Content);

			return jObject.access_token;
		}

		public static string GetBearerTokenDirect(ILogger log)
		{
			var clientSecret = Utils.ReliantUtlity.GetEnvironmentVariable("Client_Secret");
			var clientId = Utils.ReliantUtlity.GetEnvironmentVariable("Client_Id");
			var grantType = Utils.ReliantUtlity.GetEnvironmentVariable("Grant_Type");
			var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
			var tenantId = Utils.ReliantUtlity.GetEnvironmentVariable("Tenant_Id");

			var authUrl = string.Format("https://getfhirtokentst.azurewebsites.net/api/GetFhirToken?code=HfL4FEW16bkGW8zrZlCO4gVCz98Clsy07OAr9d8OfBWfzX3LlqJfkw==");
			var client = new RestClient(authUrl);
			var request = new RestRequest(Method.GET);

			IRestResponse fhirTokenResponse = client.Execute(request);
			fhirTokenResponse.Content = fhirTokenResponse.Content.Replace("\\\"", "\"").TrimStart('\"').TrimEnd('\"');
			var jObject = JsonConvert.DeserializeObject<FhirBearerToken>(fhirTokenResponse.Content);

			return jObject.access_token;
		}
	}

	public class FhirBearerToken
	{
		public string token_type { get; set; }
		public string expires_in { get; set; }
		public string ext_expires_in { get; set; }
		public string expires_on { get; set; }
		public string not_before { get; set; }
		public string resource { get; set; }
		public string access_token { get; set; }
	}
}
