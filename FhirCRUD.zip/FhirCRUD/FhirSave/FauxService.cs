using System;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;

namespace FhirSave
{
    public class FauxService
    {
        [FunctionName("FauxService")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "patient/mock")] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            try
            {
                var EndpointURI = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBEndpoint");
                var keyVaultResp = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBKey");
                var PrimaryKey = keyVaultResp;
               

                string databaseId = Utils.ReliantUtlity.GetEnvironmentVariable("FauxDatabaseName");
                string containerId = Utils.ReliantUtlity.GetEnvironmentVariable("FauxContainerName");


                object data = null;
                var options = new CosmosClientOptions() { ConnectionMode = ConnectionMode.Gateway };
                var cosmosClient = new CosmosClient(EndpointURI, PrimaryKey, options);

                var container = cosmosClient.GetContainer(databaseId, containerId);
                var sqlQueryText = "SELECT * FROM c";
                QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
                FeedIterator<object> queryResultSetIterator = container.GetItemQueryIterator<object>(queryDefinition);

                FeedResponse<object> currentResultSet = await queryResultSetIterator.ReadNextAsync();


                
                foreach (var item in currentResultSet)
                    data = item;
                //var data = await Utils.DBUtility.GetItemFromContainer(EndpointURI, PrimaryKey, sqlQueryText, databaseId, containerId);
                
                return new OkObjectResult(data);

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }
    }
}