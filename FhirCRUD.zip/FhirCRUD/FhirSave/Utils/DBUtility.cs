﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.EventHubs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace FhirSave.Utils
{
    public class DBUtility
    {
        
        public static string env = Utils.ReliantUtlity.GetEnvironmentVariable("AGG_ID");       
        //public static string env = "FHIRService-Dev";
        public static object GetItemFromContainer(string EndpointURI, string PrimaryKey, string query, string databaseId, string containerId)
        {
            object data = null;
            var options = new CosmosClientOptions() { ConnectionMode = ConnectionMode.Gateway };
            var cosmosClient = new CosmosClient(EndpointURI, PrimaryKey, options);

            var container = cosmosClient.GetContainer(databaseId, containerId);

            QueryDefinition queryDefinition = new QueryDefinition(query);
            FeedIterator<object> queryResultSetIterator = container.GetItemQueryIterator<object>(queryDefinition);

            //FeedResponse<object> currentResultSet =await queryResultSetIterator.ReadNextAsync();

            while (queryResultSetIterator.HasMoreResults)
            {
                var task = queryResultSetIterator.ReadNextAsync();
                task.Wait();
                FeedResponse<object> currentResultSet = task.Result;
                if (currentResultSet.Count > 0)
                {
                    data = currentResultSet;
                }
            }

            //foreach (var item in currentResultSet)
            //    data = item;

            return data;
        }

        public static CosmosClient CreateCosmosClient(string EndpointURI, string PrimaryKey)
        {
            var options = new CosmosClientOptions();
            options.ConnectionMode = ConnectionMode.Gateway;
            var cosmosClient = new CosmosClient(EndpointURI, PrimaryKey, options);

            return cosmosClient;
        }
        public static Container GetCosmosContainer(string EndpointURI, string PrimaryKey, string databaseId, string containerId)
        {
            var cosmosClient = CreateCosmosClient(EndpointURI, PrimaryKey);
            var container = cosmosClient.GetContainer(databaseId, containerId);

            return container;
        }

        public static async Task<Boolean> UpsertCosmosItemAsync(PatientNote Data, Container container, ILogger log, EventHubClient hubclient)
        {
            try
            {
                Data.SetId();
                
                var configurationResponse = await container.UpsertItemAsync(Data, new PartitionKey(Data.id.ToString()));
                return true;
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = "CosmosDB NotesData data upsert failed";
                errorResonse.detail = "ID:" + Data.id;
                log.LogError(errorResonse.error);
                log.LogInformation(errorResonse.error);
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env + "-NotesData";
                evehubresponse.type = "Error";
                var message = JsonConvert.SerializeObject(evehubresponse);
                await Utils.ReliantUtlity.SendMessagesToEventHub(hubclient, log, message);
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return false;
            }
        }
    }
}
