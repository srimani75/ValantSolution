﻿using FhirSave.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Hl7.Fhir.Model;
using Microsoft.Azure.EventHubs;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using FhirSave.Models.Dto;

namespace FhirSave.Utils
{
    class PatientCheckinUtility
    {
        public static async Task<CoverageModelSummary> GetCoverage(string resource, string patId, string bearerToken)
        {
            CoverageModelSummary coverageModelSummary = new CoverageModelSummary();

            if (resource.EndsWith('/') == false)
            {
                resource += '/';
            }

            CoverageRoot coverage = await CoverageLookupByIdentifier(patId, resource, bearerToken);

            if (coverage.entry == null)
            {
                return coverageModelSummary;
            }


            string patientResourceLookupId = null;
            patientResourceLookupId = coverage.entry?[0].resource.beneficiary.display;

            // Patient lookup
            patientResourceLookupId = patientResourceLookupId.Split('/')[1];
            var policyHolder = await PatientLookupDirect(patientResourceLookupId, resource, bearerToken);

            // get the appointment for the patient
            //var appts = await Utils.PatientCheckinUtility.LookupResourceDirect<FhirSave.Models.Appointments.Root>(resource + $"/Appointment/?identifier={patId}", bearerToken);
            //FhirSave.Models.Location.Root providerLocation = null;
            //if (appts.entry[0]?.resource?.participant.Count > 0)
            //{
            //    for (int i = 0; i < appts.entry[0]?.resource?.participant.Count; i++)
            //    {
            //        if (appts.entry[0].resource.participant[i].actor?.reference != null)
            //            if (appts.entry[0].resource.participant[i].actor.reference.Contains("Location"))
            //            {
            //                // now lookup the location
            //                providerLocation = await Utils.PatientCheckinUtility.LookupResourceDirect<FhirSave.Models.Location.Root>(resource + appts.entry[0].resource.participant[i].actor?.reference, bearerToken);
            //            }
            //    }
            //}

            coverageModelSummary.id = coverage?.entry?[0]?.resource.id;
            coverageModelSummary.insuranceProvider = coverage.entry[0].resource.payor[0].display;

            string insurerId = string.Empty;

            coverage.entry[0].resource.identifier.ForEach((e) =>
            {
                if (e.system.Equals("AthenaInsuranceId", StringComparison.OrdinalIgnoreCase))
                {
                    coverageModelSummary.groupNumber = e.value;
                }
                if (e.system.Equals("AthenaMRN", StringComparison.OrdinalIgnoreCase))
                {
                    coverageModelSummary.policyNumber = e.value;
                }
            });

            coverageModelSummary.id = coverage.entry[0].resource.id;

            // Look up insurer address
            var org = await PatientCheckinUtility.LookupResourceDirect<OrganizationModel.Root>($"{resource}{coverageModelSummary.insuranceProvider}", bearerToken);

            coverageModelSummary.insuranceProviderAddress = new Models.Address();
            if (org.address[0].line.Count > 0)
                for (int i = 0; i < org.address[0].line.Count; i++)
                {
                    switch (i)
                    {
                        case 0:
                            coverageModelSummary.insuranceProviderAddress.Address1 = org.address[0].line[0] == null ? null : org.address[0].line[0];
                            break;
                        case 1:
                            coverageModelSummary.insuranceProviderAddress.Address2 = org.address[0].line[1] == null ? null : org.address[0].line[1];
                            break;
                    }
                }
            coverageModelSummary.insuranceProviderAddress.City = org.address[0].city;
            coverageModelSummary.insuranceProviderAddress.State = org.address[0].state;
            coverageModelSummary.insuranceProviderAddress.country = org.address[0].country;
            coverageModelSummary.insuranceProviderAddress.zipcode = org.address[0].postalCode;

            if (org.telecom?.Count != null)
                if (org.telecom.Count > 0)
                    foreach (var tele in org.telecom)
                        switch (tele.system)
                        {
                            case "Phone":
                            case "phone":
                                coverageModelSummary.insuranceProviderAddress.WorkPhone = tele.value;
                                break;
                        }

            var dt = new Date(policyHolder.BirthDate);
            coverageModelSummary.policyHolderDOB = dt.ToDateTime();

            coverageModelSummary.policyHolderRelationToPatient = coverage.entry[0]?.resource.relationship.coding[0].code;

            // get the demographics of the policy holder
            Demographics demos = await LookupDemographicsDirect(patId, resource, bearerToken);

            coverageModelSummary.policyHolderName = demos.DemographicsDetails.FirstOrDefault().FullName;

            // policy holder address
            coverageModelSummary.policyHolderAddress = new Models.Address();
            coverageModelSummary.policyHolderAddress.Address1 = demos.DemographicsDetails.First().address.Address1;
            coverageModelSummary.policyHolderAddress.Address2 = demos.DemographicsDetails.First().address.Address2;
            coverageModelSummary.policyHolderAddress.City = demos.DemographicsDetails.First().address.City;
            coverageModelSummary.policyHolderAddress.State = demos.DemographicsDetails.First().address.State;
            coverageModelSummary.policyHolderAddress.country = demos.DemographicsDetails.First().address.country;
            coverageModelSummary.policyHolderAddress.zipcode = demos.DemographicsDetails.First().address.zipcode;
            coverageModelSummary.policyHolderAddress.CellPhone = demos.DemographicsDetails.First().address.CellPhone;
            coverageModelSummary.policyHolderAddress.WorkPhone = demos.DemographicsDetails.First().address.WorkPhone;
            coverageModelSummary.policyHolderAddress.Email = demos.DemographicsDetails.First().address.Email;
            coverageModelSummary.policyHolderAddress.workEmail = demos.DemographicsDetails.First().address.workEmail;

            return coverageModelSummary;
        }

        public static async Task<PractitionerModelDto> GetPractitioner(string resource, string bearerToken)
        {
            var client = new RestClient(resource);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            IRestResponse response = await client.ExecuteAsync(request);

            PractitionerModel practitioner = JsonConvert.DeserializeObject<PractitionerModel>(response.Content);

            PractitionerModelDto dto = new PractitionerModelDto()
            {
                active = practitioner.active,
                telecom = practitioner.telecom?[0].value,
                gender = practitioner.gender,
                given = practitioner.name?[0].given,
                family = practitioner.name?[0].family,
                fullName = practitioner?.name?[0].family == null ? practitioner.name?[0].text : practitioner.name?[0].given?[0] + " " + practitioner.name?[0].family
            };

            return dto;
        }

        public static async Task<Demographics> GetDemographics(FhirClient client, ILogger log, string baseurl, string bearertoken, string patientId, CancellationToken cancellationToken)
        {
            Demographics demographicsobj = new Demographics();

            var conditions = new SearchParams();
            conditions.Add("identifier", patientId);
            Patient pat = new Patient();
            Bundle results = client.Search<Patient>(conditions);

            if (results.Entry.Count > 0)
            {
                var fhirpatientId = results.Entry[0].Resource.Id;
                var location = new Uri(baseurl + "/Patient/" + fhirpatientId);
                pat = client.Read<Patient>(location);
            }
            else
            {
                return (demographicsobj);
            }

            List<DemographicsDetails> DemographicsList = new List<DemographicsDetails>();
            string ageString = string.Empty;
            if (pat.BirthDate != null)
            {
                string dateinput = pat.BirthDate;
                DateTime now = DateTime.Now;
                DateTime givenDate = DateTime.Parse(dateinput);
                int days = now.Subtract(givenDate).Days;
                int age = (int)Math.Floor(days / 365.24219);
                ageString = age.ToString();
            }
            else
            {
                ageString = "unknown";
            }

            // Demographics Detail
            var demographicDetail = new Models.DemographicsDetails();
            // First Name
            demographicDetail.FirstName = string.Empty;
            demographicDetail.LastName = string.Empty;
            demographicDetail.FullName = string.Empty;
            if (pat.Name.Count > 0)
            {
                if (pat.Name[0].Given?.FirstOrDefault() != null)
                {
                    demographicDetail.FirstName = pat.Name[0].Given?.FirstOrDefault();
                }
                else
                {
                    demographicDetail.FirstName = pat.Name.FirstOrDefault()?.TextElement?.Value;
                }
                // LastName
                demographicDetail.LastName = pat.Name.FirstOrDefault()?.Family;
                // FullName
                string fullName = string.Empty;
                if (pat.Name.FirstOrDefault()?.Text != null)
                {
                    fullName = pat.Name.FirstOrDefault()?.Text + " " + pat.Name.FirstOrDefault()?.Family;
                    demographicDetail.FullName = fullName.Trim();
                }
                else
                {
                    fullName = demographicDetail?.FirstName + " " + demographicDetail?.LastName;
                    demographicDetail.FullName = fullName.Trim();
                }
            }

            // Age
            demographicDetail.age = ageString;
            // DOB
            demographicDetail.DOB = pat.BirthDate;
            // Gender
            demographicDetail.BirthGender = pat.Gender.ToString();

            // Address
            Models.Address addressdata = new Models.Address();
            if (pat.Address.Count > 0)
            {
                if (pat.Address[0]?.LineElement.Count > 0)
                {
                    for (int i = 0; i < pat.Address[0].LineElement.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                addressdata.Address1 = pat.Address[0].LineElement[0].Value;
                                break;
                            case 1:
                                addressdata.Address1 = pat.Address[0].LineElement[1].Value;
                                break;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < pat.Address.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                addressdata.Address1 = pat.Address.ElementAt(0).Text;
                                break;
                            case 1:
                                addressdata.Address2 = pat.Address.ElementAt(1).Text;
                                break;
                        }
                    }
                }
                addressdata.City = pat.Address.FirstOrDefault().City;
                addressdata.State = pat.Address.FirstOrDefault().State;
                addressdata.zipcode = pat.Address.FirstOrDefault().PostalCode;
                addressdata.country = pat.Address.FirstOrDefault().Country;
            }
            if (pat.Telecom.Count > 0)
            {
                foreach (var tel in pat.Telecom)
                {
                    if (tel.System == ContactPoint.ContactPointSystem.Phone)
                        addressdata.CellPhone = tel.Value;
                    if (tel.System == ContactPoint.ContactPointSystem.Email)
                        addressdata.Email = addressdata.Email + ";" + tel.Value;
                }
            }
            demographicDetail.address = addressdata;

            DemographicsList.Add(demographicDetail);
            demographicsobj.DemographicsDetails = DemographicsList;

            return (demographicsobj);
        }

        public static async Task<Models.ChiefComplaint> GetChiefComplaint(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            Models.ChiefComplaint lstccDet = new Models.ChiefComplaint();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);

            var ccrequest = new RestRequest(Method.GET);
            ccrequest.AddHeader("Content-Type", "application/json");
            ccrequest.AddHeader("Accept", "application/json");
            ccrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            ccrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse ccresponse = await client.ExecuteAsync(ccrequest);

            var ccbundleresponse = JsonConvert.DeserializeObject<Models.ChiefComplaintsModel.Root>(ccresponse.Content);
            var entries = ccbundleresponse.entry;
            foreach (var entry in entries)
            {
                var secCom = entry.resource.evidence;
                if (secCom != null)
                {
                    List<string> tempSecCom = new List<string>();
                    foreach (var cc in secCom)
                    {
                        tempSecCom.Add(cc.code[0].coding[0].code);
                    }
                    lstccDet.SecondaryComplaints = tempSecCom;
                }

                var chiefCom = entry.resource.note;
                List<string> tempChiefCom = new List<string>();
                if (chiefCom != null && chiefCom.Count() > 0)
                {
                    foreach (var cc in chiefCom)
                    {
                        tempChiefCom.Add(cc.text);
                    }
                }

                var denials = entry.resource.extension;
                if (denials != null)
                {
                    List<string> complaintdenials = new List<string>();
                    foreach (var den in denials)
                    {
                        if (den.id == "Denials")
                            complaintdenials.Add(den.valueCodeableConcept.text);
                    }
                    lstccDet.Denials = complaintdenials;
                }
                lstccDet.ChiefComplaints = tempChiefCom;
            }
            return lstccDet;
        }

        public static async Task<List<ImmunizationDetails>> GetImmunization(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            List<ImmunizationDetails> imList = new List<ImmunizationDetails>();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var imrequest = new RestRequest(Method.GET);
            imrequest.AddHeader("Content-Type", "application/json");
            imrequest.AddHeader("Accept", "application/json");
            imrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            imrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse imresponse = await client.ExecuteAsync(imrequest);
            var imbundleresponse = JsonConvert.DeserializeObject<Models.ImmunizationModel.Root>(imresponse.Content);
            var entries = imbundleresponse.entry;
            if (entries != null)
            {
                foreach (var entry in entries)
                {
                    Models.ImmunizationDetails imDet = new Models.ImmunizationDetails();
                    if (entry.resource.identifier != null)
                        imDet.Immunizationcode = entry.resource.identifier[0].value;
                    if (entry.resource.vaccineCode?.coding != null)
                        imDet.Vaccinecode = entry.resource.vaccineCode.coding[0].code;
                    if (entry.resource.vaccineCode?.text != null)
                        imDet.name = entry.resource.vaccineCode?.text;
                    else
                        imDet.name = entry.resource.vaccineCode.coding[0].display;
                    imDet.Occurencedate = entry.resource.occurrenceDateTime.ToString();
                    imDet.Primarysource = entry.resource.primarySource.ToString();

                    imList.Add(imDet);
                }
            }
            return imList;
        }

        public static async Task<List<string>> GetMedications(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            Models.MedicationModel.Root meds = new Models.MedicationModel.Root();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);

            var ccrequest = new RestRequest(Method.GET);
            ccrequest.AddHeader("Content-Type", "application/json");
            ccrequest.AddHeader("Accept", "application/json");
            ccrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            ccrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse ccresponse = await client.ExecuteAsync(ccrequest);

            meds = JsonConvert.DeserializeObject<Models.MedicationModel.Root>(ccresponse.Content);

            List<string> listOfPatientMeds = new List<string>();

            if (meds.entry != null)
            {
                foreach (var entry in meds.entry)
                {
                    listOfPatientMeds.Add(entry.resource.medicationCodeableConcept?.coding?[0].display);
                }
            }

            return listOfPatientMeds;
        }

        private static async Task<Patient> PatientLookupDirect(string id, string resource, string bearerToken)
        {
            var messageHandler = new HttpClientEventHandler();
            messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
            {
                e.RawRequest.Headers
                .Add("Authorization", $"Bearer {bearerToken}");
            };

            Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
            {
                PreferredFormat = ResourceFormat.Json
            });

            Patient patient = client.Read<Patient>(resource + "Patient/" + id);
            return patient;
        }

        private static async Task<Patient> PatientLookupByIdentifier(string patientId, string resource, string bearerToken)
        {
            var client = new RestClient(resource + "Patient/?identifier=" + patientId);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response2 = await client.ExecuteAsync(request);
            return JsonConvert.DeserializeObject<Patient>(response2.Content);
        }

        private static async Task<Appointment> AppointmentLookupDirect(string id, string resource, string bearerToken)
        {
            var client = new RestClient(resource + "appointment/" + id);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response3xx = await client.ExecuteAsync(request);
            return JsonConvert.DeserializeObject<Appointment>(response3xx.Content);
        }

        public static async Task<FhirSave.Models.Appointments.Root> AppointmentLookupByIdentifier(string mrn, string resource, string bearerToken)
        {
            var client = new RestClient(resource + "/Appointment/?identifier=" + mrn);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            return JsonConvert.DeserializeObject<FhirSave.Models.Appointments.Root>(response.Content);
        }

        private static async Task<CoverageRoot> CoverageLookupDirect(string id, string resource, string bearerToken)
        {
            var client = new RestClient(resource + "Coverage/" + id);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            return JsonConvert.DeserializeObject<CoverageRoot>(response.Content);
        }

        private static async Task<CoverageRoot> CoverageLookupByIdentifier(string mrn, string resource, string bearerToken)
        {
            var client = new RestClient(resource + "Coverage/?identifier=" + mrn);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            return JsonConvert.DeserializeObject<CoverageRoot>(response.Content);
        }

        public static async Task<T> LookupResourceDirect<T>(string resource, string bearerToken) where T : class
        {
            var client = new RestClient(resource);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);

            T T_Instance = JsonConvert.DeserializeObject<T>(response.Content);
            return T_Instance;
        }

        private static async Task<Demographics> LookupDemographicsDirect(string mrn, string resource, string bearerToken)
        {
            var messageHandler = new HttpClientEventHandler();
            messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
            {
                e.RawRequest.Headers
                .Add("Authorization", $"Bearer {bearerToken}");
            };

            Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
            {
                PreferredFormat = ResourceFormat.Json
            });

            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            cancellationTokenSource.CancelAfter(8000);

            Demographics demos = await GetDemographics(client, null, resource, bearerToken, mrn, cancellationTokenSource.Token);
            return demos;

        }

        public static async Task<ConditionList> GetConditions(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            Models.ConditionList data = new Models.ConditionList();
            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            var bundleresponse = JsonConvert.DeserializeObject<Models.ConditionModel.Root>(response.Content);
            data.Problems = new List<ConditionData>();
            foreach (var item in bundleresponse.entry)
            {
                var con = new Models.ConditionData();
                con.VerificationStatus = item.resource.verificationStatus?.text;
                
                if (item.resource.clinicalStatus.text != null)
                {
                    con.ClinicalStatus = item.resource.clinicalStatus.text;

                }
                else
                {
                    con.ClinicalStatus = item.resource.clinicalStatus.coding?[0].display;
                }

                if (item.resource.code.text != null)
                {
                    con.Name = item.resource.code.text;

                }
                else
                {
                    con.Name = item.resource.code?.coding?[0].display;
                }

                if (item.resource.code.coding != null)
                {
                    foreach (var code in item.resource.code.coding)
                    {
                        if (code.display == "RxNorm")
                        {
                            con.RxNorm = code.code;
                        }
                        if (code.display == "ICDCode")
                        {
                            con.ICDCode = code.code;
                        }
                        if (code.display == "Pre-op evaluation")
                        {
                            con.ICDCode = code.code;
                        }
                    }
                }
                if (item.resource?.category != null)
                {
                    foreach (var cat in item.resource?.category)
                    {
                        if (cat.coding != null)
                        {
                            if (cat.coding[0].display == "Loinc")
                            {
                                con.LoincCode = cat.coding[0].code;
                            }
                        }
                    }

                }
                data.Problems.Add(con);
            }
            return data;
        }

        public static string GetEnvironmentVariable(string name)
        {
            return System.Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }
    }
}
