﻿using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace FhirCronService
{
    public class Utilities
    {
        public static string GetGender(string gender)
        {
            if (string.IsNullOrEmpty(gender)) return AdministrativeGender.Unknown.ToString();
            gender = gender.ToUpper();
            AdministrativeGender retGender = gender == "M" ? AdministrativeGender.Male : gender == "F" ? AdministrativeGender.Female
                : gender == "O" ? AdministrativeGender.Other : AdministrativeGender.Unknown;
            return retGender.ToString();
        }

        public static FhirClient BuildFhirClient()
        {
            var messageHandler = new HttpClientEventHandler();
            var resource = "https://optum-fhirserver-nonprod.azurehealthcareapis.com";
            string bearerToken = TokenHandler.GetFhirToken();
            messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
            {
                e.RawRequest.Headers
                .Add("Authorization", $"Bearer {bearerToken}");
            };

            FhirClient fhClient = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
            {
                PreferredFormat = ResourceFormat.Json
            });
            return fhClient;

        }

        public static string GetEnvironmentVariable(string name)
        {
            return System.Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }

        public static string GetDescription(Enum @enum)
        {
            if (@enum == null)
                return null;

            string description = @enum.ToString();

            try
            {
                FieldInfo fi = @enum.GetType().GetField(@enum.ToString());

                DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes.Length > 0)
                    description = attributes[0].Description;
            }
            catch
            {
            }

            return description;
        }

        public static string SerializeResource(object objResource)
        {
            StringBuilder sb = new StringBuilder();
            JsonTextWriter tw = new JsonTextWriter(new StringWriter(sb));
            JsonSerializer.Create().Serialize(tw, objResource);
            return sb.ToString();
        }

        public static string LookupResourceId<T>(string resourceId) where T:DomainResource
        {
            Bundle bndl = BuildFhirClient().Search<T>(new SearchParams().Add("identifier", resourceId));
            return bndl.Entry[0]?.Resource?.Id;
        }

        private static void PerformCleanup<T>(SearchParams srchPrms) where T : DomainResource
        {
            FhirClient fhClient = BuildFhirClient();
            Bundle bndl = fhClient.Search<T>(srchPrms);
            foreach (var ent in bndl.Entry)
            {
                fhClient.Delete(ent.Resource);
            }
        }

        public static int GetResourceCount<T>() where T : DomainResource
        {
            FhirClient fhClient = BuildFhirClient();
            return fhClient.Search<T>(new SearchParams()).Entry.Count;
        }
        public static void CleanupAllResources<T>() where T : DomainResource
        {
            PerformCleanup<T>(new SearchParams());
        }


        public static void CleaupResource<T>(string resourceId) where T: DomainResource
        {
            PerformCleanup<T>(new SearchParams().Add("identifier", resourceId));
        }

        public static T LookupResource<T>(string resourceId, FhirClient fhClient) where T : DomainResource
        {
            Bundle bndl = fhClient.Search<T>(new SearchParams().Add("identifier", resourceId));
            return bndl.Entry.Count > 0 ? fhClient.Read<T>(bndl.Entry[0].FullUrl) : null;
        }
        public static string GetBundleId(string bundle, Patient patResponse)
        {
            return patResponse.Identifier.FirstOrDefault(a => a.Value.Contains(bundle))?.Value;
        }




        public static T LookupResource<T>(string resourceId) where T : DomainResource
        {
            return LookupResource<T>(resourceId, BuildFhirClient());
        }
    }
}
