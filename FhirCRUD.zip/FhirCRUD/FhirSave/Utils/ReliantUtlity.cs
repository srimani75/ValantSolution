﻿using FhirSave.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Hl7.Fhir.Model;
using Microsoft.Azure.EventHubs;
using System.Text;

namespace FhirSave.Utils
{
    public static class Extention
    {
        public static string ConvertObjectToJson(this object ob)
        {
            return JsonConvert.SerializeObject(ob);
        }
    }
    public class ReliantUtlity
    {
       
        public static Patient GetPatient(FhirClient client, string resource, string mrn)
        {
            var pat = new Patient();
            //Patient pat = null;
            var conditions = new SearchParams();
            conditions.Add("identifier", mrn);
            //Bundle results = client.Search<Patient>(new string[] { "family:exact="+familyname.Split(" ")[1] });
            Bundle results = client.Search<Patient>(conditions);
            if (results.Entry.Count > 0)
            {
                var fhirpatientId = results.Entry[0].Resource.Id;
                var location = new Uri(resource + "/Patient/" + fhirpatientId);
                pat = client.Read<Patient>(location);
            }
            return pat;
        }

        public static async Task<string> GetBundleID(string bundle, Patient patResponse)
        {
            var bundleID = "";
            Stack<string> idStack = new Stack<string>();
            foreach (var identifier in patResponse.Identifier)
            {
                if (identifier.System.Contains(bundle))
                {
                    idStack.Push(identifier.Value);
                }
            }
            if(idStack.Count>0)
                bundleID = idStack.Peek();

            return bundleID;
        }
        public static async Task<string> GetReliantHPI(string bundleId, string resource, string age, string gender, string bearerToken, CancellationToken cancellationToken)
        {
           
            var client = new RestClient(resource + "/Bundle/" + bundleId);            
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + bearerToken);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            IRestResponse response = client.Execute(request);
            var complaintResponse = JsonConvert.DeserializeObject<ReliantHPIModel.HPI>(response.Content);

            List<string> chiefComplaint = new List<string>();
            List<string> secondaryComplaint = new List<string>();
            List<string> seriousSymptoms = new List<string>();
            foreach (var entry in complaintResponse.entry)
            {
                var res = entry.resource;
                
                foreach( var note in res.note)
                {
                    if(note.text != null) chiefComplaint.Add(note.text);
                }
                foreach(var evidence in res.evidence)
                {
                    if(evidence != null ) secondaryComplaint.Add(evidence.code[0].coding[0].code);
                }
                foreach(var extension in res.extension)
                {
                    if (extension != null)
                    {
                        if (extension.id != null && extension.id != "Denials")
                        {
                            seriousSymptoms.Add(extension.id);
                        }
                    }
                }
            }

            var hpi = "The patient is a " + gender.ToLower() + ", " + age + " years of age initially presenting with " + String.Join(", ", chiefComplaint).ToLower();
           
            var symptoms = new List<String>();
            foreach(var sersymp in seriousSymptoms)
            {
                if(sersymp != null) symptoms.Add(sersymp);
            }

            String symp = String.Join(", ", symptoms);
            if(symptoms.Count == 0 && secondaryComplaint.Count == 0)
            {
                hpi += ".";
            }
            else if (symptoms.Count != 0 && secondaryComplaint.Count == 0)
            {
                hpi += ". Symptoms include " + symp.ToLower() + ".";
            }
            else if (symptoms.Count == 0 && secondaryComplaint.Count != 0)
            {
                symp += String.Join(", ", secondaryComplaint);
                hpi += ". Symptoms include " + symp.ToLower() + ".";
            }
            else if(symptoms.Count != 0 && secondaryComplaint.Count != 0)
            {
                symp += ", " + String.Join(", ", secondaryComplaint);
                hpi += ". Symptoms include " + symp.ToLower() + ".";
            }
            
            hpi = hpi.Replace("°f", "°F");
            hpi = hpi.Replace("°c", "°C");
            return hpi;

        }
        public static async Task<ReliantAllergiesModel.ReliantAllergies> getRelaintAllergies(string patientId, string token)
        {
            var allURL = GetEnvironmentVariable("AllergiesEPICURL");
            //var allURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/R4/AllergyIntolerance";
            var client = new RestClient(allURL);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer "+ token);
            request.AddQueryParameter("patient", patientId);
            request.AddQueryParameter("clinical-status", "active");
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");            
            IRestResponse response = await client.ExecuteAsync(request);
            ReliantAllergiesModel.ReliantAllergies data = JsonConvert.DeserializeObject<Models.ReliantAllergiesModel.ReliantAllergies>(response.Content);

            return data;
        }

        public static async Task<Models.ReliantVitalsResponse.ReliantVitalsDetail> GetReliantVitals(string code, string bearertoken, string patientID,CancellationToken token,ILogger log)
        {
            var obsURL = GetEnvironmentVariable("ObservationEPICURL");
            //var obsURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/R4/Observation";
            var client = new RestClient(obsURL);
            var request = new RestRequest(Method.GET);
            var date = DateTime.Today.AddYears(-1);
            var month = date.Month.ToString();
            var year = date.Year.ToString();
            var day = date.Day.ToString();
            if (Convert.ToInt32(month) < 10)
                month = "0" + month;
            if (Convert.ToInt32(day) < 10)
                day = "0" + day;
           

            var searchdate = year + "-" + month + "-" + day;
            log.LogInformation("Vitals Search date:" + searchdate);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddQueryParameter("patient", patientID);                   
            request.AddQueryParameter("category", code);
            request.AddQueryParameter("date", "gt" + searchdate);
            IRestResponse response = await client.ExecuteAsync(request, token);
            var data = JsonConvert.DeserializeObject<Models.ReliantVitalsResponse.ReliantVitalsDetail>(response.Content);

            return data;
        }
        public static async Task<ReliantSocialHistoryResponse.ReliantSocial> GetReliantSocial(string code, string bearertoken, string patientID) 
        {
            var obsURL = GetEnvironmentVariable("ObservationEPICURL");
            //var obsURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/R4/Observation";
            var client = new RestClient(obsURL);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddQueryParameter("patient", patientID);
            request.AddQueryParameter("category", code);
            IRestResponse response = await client.ExecuteAsync(request);
            var data = JsonConvert.DeserializeObject<Models.ReliantSocialHistoryResponse.ReliantSocial>(response.Content);
            return data;
        }
        public static async Task<ReliantFamilyHistoryModel.FamilyHistory> GetFamilyHistory(string bearertoken, string patientID)
        {
            var famURL = GetEnvironmentVariable("FamilyHistoryURL");
            //var famURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/DSTU2/FamilyMemberHistory";
            var client = new RestClient(famURL);            
            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer "+bearertoken);
            request.AddQueryParameter("patient", patientID);
            IRestResponse response =await client.ExecuteAsync(request);
            var data = JsonConvert.DeserializeObject<ReliantFamilyHistoryModel.FamilyHistory>(response.Content);
            return data;
        }
        public static async Task<Models.ReliantLabsModel.ReliantLabsResponse> GetReliantLabs(string patientId, string token)
        {
            var labsURL = GetEnvironmentVariable("LabsEPICURL");
            //var labsURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/DSTU2/Observation";
            var client = new RestClient(labsURL);            
            var request = new RestRequest(Method.GET);
            request.AddQueryParameter("patient", patientId);
            request.AddQueryParameter("category", "laboratory");
            request.AddHeader("Authorization", "Bearer "+ token);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");            
            IRestResponse response = await client.ExecuteAsync(request);
            Models.ReliantLabsModel.ReliantLabsResponse data = JsonConvert.DeserializeObject<Models.ReliantLabsModel.ReliantLabsResponse>(response.Content);

            return data;
        }
        public static async Task<ReliantProblemsModel.ReliantProblemsResponse> GetReliantProblems(string patientId, string token)
        {
            var conURL = GetEnvironmentVariable("ConditionEPICURL");
            //var conURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/R4/Condition";
            var client = new RestClient(conURL);            
            var request = new RestRequest(Method.GET);
            request.AddQueryParameter("patient", patientId);
            request.AddQueryParameter("category", "problem-list-item");
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer" + token);
            IRestResponse response = client.Execute(request);
            ReliantProblemsModel.ReliantProblemsResponse data = JsonConvert.DeserializeObject<ReliantProblemsModel.ReliantProblemsResponse>(response.Content);

            return data;
        }
 
        public static async Task<Models.ReliantImmunizationsModel.Immunizations> GetReliantImmunizations(string patientId, string token,ILogger log)
        {
            var ImmunURL = GetEnvironmentVariable("ImmunizationEPICURL");
            //var ImmunURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/R4/Immunization";
            var client = new RestClient(ImmunURL);
            var date = DateTime.Today.AddYears(-5);            
            var month = date.Month.ToString();
            var year = date.Year.ToString();
            var day = date.Day.ToString();
            if (Convert.ToInt32(month) < 10)
                month = "0" + month;
            if (Convert.ToInt32(day) < 10)
                day = "0" + day;

            var searchdate = year + "-" + month + "-" + day;
            log.LogInformation("Immunizations search date:" + searchdate);
            var request = new RestRequest(Method.GET);
            request.AddQueryParameter("patient", patientId);
            request.AddQueryParameter("date", "gt"+searchdate);
            request.AddQueryParameter("status", "completed");
            request.AddHeader("Authorization", "Bearer " + token);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            IRestResponse response = await client.ExecuteAsync(request);
            Models.ReliantImmunizationsModel.Immunizations data = JsonConvert.DeserializeObject<Models.ReliantImmunizationsModel.Immunizations>(response.Content);

            return data;
        }

        public static async Task<ReliantSurgicalHistoryModel.SurgicalHistory> GetReliantSurgicalHistory(string patientId, string token)
        {
            var surgURL = GetEnvironmentVariable("ReliantSurgicalHistoryURL")+"?patient="+patientId;
            //var surgURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/R4/Procedure?patient="+ patientId;
            var client = new RestClient(surgURL);            
            var request = new RestRequest(Method.GET);
            var clientID = GetEnvironmentVariable("reliantclientID");
            //request.AddQueryParameter("ClientID", "d442135f-546d-46e8-a35d-166f5636c1ad");
            request.AddQueryParameter("ClientID", clientID);
           
            request.AddHeader("Authorization", "Bearer "+token);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            IRestResponse response = await client.ExecuteAsync(request);
            ReliantSurgicalHistoryModel.SurgicalHistory data = JsonConvert.DeserializeObject<ReliantSurgicalHistoryModel.SurgicalHistory>(response.Content);

            return data;
        }
       
        public static async System.Threading.Tasks.Task DelBundle(string acesstoken,string bundleID)
        {
            var resource = GetEnvironmentVariable("resource");
            var client = new RestClient(resource + "/Bundle/" + bundleID);
            //var client = new RestClient("https://optum-fhirserver-dev.azurehealthcareapis.com/Bundle/" + bundleID);
            var request = new RestRequest(Method.DELETE);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer "+ acesstoken); 
            IRestResponse response =await client.ExecuteAsync(request);
        }
        public static async Task<ReliantPatientModel.Patientinfo> GetReliantPatient(string bearertoken, string patientID,ILogger log, CancellationToken canceltoken)
        {
            var patURL = GetEnvironmentVariable("PatientEPICURL");
            //var patURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/DSTU2/Patient";
            var client = new RestClient(patURL + "/"+patientID);
            
            var request = new RestRequest(Method.GET);
           
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer "+bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response =client.Execute(request);
            log.LogInformation(response.Content);
            var data = JsonConvert.DeserializeObject<ReliantPatientModel.Patientinfo>(response.Content);            
            log.LogInformation(JsonConvert.SerializeObject(data));
            return data;
        }
        public static async Task<MedicationStatementModel.MedicationStatementDetails> GetReliantMedicationStatement(string patientID, string bearertoken,CancellationToken token)
        {
            var medURL = GetEnvironmentVariable("MedicationEPICURL");
            //var medURL = "https://fhirnp.reliantmedicalgroup.org/FHIRTST/api/FHIR/DSTU2/MedicationStatement";
            var client = new RestClient(medURL);
            
            var request = new RestRequest(Method.GET);
            request.AddQueryParameter("status", "active");
            request.AddQueryParameter("patient", patientID);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer "+bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response =await client.ExecuteAsync(request,token);

            var data = JsonConvert.DeserializeObject<MedicationStatementModel.MedicationStatementDetails>(response.Content);
            return data;
        }
        public sessionresponse GetSessionID(string bearertoken, string patientID, ILogger log, CancellationToken cancellationToken)
        {
            var clientID = GetEnvironmentVariable("reliantclientID");
            var loginURL = GetEnvironmentVariable("GarberLoginDoneURL");
            //var loginURL = "https://fhirnp.reliantmedicalgroup.org/FHIRAPITST/api/Garber/2020/Informatics/Utility/loginDoneFHIRAPI";
            //var clientID = "d442135f-546d-46e8-a35d-166f5636c1ad";
            var sessionID = GenerateRandomString(8);           
            var client = new RestClient(loginURL);
            sessionresponse session = new sessionresponse();
            var request = new RestRequest(Method.GET);
            request.AddQueryParameter("ClientID", clientID);
            request.AddQueryParameter("PatientID", patientID);
            request.AddQueryParameter("SessionID", sessionID);
            request.AddHeader("Authorization", "Bearer "+bearertoken);
            IRestResponse response =client.Execute(request);
           // log.LogInformation(response.Content);
            if (response.Content.Contains("Status"))
            {
                session = JsonConvert.DeserializeObject<sessionresponse>(response.Content);
                if (session.Status == "0")
                {
                    session.SessionID = "";
                }
                else
                    session.SessionID = sessionID;
            }
            //log.LogInformation(response.Content);
            return session;
        }
       
        public static async Task<List<PossCausandDenDetails>> GetPossCausAndDen(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            List<PossCausandDenDetails> pcdList = new List<PossCausandDenDetails>();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var pcdrequest = new RestRequest(Method.GET);
            pcdrequest.AddHeader("Content-Type", "application/json");
            pcdrequest.AddHeader("Accept", "application/json");
            pcdrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            pcdrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse pcdresponse = await client.ExecuteAsync(pcdrequest);
            var pcdbundleresponse = JsonConvert.DeserializeObject<Models.PossibleCausesandDenialsModel.Root>(pcdresponse.Content);
            var entries = pcdbundleresponse.entry;
            foreach (var entry in entries)
            {
                var extension = entry.resource.extension;
                if (extension != null)
                {
                    foreach (var ext in extension)
                    {
                        if (ext.id == Extensions.careoptions.ToString() || ext.id == Extensions.RiskFactors.ToString())
                            break;
                        var pcdDetail = new Models.PossCausandDenDetails();
                        pcdDetail.ID = ext.valueCodeableConcept.id;
                        pcdDetail.CommonName = ext.valueCodeableConcept.text;
                        pcdDetail.Name = ext.valueCodeableConcept.coding[0].display;
                        var ext1 = ext.extension[1].valueCodeableConcept.coding;
                        var ext2 = ext.extension[2].valueCodeableConcept.coding;
                        foreach (var code in ext1)
                        {
                            if (code.display.Contains("Category"))
                                pcdDetail.CategoriesCareDelimited = code.code;
                            if (code.display.Contains("Prevalence"))
                                pcdDetail.Prevalence = code.code;
                            if (code.display.Contains("acuteness"))
                                pcdDetail.Acuteness = code.code;
                            if (code.display.Contains("severity"))
                                pcdDetail.Severity = code.code;
                            if (code.display.Contains("triage_level"))
                                pcdDetail.TriageLevel = code.code;
                            if (code.display.Contains("recommended_channel"))
                                pcdDetail.RecommendedChannel = code.code;
                            if (code.display.Contains("probability"))
                                pcdDetail.Probablity = code.code;
                            if (code.display.Contains("short_description"))
                                pcdDetail.ShortDescription = code.code;
                            if (code.display.Contains("medline_url"))
                                pcdDetail.MedlineURL = code.code;
                            if (code.display.Contains("common_medline_name"))
                                pcdDetail.CommonMedlineName = code.code;
                        }
                        foreach (var code in ext2)
                        {
                            if (code.display.Contains("ICDCodes"))
                                pcdDetail.ICD10Code = code.code;
                            if (code.display.Contains("hint"))
                                pcdDetail.Hint = code.code;
                        }
                        pcdList.Add(pcdDetail);
                    }
                }
            }
            return pcdList;
        }

        public static async Task<List<SurgicalHistoryDetails>> GetSurgicalHistory(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            List<SurgicalHistoryDetails> shList = new List<SurgicalHistoryDetails>();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var shrequest = new RestRequest(Method.GET);
            shrequest.AddHeader("Content-Type", "application/json");
            shrequest.AddHeader("Accept", "application/json");
            shrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            shrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse shresponse = await client.ExecuteAsync(shrequest);
            var shbundleresponse = JsonConvert.DeserializeObject<Models.SurgicalHistoryModel.Root>(shresponse.Content);
            var entries = shbundleresponse.entry;
            if (entries != null)
            {
                foreach (var entry in entries)
                {
                    Models.SurgicalHistoryDetails shDet = new Models.SurgicalHistoryDetails();
                    shDet.Status = entry.resource.status;
                    if(entry.resource.code.coding != null)
                    {
                        shDet.Code = entry.resource.code.coding[0].code;
                        shDet.Name = entry.resource.code.coding[0].display;
                    }
                    shDet.Laterality = entry.resource.code.text;
                    shDet.Date = entry.resource.performedString;
                    if (entry.resource.note != null)
                        shDet.Comment = entry.resource.note[0].text;

                    shList.Add(shDet);
                }
            }
            return shList;
        }

        public static async Task<List<ImmunizationDetails>> GetImmunization(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            List<ImmunizationDetails> imList = new List<ImmunizationDetails>();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var imrequest = new RestRequest(Method.GET);
            imrequest.AddHeader("Content-Type", "application/json");
            imrequest.AddHeader("Accept", "application/json");
            imrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            imrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse imresponse = await client.ExecuteAsync(imrequest);
            var imbundleresponse = JsonConvert.DeserializeObject<Models.ImmunizationModel.Root>(imresponse.Content);
            var entries = imbundleresponse.entry;
            if(entries != null)
            {
                foreach(var entry in entries)
                {
                    Models.ImmunizationDetails imDet = new Models.ImmunizationDetails();
                    if (entry.resource.identifier != null)
                        imDet.Immunizationcode = entry.resource.identifier[0].value;
                    if (entry.resource.vaccineCode.coding != null)
                        imDet.Vaccinecode = entry.resource.vaccineCode.coding[0].code;
                    imDet.name = entry.resource.vaccineCode.text;
                    imDet.Occurencedate = entry.resource.occurrenceDateTime.ToString();
                    imDet.Primarysource = entry.resource.primarySource.ToString();

                    imList.Add(imDet);
                }
            }
            return imList;
        }

        public static async Task<Allergies> GetAllergyBundle(string baseurl, string bundleId, string bearertoken)
        {
            var client = new RestClient(baseurl + "/Bundle/" + bundleId);

            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            var bundleresponse = JsonConvert.DeserializeObject<Models.AllergiesModel.AllergiesDetails>(response.Content);

            Allergies allergies = new Allergies();
            List<AllergiesDetails> detailsList = new List<AllergiesDetails>();
            string lastDate = bundleresponse.meta.lastUpdated.ToString("MMM dd yyyy hh:mm tt");
            foreach (var entry in bundleresponse.entry)
            {
                AllergiesDetails details = new AllergiesDetails();

                details.detail = entry.resource.code.coding?[0].display;
                details.entrycode = entry.resource.code.coding?[0].code;
                details.description = entry.resource?.reaction?[0].substance?.text;
                details.section = "allergies";
                details.status = entry.resource.clinicalStatus?.coding?[0].code;
                details.displaydate = lastDate;
                details.reactiontype = entry.resource.code.coding?[0].display;
                var reactions = entry.resource.reaction?[0].manifestation;

                if (reactions != null) 
                {
                    List<string> tempReactions = new List<string>();

                    foreach (var reaction in reactions)
                    {
                        tempReactions.Add(reaction.text);
                    }

                    details.reactions = tempReactions;
                }
                else
                {
                    details.reactions = null;
                }

                //           Parsing ICDCodes
                if (entry.resource.code.coding.Count > 1)
                {
                    List<Models.ICDCode> ICDCodeList = new List<Models.ICDCode>();
                    var responseCode = new Models.ICDCode();
                    if (entry.resource.code.coding[1].code != null) responseCode.icd9 = entry.resource.code.coding[1].code;
                    if (entry.resource.code.coding[2].code != null) responseCode.icd10 = entry.resource.code.coding[2].code;
                    ICDCodeList.Add(responseCode);
                    details.ICDCodes = ICDCodeList;
                }

                detailsList.Add(details);
            }

            allergies.AllergiesDetails = detailsList;
            return allergies;
        }

        public static async Task<Models.ChiefComplaint> GetChiefComplaint(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            Models.ChiefComplaint lstccDet = new Models.ChiefComplaint();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);

            var ccrequest = new RestRequest(Method.GET);
            ccrequest.AddHeader("Content-Type", "application/json");
            ccrequest.AddHeader("Accept", "application/json");
            ccrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            ccrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse ccresponse = await client.ExecuteAsync(ccrequest);

            var ccbundleresponse = JsonConvert.DeserializeObject<Models.ChiefComplaintsModel.Root>(ccresponse.Content);
            var entries = ccbundleresponse.entry;
            foreach (var entry in entries)
            {
                var secCom = entry.resource.evidence;
                if(secCom!=null)
                {
                    List<string> tempSecCom = new List<string>();                    
                    foreach (var cc in secCom)
                    {
                        tempSecCom.Add(cc.code[0].coding[0].code);
                    }
                    lstccDet.SecondaryComplaints = tempSecCom;
                }                

                var chiefCom = entry.resource.note;
                List<string> tempChiefCom = new List<string>();                
                foreach (var cc in chiefCom)
                {
                    tempChiefCom.Add(cc.text);
                }

                var denials = entry.resource.extension;
                if(denials!=null)
                {
                    List<string> complaintdenials = new List<string>();
                    foreach (var den in denials)
                    {
                        if(den.id == "Denials")
                            complaintdenials.Add(den.valueCodeableConcept.text);
                    }
                    lstccDet.Denials = complaintdenials;
                }
                lstccDet.ChiefComplaints = tempChiefCom;
            }
            return lstccDet;
        }

        public static async Task<Models.RiskFactor> GetRiskFactors(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            //bundleID = "7cfa6ce1-6b88-4c01-9c9b-1261dd056a24";
            Models.RiskFactor lstRiskFactors = new Models.RiskFactor();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var rfrequest = new RestRequest(Method.GET);
            rfrequest.AddHeader("Content-Type", "application/json");
            rfrequest.AddHeader("Accept", "application/json");
            rfrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            rfrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse pcdresponse = await client.ExecuteAsync(rfrequest);
            var rfbundleresponse = JsonConvert.DeserializeObject<Models.PossibleCausesandDenialsModel.Root>(pcdresponse.Content);
            var entries = rfbundleresponse.entry;
            foreach (var entry in entries)
            {
                List<string> tempRiskFactors = new List<string>();
                var extension = entry.resource.extension;
                if (extension != null)
                {
                    foreach (var ext in extension)
                    {
                        if (ext.id == Extensions.RiskFactors.ToString())
                        {
                            foreach (var code in ext.valueCodeableConcept.coding)
                                tempRiskFactors.Add(code.code);
                        }
                    }
                }
                    
                lstRiskFactors.RiskFactors = tempRiskFactors;
            }
            return lstRiskFactors;
        }

        public static async Task<List<Models.SeriousSymptomsDet>> GetSeriousSymp(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            List<SeriousSymptomsDet> serSympList = new List<SeriousSymptomsDet>();
            var client = new RestClient(baseurl + "/Bundle/" + bundleID);

            var ccrequest = new RestRequest(Method.GET);
            ccrequest.AddHeader("Content-Type", "application/json");
            ccrequest.AddHeader("Accept", "application/json");
            ccrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            ccrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse ccresponse = await client.ExecuteAsync(ccrequest);

            var ccbundleresponse = JsonConvert.DeserializeObject<Models.ChiefComplaintsModel.Root>(ccresponse.Content);
            var entries = ccbundleresponse.entry;
            foreach (var entry in entries)
            {
                var extension = entry.resource.extension;
                if (extension != null)
                {
                    foreach (var item in extension)
                    {
                        if (item.id != "Denials")
                        {
                            Models.SeriousSymptomsDet serSymp = new Models.SeriousSymptomsDet();
                            serSymp.Name = item.valueCodeableConcept.text;
                            serSymp.CommonName = item.id;
                            serSymp.ID = item.valueCodeableConcept.id;
                            serSymp.IsEmergency = item.extension[0].valueBoolean.ToString();
                            serSympList.Add(serSymp);
                        }
                    } 
                }
            }
            return serSympList;
        }

        public static async Task<Models.Miscellaneous> GetMiscellaneous(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            //bundleID = "7cfa6ce1-6b88-4c01-9c9b-1261dd056a24";
            Models.Miscellaneous miscellaneousDet = new Models.Miscellaneous();

            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var rfrequest = new RestRequest(Method.GET);
            rfrequest.AddHeader("Content-Type", "application/json");
            rfrequest.AddHeader("Accept", "application/json");
            rfrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            rfrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse pcdresponse = await client.ExecuteAsync(rfrequest);
            var rfbundleresponse = JsonConvert.DeserializeObject<Models.PossibleCausesandDenialsModel.Root>(pcdresponse.Content);
            var entries = rfbundleresponse.entry;
            foreach (var entry in entries)
            {
                List<string> tempCareOptions = new List<string>();
                var extension = entry.resource.extension;
                if (extension != null)
                {
                    foreach (var ext in extension)
                    {
                        if (ext.id == Extensions.careoptions.ToString() && ext.valueCodeableConcept!=null)
                        {
                            foreach (var item in ext.valueCodeableConcept.coding)
                                tempCareOptions.Add(item.code);
                        }
                    }
                }
                miscellaneousDet.CareOptions = tempCareOptions;

                var coding = entry.resource.code.coding;
                foreach(var item in coding)
                {
                    if (item.display == "teleconsultation")
                        miscellaneousDet.TeleconsultationApplicable = item.userSelected.ToString();

                    if (item.display == "triagelevel")
                    {
                        miscellaneousDet.TriageLevel = item.code;
                        miscellaneousDet.PatientSelfTriageLevel = item.code;
                    }
                    if (item.display == "NPS")
                    {
                        miscellaneousDet.LikelihoodToRecommend = item.code;                       
                    }

                }
            }
            return miscellaneousDet;
        }

        public static async Task<PatientResponse> GetPatientResponseBundle(string baseurl, string bundleId, string bearertoken)
        {
            //bundleId = "1b3ae90e-036c-4a4a-b4f2-c6d0e939f19b";
            var client = new RestClient(baseurl + "/Bundle/" + bundleId);

            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            var bundleresponse = JsonConvert.DeserializeObject<PatientResponseModel.PatientAnswerResponse>(response.Content);

            PatientResponse responses = new PatientResponse();
            //List<Question> questions = new List<Question>();

            List<Question> questions = new List<Question>();
            if(bundleresponse.entry[0].resource.item!=null)
            {
                string prevquestion = "";
                List<string> repeatanswers = new List<string>();
                foreach (var item in bundleresponse.entry[0].resource.item)
                {                    
                        Question qna = new Question();
                        
                        if(questions.Count==0)
                        {
                            qna.question = item.text;
                            prevquestion = item.text;
                            repeatanswers.Add(item.answer[0].item[0].text);                            
                            //qna.answer = repeatanswers;
                            questions.Add(qna);
                        }
                        else
                        {
                            if (prevquestion == item.text)
                            {                                
                                    repeatanswers.Add(item.answer[0].item[0].text);
                                //questions[questions.Count - 1].answer.Add(item.answer[0].item[0].text);                            
                            }
                            else
                            {
                                //List<string> lstanswers = new List<string>();
                                var lstanswers= repeatanswers.Distinct().ToList();
                                questions[questions.Count - 1].answer = lstanswers;
                                
                                qna.question = item.text;
                                prevquestion = item.text;
                                repeatanswers.Clear();
                                repeatanswers.Add(item.answer[0].item[0].text);
                                //qna.answer = repeatanswers;
                                questions.Add(qna);
                            }
                        }                         
                }
                questions[questions.Count - 1].answer = repeatanswers;
            }            

            responses.qna = questions;
            return responses;
        }

        public static async Task<List<Models.SocialHistorydetail>> GetSocialHistoryData(ILogger log, string bundleID, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        {
            List<Models.SocialHistorydetail> lstSocHistDet = new List<Models.SocialHistorydetail>();


            var client = new RestClient(baseurl + "/Bundle/" + bundleID);

            var socrequest = new RestRequest(Method.GET);
            socrequest.AddHeader("Content-Type", "application/json");
            socrequest.AddHeader("Accept", "application/json");
            socrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            socrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse socresponse = await client.ExecuteAsync(socrequest);
            var socbundleresponse = JsonConvert.DeserializeObject<Models.SocialHistoryModel.Root>(socresponse.Content);
            var entries = socbundleresponse.entry;
            foreach (var entry in entries)
            {
                Models.SocialHistorydetail SocHistDet = new Models.SocialHistorydetail();
                SocHistDet.detail = entry.resource.code.coding[0].display;
                SocHistDet.entrycode = entry.resource.category[0].text;
                SocHistDet.status = "social";
                SocHistDet.section = "History";
                SocHistDet.displaydate = entry.resource.effectiveDateTime.ToString();

                if (entry.resource.code.coding.Count > 1)
                {
                    List<Models.ICDCode> lstcodes = new List<Models.ICDCode>();
                    Models.ICDCode iccodes = new Models.ICDCode();
                    iccodes.icd9 = entry.resource.code.coding[1].code;
                    iccodes.icd10 = entry.resource.code.coding[2].code;
                    lstcodes.Add(iccodes);
                    SocHistDet.ICDCode = lstcodes;
                }
                lstSocHistDet.Add(SocHistDet);
            }



            return lstSocHistDet;
        }
        public static async Task<List<Models.FamilyHistorydetail>> GetFamilyHistoryData(ILogger log, string bundleID, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        {
            List<Models.FamilyHistorydetail> lstfamHistDet = new List<Models.FamilyHistorydetail>();
            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var famrequest = new RestRequest(Method.GET);
            famrequest.AddHeader("Content-Type", "application/json");
            famrequest.AddHeader("Accept", "application/json");
            famrequest.AddHeader("Authorization", "Bearer " + bearertoken);
            famrequest.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse famresponse = await client.ExecuteAsync(famrequest);
            var fambundleresponse = JsonConvert.DeserializeObject<Models.FamilyHistoryModel.Root>(famresponse.Content);
            //var entries = fambundleresponse.entry;
            foreach (var entry in fambundleresponse.entry)
            {
                Models.FamilyHistorydetail famHistDet = new Models.FamilyHistorydetail();
                famHistDet.detail = entry.resource.condition[0].code.coding[0].display;
                famHistDet.entrycode = entry.resource.name;
                famHistDet.status = "family";
                famHistDet.section = "History";
                famHistDet.displaydate = entry.resource.date.ToString();

                if (entry.resource.condition[0].code.coding.Count > 1)
                {
                    List<Models.ICDCode> lstcodes = new List<Models.ICDCode>();
                    Models.ICDCode iccodes = new Models.ICDCode();
                    iccodes.icd9 = entry.resource.condition[0].code.coding[1].code;
                    iccodes.icd10 = entry.resource.condition[0].code.coding[2].code;
                    lstcodes.Add(iccodes);
                    famHistDet.ICDCode = lstcodes;
                }
                List<string> lstrelations = new List<string>();
                foreach (var relation in entry.resource.relationship.coding)
                {
                    lstrelations.Add(relation.code);
                }
                famHistDet.relations = lstrelations;
                lstfamHistDet.Add(famHistDet);
            }



            return lstfamHistDet;
        }
        public static async Task<List<Models.VitalsDetails>> GetVitals(ILogger log, string bundleID, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        {
            var client2 = new RestClient(baseurl + "/Bundle/" + bundleID);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client2.ExecuteAsync(request);
            var bundleResponse = JsonConvert.DeserializeObject<Models.VitalsModel.VitalsDetails>(response.Content);

            List<Models.VitalsDetails> vitalsList = new List<Models.VitalsDetails>();

            var entries = bundleResponse.entry;
            foreach (var entry in entries)
            {

                var vitalDetail = new Models.VitalsDetails();
                vitalDetail.section = "vitals";
                vitalDetail.code = entry.resource.id;
                vitalDetail.entrycode = entry.resource.category[0].coding[0].code;
                vitalDetail.description = entry.resource.code.text;
                vitalDetail.status = entry.resource.performer[0].display;
                vitalDetail.detail = (entry.resource.valueQuantity.value.ToString() + " " + entry.resource.valueQuantity.unit).TrimEnd();
                vitalDetail.displaydate = entry.resource.effectiveDateTime.ToString("MMM dd yyyy hh:mm tt");

                if (entry.resource.code.coding.Count > 1)
                {
                    List<Models.ICDCode> ICDCodeList = new List<Models.ICDCode>();
                    var responseCode = new Models.ICDCode();
                    if (entry.resource.code.coding[1].code != null) responseCode.icd9 = entry.resource.code.coding[1].code;
                    if (entry.resource.code.coding[2].code != null) responseCode.icd10 = entry.resource.code.coding[2].code;
                    ICDCodeList.Add(responseCode);
                    vitalDetail.ICDCode = ICDCodeList;
                }

                vitalsList.Add(vitalDetail);

            }

            return vitalsList;
        }
        public static async Task<Demographics> GetDemographics(FhirClient client, ILogger log, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        {
            var conditions = new SearchParams();
            conditions.Add("identifier", patientID);
            Patient pat = new Patient();
            Bundle results = client.Search<Patient>(conditions);
            if (results.Entry.Count > 0)
            {
                var fhirpatientId = results.Entry[0].Resource.Id;
                log.LogInformation("Demographics FHIRPatientID:" + fhirpatientId);
                var location = new Uri(baseurl+"/Patient/" + fhirpatientId);
                pat = client.Read<Patient>(location);
            }

            List<DemographicsDetails> DemographicsList = new List<DemographicsDetails>();
            Demographics demographicsobj = new Demographics();


            var demographicDetail = new Models.DemographicsDetails();

            string dateinput = pat.BirthDate;
            DateTime now = DateTime.Now;
            DateTime givenDate = DateTime.Parse(dateinput);
            int days = now.Subtract(givenDate).Days;
            int age = (int)Math.Floor(days / 365.24219);
            string ageString = age.ToString();
            if(pat.Name.Count>0)
            {
                string fullName = pat.Name.FirstOrDefault().Text;
                demographicDetail.FullName = pat.Name.FirstOrDefault().Text;
                demographicDetail.FirstName = pat.Name.FirstOrDefault().TextElement.Value;
                demographicDetail.LastName = pat.Name.FirstOrDefault().Family;
            }
            
            demographicDetail.age = ageString;
            demographicDetail.DOB = pat.BirthDate;
            demographicDetail.BirthGender = pat.Gender.ToString();
            Models.Address addressdata = new Models.Address();
            if (pat.MaritalStatus != null)
            {
                demographicDetail.MaritalStatus = pat.MaritalStatus.Text;
            }

            if (pat.Address.Count > 0)
            {
                addressdata.Address1 = pat.Address.FirstOrDefault().Text;
                addressdata.City = pat.Address.FirstOrDefault().City;
                addressdata.State = pat.Address.FirstOrDefault().State;
                addressdata.zipcode = pat.Address.FirstOrDefault().PostalCode;
                addressdata.country = pat.Address.FirstOrDefault().Country;
            }
            
            if (pat.Telecom.Count > 0)
            {
                foreach (var tel in pat.Telecom)
                {
                    if (tel.System == ContactPoint.ContactPointSystem.Phone)
                        addressdata.CellPhone = tel.Value;
                    if (tel.System == ContactPoint.ContactPointSystem.Email)
                        addressdata.Email = addressdata.Email + ";" + tel.Value;
                }               
            }

            demographicDetail.address = addressdata;
            DemographicsList.Add(demographicDetail);
            demographicsobj.DemographicsDetails = DemographicsList;



            return (demographicsobj);
        }
        public static async Task<ConditionList> GetConditions(ILogger log, string bundleID, string baseurl, string bearertoken, CancellationToken cancellationToken)
        {
            Models.ConditionList data = new Models.ConditionList();
            var client = new RestClient(baseurl + "/Bundle/" + bundleID);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + bearertoken);
            request.AddParameter("application/json", "", ParameterType.RequestBody);
            IRestResponse response = await client.ExecuteAsync(request);
            var bundleresponse = JsonConvert.DeserializeObject<Models.ConditionModel.Root>(response.Content);
            data.Problems = new List<ConditionData>();
            foreach (var item in bundleresponse.entry)
            {
                var con = new Models.ConditionData();
                con.VerificationStatus = item.resource.verificationStatus.text;
                con.ClinicalStatus = item.resource.clinicalStatus.text;
                con.Name = item.resource.code.text;
                
                if(item.resource.code.coding != null)
                {
                    foreach (var code in item.resource.code.coding)
                    {
                        if (code.display == "RxNorm")
                        {
                            con.RxNorm = code.code;
                        }
                        if(code.display == "ICDCode")
                        {
                            con.ICDCode = code.code;
                        }
                    }
                }
                foreach (var cat in item.resource.category)
                {
                    if(cat.coding != null)
                    {
                        if (cat.coding[0].display == "Loinc")
                        {
                            con.LoincCode = cat.coding[0].code;
                        }
                    }
                }
                data.Problems.Add(con);
            }
            return data;
        }

        private static Random randomgen = new Random();
        public static string GenerateRandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[randomgen.Next(s.Length)]).ToArray());
        }
        public static string GenerateErrorId()
        {
            return $"{DateTime.Now}_{GenerateRandomString(8)}".Replace(" ", "_").Replace("/", "_");
        }
        public static string GetEnvironmentVariable(string name)
        {
            return System.Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }

        public static async Task<List<string>> GetVaultValue(string key)
        {
            var client = new RestClient(GetEnvironmentVariable("keyurl"));
            var request = new RestRequest(Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Accept", "application/json");
            request.AddParameter("SecretKey", key, ParameterType.GetOrPost);
            IRestResponse response = await client.ExecuteAsync(request);
            var bundleResponse = response.Content;
            var lst = JsonConvert.DeserializeObject<List<string>>(bundleResponse);
            return lst;
        }
        public static async System.Threading.Tasks.Task SendMessagesToEventHub(EventHubClient eventhubclient, ILogger log,string message)
        {
            try
            {
               // var message = $"Message pavan testing";                
                await eventhubclient.SendAsync(new EventData(Encoding.UTF8.GetBytes(message)));
            }
            catch (Exception exception)
            {
                log.LogInformation($"{DateTime.Now} > Exception: {exception.Message}");
            }
            await System.Threading.Tasks.Task.Delay(10);
        }
        public enum Extensions
        {
            RiskFactors,
            careoptions
        }
    }
    public class sessionresponse
    {          
        public string Status { get; set; }
        public string Comment { get; set; }
        public string SessionID { get; set; }
        public List<string> ProviderID { get; set; }
        public List<string> ProviderDisplayName { get; set; }
        public string Gender { get; set; }
        public string BirthDate { get; set; }
    }
}

