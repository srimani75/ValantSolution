﻿using FhirCronService;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Optum.Fhir.Models;
using System.Linq;
using System.Threading.Tasks;

namespace FhirSave.Processors
{
    public class CoverageProcessor
    {

        public static async Task<Patient> SavePatientInsurance(InsuranceInfo insInfo, ILogger log = null)
        {

            FhirClient fhClient = Utilities.BuildFhirClient();
            bool isNew = false;
            Patient fhirPat = Utilities.LookupResource<Patient>(insInfo.PatientId, fhClient);
            Coverage cvrg = insInfo.FhirInsuranceId != null ?
                Utilities.ReadResource<Coverage>(insInfo.FhirInsuranceId, "Coverage", fhClient) :
                Utilities.LookupResource<Coverage>(insInfo.Id,fhClient);
            if (cvrg == null)
            {
                cvrg = new Coverage();
                cvrg.Identifier = new System.Collections.Generic.List<Identifier>();
                isNew = true;
            }
            cvrg.Identifier.Clear();
            cvrg.Identifier.Add(new Identifier
            {
                System = "MemberId",
                Value = insInfo.MemberId
            });
            cvrg.Identifier.Add(new Identifier
            {
                System = "GroupNumber",
                Value = insInfo.GroupNumber
            });
            cvrg.Identifier.Add(new Identifier
            {
                System = "InsuranceProvider",
                Value = insInfo.InsuranceProvider
            });
            cvrg.Identifier.Add(new Identifier
            {
                System = "PayerId",
                Value = insInfo.PayerId
            });

            cvrg.Beneficiary = new ResourceReference { Reference = string.Format("Patient/{0}", fhirPat.Id) };
            if(insInfo.PolicyHolder != null)
                cvrg.Subscriber = new ResourceReference { Reference = string.Format("Patient/{0}", insInfo.PolicyHolder) };
            
            if (insInfo.RelationshipToIinsured != null)
            {
                cvrg.Relationship = new CodeableConcept
                {
                    Coding = new System.Collections.Generic.List<Coding>()
                {
                    new Coding
                    {
                        Code = insInfo.RelationshipToIinsured
                    }
                }
                };
            }
            cvrg.Status = FinancialResourceStatusCodes.Active;
            cvrg.Payor = new System.Collections.Generic.List<ResourceReference>
            {
                new ResourceReference{ Display = insInfo.PayerId}
            };

            Coverage retCvrg;
            bool? v = cvrg.Beneficiary?.Reference?.Contains(fhirPat.Id);
            if (cvrg.Beneficiary?.Reference != null && v.HasValue)
            {
                //retCvrg = await fhClient.CreateAsync(cvrg);
                retCvrg =  fhClient.Create(cvrg);
            }
            else
            {
                //retCvrg = await fhClient.UpdateAsync(cvrg);
                retCvrg =  fhClient.Update(cvrg);
            }
            
            Bundle bndlCvrg = Utilities.ReadResource<Bundle>(Utilities.GetBundleId("CoverageBundle", fhirPat),"Bundle", fhClient);
            if (bndlCvrg != null)
            {
                //var obj = bndlCvrg.Entry.Where(x => x.FullUrl == "Coverage/" + retCvrg.Id).FirstOrDefault();
                if (bndlCvrg.Entry.Where(x => x.FullUrl == "Coverage/" + retCvrg.Id).FirstOrDefault() == null)
                {
                    
                    bndlCvrg.AddResourceEntry(retCvrg, string.Format("{0}/{1}", retCvrg.TypeName, retCvrg.Id));
                    bndlCvrg = fhClient.UpdateAsync(bndlCvrg).Result;
                }
            }
            else
            {
                
                bndlCvrg = new Bundle { Type = Bundle.BundleType.Collection };
                bndlCvrg.AddResourceEntry(retCvrg, string.Format("{0}/{1}", retCvrg.TypeName, retCvrg.Id));
                bndlCvrg = fhClient.CreateAsync(bndlCvrg).Result;
                fhirPat.Identifier.Add(new Identifier("CoverageBundle", bndlCvrg.Id));
            }

            if (insInfo.InsuranceCardImages != null && insInfo.InsuranceCardImages.Length > 0)
            {
                if (fhirPat.Photo == null)
                    fhirPat.Photo = new System.Collections.Generic.List<Attachment>();

                foreach (var img in insInfo.InsuranceCardImages)
                {
                    fhirPat.Photo.Add(ImageProcessor.BuildImage(img));
                }
            }
            return fhClient.UpdateAsync(fhirPat).Result;
        }
    }
}
