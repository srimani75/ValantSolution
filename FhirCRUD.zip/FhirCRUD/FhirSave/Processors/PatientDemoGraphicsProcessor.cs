﻿using FhirCronService.Models;
using FhirSave.Processors;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Optum.Fhir.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using static Hl7.Fhir.Model.ContactPoint;

namespace FhirCronService.Processors
{
    public class PatientDemoGraphicsProcessor
    {
        /*
        //data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAADElEQVQImWNgoBMAAABpAAFEI8ARAAAAAElFTkSuQmCC
        // from Element: extension
        "contentType" : "<code>", // Mime type of the content, with charset etc.
        "language" : "<code>", // Human language of the content (BCP-47)
        "data" : "<base64Binary>", // Data inline, base64ed
        "url" : "<url>", // Uri where the data can be found
        "size" : "<unsignedInt>", // Number of bytes of content (if url provided)
        "hash" : "<base64Binary>", // Hash of the data (sha-1, base64ed)
        "title" : "<string>", // Label to display in place of the data
        "creation" : "<dateTime>" // Date attachment was first created
        */

        public static async System.Threading.Tasks.Task<Patient> SavePatientDemographics(PatientDemographics objPat, ILogger log)
        {
            FhirClient fhClient = Utilities.BuildFhirClient(log);
            Patient fhirPat = objPat.FhirPatientId != null ?
                Utilities.ReadResource<Patient>(objPat.FhirPatientId, "Patient", fhClient) :
                Utilities.LookupResource<Patient>(objPat.PatientId, fhClient);

            if (fhirPat != null)
            {
                log?.LogInformation("Patient found successfully...");

                if (fhirPat.Name == null)
                    fhirPat.Name = new List<HumanName>();
                if (fhirPat.Address == null)
                    fhirPat.Address = new List<Address>();
                if (fhirPat.Photo == null)
                    fhirPat.Photo = new List<Attachment>();
                if (fhirPat.Identifier == null)
                    fhirPat.Identifier = new List<Identifier>();
                if (fhirPat.Contact == null)
                    fhirPat.Contact = new List<Patient.ContactComponent>();
                if (fhirPat.Telecom == null)
                    fhirPat.Telecom = new List<ContactPoint>();


                if (objPat.SSN != null)
                {
                    fhirPat.Identifier.Add
                        (
                        new Identifier
                        {
                            System = "SSN",
                            Value = objPat.SSN
                        });
                }


                if (Enum.TryParse(objPat.Gender, out AdministrativeGender patGender))
                {
                    fhirPat.Gender = patGender;
                }

                if (objPat.EmergencyContact != null)
                {
                    Patient.ContactComponent fhirEmergency = BuildContact(objPat.EmergencyContact, "emergency");
                    fhirPat.Contact.Add(fhirEmergency);
                }

                if (objPat.EmployerInformation != null)
                {
                    Patient.ContactComponent fhirEmployer = BuildContact(objPat.EmployerInformation, "employer");
                    fhirPat.Contact.Add(fhirEmployer);
                }

                if (objPat.ReligioisAffiliation != null)
                {
                    fhirPat.Extension.Add(new Hl7.Fhir.Model.Extension
                    {
                        Value = new Coding
                        {
                            Display = objPat.ReligioisAffiliation,
                            System = "ReligioisAffiliation"
                        },
                        Url = "http://terminology.hl7.org/CodeSystem/v3-ReligiousAffiliation"
                    });
                }
                if (objPat.Ethnicity != null)
                {
                    fhirPat.Extension.Add(new Hl7.Fhir.Model.Extension
                    {
                        Value = new Coding
                        {
                            Display = objPat.Ethnicity,
                            System = "Ethnicity"
                        },
                        Url = "http://terminology.hl7.org/CodeSystem/v3-Ethnicity"
                    });
                }

                if (objPat.Race != null)
                {
                    fhirPat.Extension.Add(new Hl7.Fhir.Model.Extension
                    {
                        Value = new Coding
                        {
                            Display = objPat.Race,
                            System = "Race"
                        },
                        Url = "http://terminology.hl7.org/CodeSystem/v3-Race"
                    });
                }

                foreach (var tc in objPat.telecom)
                {
                    ContactPoint cp = new ContactPoint();
                    bool hasUse = Enum.TryParse(tc.use, out ContactPointUse cntctUse);
                    bool hasSystem = Enum.TryParse(tc.system, out ContactPointSystem cntctSystem);
                    if (hasUse)
                    {   
                        cp.Use = cntctUse;
                    }
                    if (hasSystem)
                    {
                        cp.System = cntctSystem;
                    }
                    if (hasUse && hasSystem)
                    {
                        fhirPat.Telecom.RemoveAll(x => x.System == cntctSystem && x.Use == cntctUse);
                    }
                    cp.Value = tc.value;
                    fhirPat.Telecom.Add(cp);
                }

                if (objPat.Names != null)
                {
                    foreach (var nm in objPat.Names)
                    {
                        HumanName hmnName = new HumanName
                        {
                            Family = nm?.FamilyName,
                            Given = nm?.GivenName,
                            Text = nm?.NameText,
                            Use = Enum.Parse<HumanName.NameUse>(nm.NameUse)
                        };
                        fhirPat.Name.Add(hmnName);
                    }
                }

                if (objPat.Addresses != null)
                {
                    foreach (var addr in objPat.Addresses)
                    {
                        fhirPat.Address.Add(
                            new Address
                            {
                                City = addr?.City,
                                Country = addr?.Country,
                                PostalCode = addr?.PostalCode,
                                State = addr?.State,
                                Line = addr?.Lines,
                                Use = Enum.Parse<Address.AddressUse>(addr?.AddressUse),
                                Text = addr?.Lines?.FirstOrDefault()
                            }
                            );
                    }
                }

                if (objPat.PhotoIdentifiers != null && objPat.PhotoIdentifiers.Length > 0)
                {
                    foreach (var img in objPat.PhotoIdentifiers)
                    {
                        fhirPat.Photo.Add(ImageProcessor.BuildImage(img));
                    }
                }
                if (objPat.GurantorInformation != null)
                {
                    fhirPat.Link = new List<Patient.LinkComponent>();
                    RelatedPerson relaredPers = BuildelatedPerson(objPat.GurantorInformation, fhirPat);
                    RelatedPerson retPers = fhClient.Create(relaredPers);
                    fhirPat.Link.Add(new Patient.LinkComponent
                    {
                        Other = new ResourceReference
                        {
                            Reference = string.Format("RelatedPerson/{0}", retPers.Id)
                        }
                    });
                }
                return await fhClient.UpdateAsync(fhirPat);
            }
            else
            {
                log?.LogInformation("Could not find patient...");
            }
            return fhirPat;
        }

        private static RelatedPerson BuildelatedPerson(RelatedPersonInfo cntct, Patient fhirPat)
        {
            RelatedPerson fhirRelated = new RelatedPerson();
            fhirRelated.Address = new List<Address>();
            fhirRelated.Name = new List<HumanName>();
            fhirRelated.Relationship = new List<CodeableConcept>();
            fhirRelated.Telecom = new List<ContactPoint>();

            fhirRelated.Identifier = new List<Identifier>()
            {
                new Identifier
                {
                    System= "SSN",
                    Value = cntct.ssn
                }
            };

            fhirRelated.Patient = new ResourceReference
            {
                Reference = string.Format("Patient/{0}", fhirPat)
            };
            if (cntct.name != null)
            {
                foreach (var nmInfo in cntct.name)
                {
                    HumanName nm = new HumanName
                    {
                        Family = nmInfo.FamilyName,
                        Given = nmInfo.GivenName,
                        Text = nmInfo.NameText
                    };
                    if (Enum.TryParse(nmInfo.NameUse, out HumanName.NameUse use))
                        nm.Use = use;
                    fhirRelated.Name.Add(nm);
                }
            }
            if (cntct.telecom != null)
            {
                foreach (var cntctTelecom in cntct.telecom)
                {
                    ContactPoint cp = new ContactPoint();
                    if (Enum.TryParse(cntctTelecom.use, out ContactPoint.ContactPointUse cntctUse))
                    {
                        cp.Use = cntctUse;
                    }
                    if (Enum.TryParse(cntctTelecom.system, out ContactPoint.ContactPointSystem cntctSystem))
                    {
                        cp.System = cntctSystem;
                    }
                    cp.Value = cntctTelecom.value;
                    fhirRelated.Telecom.Add(cp);
                }
            }
            if (cntct.photo != null)
            {
                foreach (var img in cntct.photo)
                {
                    Attachment attch = ImageProcessor.BuildImage(img);
                    fhirRelated.Photo.Add(attch);
                }
            }
            if (cntct.address != null)
            {
                foreach (var addrInfo in cntct.address)
                {
                    Address addr = new Address
                    {
                        City = addrInfo.City,
                        Country = addrInfo.Country,
                        State = addrInfo.State,
                        Line = addrInfo.Lines,
                        PostalCode = addrInfo.PostalCode
                    };
                    fhirRelated.Address.Add(addr);
                }
            }
            if (cntct.relationship != null)
            {
                fhirRelated.Relationship.Add(
                    new CodeableConcept
                    {
                        Coding = new List<Coding>()
                        {
                            new Coding
                            {
                                Display = cntct.relationship,
                                System = "http://terminology.hl7.org/CodeSystem/v3-RoleCode"
                            }
                        }
                    });
                fhirRelated.Relationship.Add(
                new CodeableConcept
                {
                    Coding = new List<Coding>()
                        {
                            new Coding
                            {
                                Display = "Guarantor",
                                System = "http://terminology.hl7.org/CodeSystem/v3-RoleCode"
                            }
                        }
                }
                    );
            }
            return fhirRelated;
        }

        private static Patient.ContactComponent BuildContact(ContactInfo cntct, string relationShip)
        {

            Patient.ContactComponent fhirContact = new Patient.ContactComponent();
            fhirContact.Relationship = new List<CodeableConcept>();
            fhirContact.Telecom = new List<ContactPoint>();

            if (cntct.name != null)
            {
                fhirContact.Name = new HumanName();
                fhirContact.Name.Family = cntct.name.FamilyName;
                fhirContact.Name.Given = cntct.name.GivenName;
                fhirContact.Name.Text = cntct.name.NameText;
                if (Enum.TryParse(cntct?.name.NameUse, out HumanName.NameUse use))
                    fhirContact.Name.Use = use;
            }
            if (cntct.address != null)
            {
                fhirContact.Address = new Address
                {
                    City = cntct.address.City,
                    Country = cntct.address.Country,
                    State = cntct.address.State,
                    Line = cntct.address.Lines,
                    PostalCode = cntct.address.PostalCode
                };
            }
            if (cntct.telecom != null)
            {
                foreach (var cntctTelecom in cntct.telecom)
                {
                    ContactPoint cp = new ContactPoint();
                    if (Enum.TryParse(cntctTelecom.use, out ContactPointUse cntctUse))
                    {
                        cp.Use = cntctUse;
                    }
                    if (Enum.TryParse(cntctTelecom.system, out ContactPointSystem cntctSystem))
                    {
                        cp.System = cntctSystem;
                    }
                    cp.Value = cntctTelecom.value;
                    fhirContact.Telecom.Add(cp);
                }
            }
            if (relationShip == "emergency")
            {
                fhirContact.Relationship.Add
                (
                    new CodeableConcept
                    {
                        Coding = new List<Coding>()
                        {
                            new Coding
                            {
                                Code = "C",
                                Display = "Emergency Contact",
                                System = "http://terminology.hl7.org/CodeSystem/v2-0131"
                            }
                        }
                    });
            }
            if (relationShip == "employer")
            {
                fhirContact.Relationship.Add
                (
                    new CodeableConcept
                    {
                        Coding = new List<Coding>()
                        {
                            new Coding
                            {
                                Code = "E",
                                Display = "Employer",
                                System = "http://terminology.hl7.org/CodeSystem/v2-0131"
                            }
                        }
                    });
            }
            return fhirContact;
        }
    }
}
