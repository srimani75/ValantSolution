﻿using Hl7.Fhir.Model;
using Optum.Fhir.Models;
using System;
using System.Text.RegularExpressions;

namespace FhirSave.Processors
{
    public class ImageProcessor
    {
        public static Attachment BuildImage(Image img)
        {

            var base64Data = img.ImageContents.Split(new char[] { ',' })[1];
                //Regex.Match(img.ImageContents, @"data:image/(?<type>.+?),(?<data>.+)").Groups["data"].Value;
            var binData = Convert.FromBase64String(base64Data);
            //data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAADElEQVQImWNgoBMAAABpAAFEI8ARAAAAAElFTkSuQmCC
            Attachment attch = new Attachment();
            attch.Title = img.Title;
            attch.Data = binData;
            attch.Language = "en";
            attch.ContentType = "image/png";

            return attch;

        }
    }
}
