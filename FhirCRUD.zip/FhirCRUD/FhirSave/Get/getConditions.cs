using System;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Hl7.Fhir.Model;

namespace FhirSave
{
    public static class getConditions
    {
        [FunctionName("getConditions")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                BadRequestResult badresult = new BadRequestResult();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(8000);
                //var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
                var resource = "https://optum-fhirserver.azurehealthcareapis.com";
                var bearerToken = FhirToken.GetBearerToken(log);

                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });

                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                var mrn = query.Get("patientID");

                Patient patresource = Utils.ReliantUtlity.GetPatient(client, resource, mrn);
                var id = Utils.ReliantUtlity.GetBundleID("ProblemsBundle", patresource);
                var bundleid = id.Result;

                var outputval = Utils.ReliantUtlity.GetConditions(log, bundleid, resource, bearerToken, cancellationTokenSource.Token);
                return new OkObjectResult(outputval.Result);

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }
    }
}