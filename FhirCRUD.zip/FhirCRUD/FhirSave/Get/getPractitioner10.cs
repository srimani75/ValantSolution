﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using Hl7.Fhir.Model;
using FhirSave.Models.Dto;
using FhirSave.Utils;

namespace FhirSave
{
    public class getPractioner
    {
        [FunctionName("getPractioner10")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.0/getPractitioner")] HttpRequest req,
            ILogger log)
        {
            PractitionerModelDto practitioner = new PractitionerModelDto();

            try
            {
                var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                var PatID = query.Get("PatientID");

                if (string.IsNullOrEmpty(PatID)) 
                {
                    throw new ArgumentNullException("This HTTP triggered function executed successfully. Pass a Patient Id in the query string or in the request body for a personalized response.", "Body");
                }

                string bearerToken = FhirToken.GetBearerToken(log);

                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });

                Hl7.Fhir.Model.Patient patresource = Utils.ReliantUtlity.GetPatient(client, resource, PatID);

                if (patresource?.GeneralPractitioner.Count == 0)
                {
                    return new OkObjectResult(practitioner);
                }

                string practitionerRef = string.Empty;
                if (patresource?.GeneralPractitioner?[0].Display != null)
                {
                    practitionerRef = patresource?.GeneralPractitioner?[0].Display;
                    if (resource.EndsWith('/') == false)
                    {
                        resource += '/';
                    }
                    resource = resource + practitionerRef;
                } 
                else
                {
                    resource = patresource?.GeneralPractitioner?[0].Reference;
                }

                practitioner = await Utils.PatientCheckinUtility.GetPractitioner(resource, bearerToken);

                return new OkObjectResult(practitioner);
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }

        //[FunctionName("getPractioner10")]
        //public async Task<IActionResult> Run(
        //    [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.0/getPractioner")] HttpRequest req,
        //    ILogger log)
        //{
        //    string responseMessage = string.Empty;
        //    var content = new StreamReader(req.Body).ReadToEndAsync();
        //    try
        //    {
        //        log.LogInformation("C# HTTP trigger function processed a request.");
        //        BadRequestResult badresult = new BadRequestResult();

        //        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        //        cancellationTokenSource.CancelAfter(8000);

        //        if (string.IsNullOrEmpty(content.Result))
        //        {
        //            throw new ArgumentNullException("The body of the request is null or empty", "Body");
        //        }
        //        reqBody reqdata = JsonConvert.DeserializeObject<reqBody>(content.Result);
        //        var PatID = reqdata.patientID;
        //        var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");

        //        //FhirToken fhToken = new FhirToken(configuration);
        //        //string bearerToken = fhToken.GetBearerToken(log);
        //        //var resource = "https://optum-fhirserver.azurehealthcareapis.com";

        //        string bearerToken = FhirToken.GetBearerToken(log);

        //        var messageHandler = new HttpClientEventHandler();
        //        messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
        //        {
        //            e.RawRequest.Headers
        //            .Add("Authorization", $"Bearer {bearerToken}");
        //        };

        //        Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
        //        {
        //            PreferredFormat = ResourceFormat.Json
        //        });

        //        //Hl7.Fhir.Model.Patient patresource = Utils.ReliantUtlity.GetPractitioner(client, resource, providerId);
        //        //var bundleId = await Utils.ReliantUtlity.GetBundleID("AllergiesBundle", patresource);
        //        Practitioner practitioner = new Practitioner();
        //        var practionerId = "e7b03152-b7e6-495b-8f39-ecd9cee86a3d";
        //        var practitionerx = await Utils.PatientCheckinUtility.GetPractitioner(practionerId, resource, bearerToken);

        //        return new OkObjectResult(practitioner);

        //    }
        //    catch (Exception ex)
        //    {
        //        var errorResonse = new Models.ErrorResponse();
        //        errorResonse.error = Guid.NewGuid().ToString();
        //        errorResonse.message = ex.Message;
        //        errorResonse.detail = ex;

        //        var result = new OkObjectResult(errorResonse);
        //        result.StatusCode = StatusCodes.Status500InternalServerError;
        //        return result;
        //    }
        //}
    }
}
