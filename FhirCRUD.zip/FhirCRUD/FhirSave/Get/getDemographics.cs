using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using FhirSave.Models;
using Microsoft.Azure.EventHubs;

namespace FhirSave
{
    public class getDemographics
    {
        public static string Eventhubendpoint = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubEndpoint");
        public static string EventhubKey = Utils.ReliantUtlity.GetEnvironmentVariable("EventHubKey");
        public static string env = Utils.ReliantUtlity.GetEnvironmentVariable("AGG_ID");

        //public static string Eventhubendpoint = "lp-cl-eastus-eventhub-07c73293.servicebus.windows.net/";// Utils.ReliantUtlity.GetEnvironmentVariable("EventHubEndpoint");
        //public static string EventhubKey = "+1tKqvZhKF5l2maA3+WoFmqJ2Bmt3JPtD4BEvrA0EIM=";// Utils.ReliantUtlity.GetEnvironmentVariable("EventHubKey");

        //public static string env = "";// Utils.ReliantUtlity.GetEnvironmentVariable("AGG_ID");

        [FunctionName("getDemographics")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            string responseMessage = string.Empty;
            var connectionStringBuilder = new EventHubsConnectionStringBuilder("Endpoint=sb://" + Eventhubendpoint + ";SharedAccessKeyName=lp-cl-auth-rule;SharedAccessKey=" + EventhubKey)
            {
                EntityPath = "application-logs"
            };
            log.LogInformation(connectionStringBuilder.ToString());
            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionStringBuilder.ToString());
            var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
            //var resource = "https://optum-fhirserver-prod.azurehealthcareapis.com";

            var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
            var PatID = query.Get("PatientID");
            // var content = new StreamReader(req.Body).ReadToEndAsync();
            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                BadRequestResult badresult = new BadRequestResult();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(8000);            
               
                if(PatID!=null)
                {
                    var bearerToken = FhirToken.GetBearerToken(log);

                    var messageHandler = new HttpClientEventHandler();
                    messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                    {
                        e.RawRequest.Headers
                        .Add("Authorization", $"Bearer {bearerToken}");
                    };

                    Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                    {
                        PreferredFormat = ResourceFormat.Json
                    });
                    Demographics demographics = new Demographics();
                    demographics = await Utils.ReliantUtlity.GetDemographics(client, log, resource, bearerToken, PatID, cancellationTokenSource.Token);
                    return new OkObjectResult(demographics);
                }
                else
                {
                    var errorResonse = new Models.ErrorResponse();
                    //replace with actual id
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = "Patient ID is null";
                    errorResonse.detail = "Patient ID is null";
                    log.LogInformation(errorResonse.error);
                    log.LogError(errorResonse.error);
                    var evehubresponse = new Models.EventHubErrorResponse();
                    var eventhubdata = new Models.Data();
                    eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                    evehubresponse.data = eventhubdata;
                    evehubresponse.agg = env+"-Demographics";
                    evehubresponse.type = "Error";
                    await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }
                
                

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = "Demographics call failed while getting data";
                errorResonse.detail = "Patient ID is:"+PatID;
                log.LogInformation(errorResonse.error);
                log.LogError(errorResonse.error);
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env+"-Demographics";
                evehubresponse.type = "Error";
                await Utils.ReliantUtlity.SendMessagesToEventHub(eventHubClient, log, JsonConvert.SerializeObject(evehubresponse));
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }

        }
    }
}