using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System.Text.RegularExpressions;

namespace FhirSave
{
    public static class GetProviderImage
    {
        [FunctionName("GetProviderImage")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");
            string responseMessage = "";
            try
            {
                string ProviderFHIRID = req.Query["ProviderID"];
                string accesstoken = req.Query["accesstoken"];

                var client = new RestClient("https://fhirnp.reliantmedicalgroup.org/FHIRPOC/api/FHIR/R4/Practitioner/" + ProviderFHIRID);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + accesstoken);
                IRestResponse response = client.Execute(request);
                var BinaryID = response.Content.Split("Binary/")[1].Split("/>")[0].TrimEnd('\"');

                var client1 = new RestClient("https://fhirnp.reliantmedicalgroup.org/FHIRPOC/api/FHIR/R4/Binary/eKXJ.qi0gLk4gj-BPlBULFw3");                
                var request1 = new RestRequest(Method.GET);
                request1.AddHeader("Authorization", "Bearer "+ accesstoken);            
               
                IRestResponse response1 = client1.Execute(request1);
                if (IsBase64String(response1.Content))
                {
                    string filePath = "c:\\users\\pkruam\\MyImage.jpg";
                    File.WriteAllBytes(filePath, Convert.FromBase64String(response1.Content));
                }


                    
            }
           catch(Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = "Session initiating failed";
                errorResonse.detail = "Reliant session webservice did not return any session";
                log.LogInformation(errorResonse.error);
                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }

            return new OkObjectResult(responseMessage);
        }
        public static bool IsBase64String(this string s)
        {
            s = s.Trim();
            return (s.Length % 4 == 0) && Regex.IsMatch(s, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);

        }
    }
}
