﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using Hl7.Fhir.Model;
using FhirSave.Utils;

namespace FhirSave
{
    public class getImmunization11
    {
        [FunctionName("getImmunization11")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.1/getImmunization")] HttpRequest req,
            ILogger log)
        {
            Models.Immunization immunization = new Models.Immunization();

            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                BadRequestResult badresult = new BadRequestResult();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(8000);
                var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");

                var bearerToken = FhirToken.GetBearerToken(log);
                //var bearerToken = FhirToken.GetBearerTokenDirect(log);

                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });

                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                var mrn = query.Get("PatientID");
                if (mrn == string.Empty || mrn == null)
                {
                    var errorResonse = new Models.ErrorResponse();
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = "No patient Id given.";
                    errorResonse.detail = "No patient Id given.";

                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

                Patient patresource = Utils.ReliantUtlity.GetPatient(client, resource, mrn);
                if (patresource.Id == null)
                {
                    var errorResonse = new Models.ErrorResponse();
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = $"No patient {mrn}.";
                    errorResonse.detail = $"No patient {mrn}.";

                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

                var id = Utils.ReliantUtlity.GetBundleID("ImmunizationBundle", patresource);
                var bundleid = id.Result;
                if (string.IsNullOrEmpty(bundleid))
                {
                    var errorResonse = new Models.ErrorResponse();
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = $"No immunization bundle Id given for patient {mrn}.";
                    errorResonse.detail = $"No immunization bundle Id given for patient {mrn}.";

                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

                var outputval = Utils.PatientCheckinUtility.GetImmunization(log, bundleid, resource, bearerToken, cancellationTokenSource.Token);
                
                immunization.ImmunizationList = outputval.Result;

                return new OkObjectResult(immunization);
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }
    }
}
