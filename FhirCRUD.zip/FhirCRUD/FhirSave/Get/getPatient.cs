﻿using FhirSave.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Hl7.Fhir.Rest;
using Hl7.Fhir.Model;
using Microsoft.Azure.EventHubs;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using FhirSave.Utils;

namespace FhirSave
{
    class getPatientFhir
    {
        public static async Task<Patient> GetPatientBundle(FhirClient client, ILogger log, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        {
            Patient patient = new Patient();

            GetDemographics(client, log, baseurl, bearertoken, patientID, cancellationToken);
            // something like this --> patient.coverage = GetCoverage(client, log, baseurl, bearertoken, patientID, cancellationToken);


            // TBD
            //GetInsurance(client, log, baseurl, bearertoken, patientID, cancellationToken);
            //GetAllergies(client, log, baseurl, bearertoken, patientID, cancellationToken);
            
            
            return null;
        }

        public static async Task<Demographics> GetDemographics(FhirClient client, ILogger log, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        {
            Demographics d = await PatientCheckinUtility.GetDemographics(client, log, baseurl, bearertoken, patientID, cancellationToken);
            return d;
        }

        //public static async Task<CoverageModelSummary> GetCoverage(FhirClient client, ILogger log, string baseurl, string bearertoken, string patientID, CancellationToken cancellationToken)
        //{
        //    CoverageModelSummary d = await PatientCheckinUtility.GetCoverage("", patientID, bearertoken);
        //    return d;
        //}
    }
}
