using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.Cosmos;
using System.Collections.Generic;

namespace FhirSave
{
    public static class GetAllProfiles
    {
        [FunctionName("GetAllProfiles")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            try
            {
                var EndpointURI = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBEndpoint");
                var keyVaultResp = Utils.ReliantUtlity.GetEnvironmentVariable("CosmosDBKey");
                var PrimaryKey = keyVaultResp;
                string databaseId = Utils.ReliantUtlity.GetEnvironmentVariable("FauxDatabaseName");
                string containerId = Utils.ReliantUtlity.GetEnvironmentVariable("ProfileContainerName");
                //var PrimaryKey = "IpmKSMKNYA6sYK03MSLFsO0tPvCSUVUDggGlps6dAdTvaSeQT95PyfmdRMjWhxBqPZE4Rm7zGmSOEyTarVrEpw==";
                //var EndpointURI = "https://cosmosdb-stage.documents.azure.com:443/";              
                
                //string databaseId = "mock-db";
                //string containerId = "UserProfiles";


                List<profilesdata> data = new List<profilesdata>();
                var options = new CosmosClientOptions() { ConnectionMode = ConnectionMode.Gateway };
                var cosmosClient = new CosmosClient(EndpointURI, PrimaryKey, options);

                var container = cosmosClient.GetContainer(databaseId, containerId);
                var sqlQueryText = "SELECT * FROM c";
                QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
                FeedIterator<object> queryResultSetIterator = container.GetItemQueryIterator<object>(queryDefinition);

                FeedResponse<object> currentResultSet = await queryResultSetIterator.ReadNextAsync();



                foreach (var item in currentResultSet.Resource)
                {
                    var val = Utils.Extention.ConvertObjectToJson(item);
                    var Profile = JsonConvert.DeserializeObject<Profiles>(val);
                    profilesdata prf = new profilesdata();
                    prf.name = Profile.PatientName;
                    prf.id = Profile.patientid;
                    data.Add(prf);
                }
                    
                //var data = await Utils.DBUtility.GetItemFromContainer(EndpointURI, PrimaryKey, sqlQueryText, databaseId, containerId);

                return new OkObjectResult(data);

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }
        public class profilesdata
        {
            public string name { get; set; }
            public string id { get; set; }
        }
        public class Address
        {
            public string address1 { get; set; }
            public object address2 { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string country { get; set; }
            public string zipcode { get; set; }
            public string cellPhone { get; set; }
            public object workPhone { get; set; }
            public object email { get; set; }
            public object workEmail { get; set; }
        }

        public class Demographics
        {
            public object sensitiveHealth { get; set; }
            public object inactiveFlag { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string fullName { get; set; }
            public string age { get; set; }
            public string birthGender { get; set; }
            public string dob { get; set; }
            public object ethnicity { get; set; }
            public object insurance { get; set; }
            public object race { get; set; }
            public Address address { get; set; }
        }

        public class RiskFactor
        {
            public string name { get; set; }
            public string infermedicaID { get; set; }
        }

        public class Provider
        {
            public string id { get; set; }
            public string providername { get; set; }
        }

        public class Profiles
        {
            public string id { get; set; }
            public string PatientName { get; set; }
            public string patientid { get; set; }
            public Demographics demographics { get; set; }
            public List<RiskFactor> riskFactors { get; set; }
            public List<Provider> providers { get; set; }
            
        }

    }
}
