﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Get
{
    public enum imageType
    {
        patient = 0,
        insuranceFront = 1,
        insuranceBack = 2
    }

    class getImage
    {

    }
}
