﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Threading;
using Hl7.Fhir.Rest;
using FhirSave.Models;
using RestSharp;
using System.Collections.Generic;
using FhirSave.Utils;
using FhirSave.Models.Dto;

namespace FhirSave
{
    public class GetAppointment10
    {
        [FunctionName("GetAppointment")]
        public async Task<IActionResult> Run(
             [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.0/getAppointment")] HttpRequest req,
             ILogger log)
        {
            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                BadRequestResult badresult = new BadRequestResult();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(8000);

                var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                var patID = query.Get("PatientID");
                var apptID = query.Get("AppointmentID");

                var bearerToken = FhirToken.GetBearerToken(log);

                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });

                var lookupId = patID == null ? apptID : patID;
                var appts = await Utils.PatientCheckinUtility.LookupResourceDirect<FhirSave.Models.Appointments.Root>(resource + $"/Appointment/?identifier={lookupId}", bearerToken);


                // build Dto
                AppointmentDto appointment = new AppointmentDto();
                appointment.id = appts.id;
                appointment.fullUrl = appts.entry?[0].fullUrl;
                appointment.resource = new Models.Dto.Resource();
                appointment.resource.id = appts.entry?[0].resource?.id;
                appointment.resource.created = appts.entry?[0].resource.created;
                appointment.resource.start = appts.entry[0].resource.start;
                appointment.resource.end = appts.entry[0].resource.end;
                appointment.resource.participants = new List<Participant>();
                foreach(var participant in appts.entry?[0].resource?.participant)
                {
                    Participant part = new Participant();
                    part.actor = new Actor();
                    part.actor.display = participant?.actor?.display;
                    part.actor.reference = participant?.actor?.reference;
                    part.required = participant.required;
                    part.status = participant.status;
                    appointment.resource.participants.Add(part);
                }
                appointment.resource.identifiers = new List<Models.Dto.Identifier>();
                foreach(var ident in appts.entry?[0].resource?.identifier)
                {
                    Models.Dto.Identifier tmp = new Models.Dto.Identifier();
                    tmp.system = ident.system;
                    tmp.value = ident.value;
                    appointment.resource.identifiers.Add(tmp);
                }

                return new OkObjectResult(appointment);
            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }
    }
}
