using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading;
using Hl7.Fhir.Rest;
using FhirSave.Models;

namespace FhirSave
{
    public class GetAllergies
    {      

        [FunctionName("GetAllergies")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            string responseMessage = string.Empty;
            var content = new StreamReader(req.Body).ReadToEndAsync();
            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                BadRequestResult badresult = new BadRequestResult();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(8000);

                if (string.IsNullOrEmpty(content.Result))
                {
                    throw new ArgumentNullException("The body of the request is null or empty", "Body");
                }
                reqBody reqdata = JsonConvert.DeserializeObject<reqBody>(content.Result);
                var PatID = reqdata.patientID;
                var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");

                //FhirToken fhToken = new FhirToken(configuration);
                //string bearerToken = fhToken.GetBearerToken(log);
                //var resource = "https://optum-fhirserver.azurehealthcareapis.com";
               
                string bearerToken = FhirToken.GetBearerToken(log);

                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

               Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
               {
                     PreferredFormat = ResourceFormat.Json
               });

                Hl7.Fhir.Model.Patient patresource = Utils.ReliantUtlity.GetPatient(client, resource, PatID);
                var bundleId = await Utils.ReliantUtlity.GetBundleID("AllergiesBundle", patresource);
                Allergies allergies = new Allergies();
                allergies = await Utils.ReliantUtlity.GetAllergyBundle(resource, bundleId, bearerToken);

                return new OkObjectResult(allergies);

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }

    }

}
