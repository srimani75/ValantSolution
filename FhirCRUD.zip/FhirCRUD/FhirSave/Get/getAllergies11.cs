﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Threading;
using Hl7.Fhir.Rest;
using FhirSave.Models;
using RestSharp;
using System.Collections.Generic;
using FhirSave.Utils;

namespace FhirSave
{
    public class GetAllergies11
    {

        [FunctionName("GetAllergies11")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "v1.1/getAllergies")] HttpRequest req,
            ILogger log)
        {
            Allergies allergies = new Allergies();

            try
            {
                log.LogInformation("C# HTTP trigger function processed a request.");
                BadRequestResult badresult = new BadRequestResult();

                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(8000);
                var resource = Utils.PatientCheckinUtility.GetEnvironmentVariable("resource");

                //var bearerToken = FhirToken.GetBearerTokenDirect(log);
                var bearerToken = FhirToken.GetBearerToken(log);

                var messageHandler = new HttpClientEventHandler();
                messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
                {
                    e.RawRequest.Headers
                    .Add("Authorization", $"Bearer {bearerToken}");
                };

                Hl7.Fhir.Rest.FhirClient client = new Hl7.Fhir.Rest.FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
                {
                    PreferredFormat = ResourceFormat.Json
                });

                var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
                var PatID = query.Get("PatientID");
                if (PatID == string.Empty || PatID == null)
                {
                    var errorResonse = new Models.ErrorResponse();
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = "No patient Id given.";
                    errorResonse.detail = "No patient Id given.";

                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

                Hl7.Fhir.Model.Patient patresource = Utils.ReliantUtlity.GetPatient(client, resource, PatID);
                if (patresource.Id == null)
                {
                    var errorResonse = new Models.ErrorResponse();
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = $"No patient {PatID}.";
                    errorResonse.detail = $"No patient {PatID}.";

                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

                var bundleId = await Utils.ReliantUtlity.GetBundleID("AllergiesBundle", patresource);
                if (bundleId == "")
                {
                    var errorResonse = new Models.ErrorResponse();
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = $"No allergies bundle Id given for patient {PatID}.";
                    errorResonse.detail = $"No allergies bundle Id given for patient {PatID}.";

                    var result = new OkObjectResult(errorResonse);
                    result.StatusCode = StatusCodes.Status500InternalServerError;
                    return result;
                }

                allergies = await Utils.ReliantUtlity.GetAllergyBundle(resource, bundleId, bearerToken);

                return new OkObjectResult(allergies);

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                var result = new OkObjectResult(errorResonse);
                result.StatusCode = StatusCodes.Status500InternalServerError;
                return result;
            }
        }
    }
}
