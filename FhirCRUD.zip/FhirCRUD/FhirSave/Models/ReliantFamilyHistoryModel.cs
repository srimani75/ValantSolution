using System.Collections.Generic;
namespace FhirSave.Models
{
    public class ReliantFamilyHistoryModel
    {
        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Patient
        {
            public string display { get; set; }
            public string reference { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Relationship
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Code
        {
            public string text { get; set; }
        }

        public class Note
        {
            public string text { get; set; }
        }

        public class Condition
        {
            public Code code { get; set; }
            public string onsetString { get; set; }
            public Note note { get; set; }
        }

        public class Details
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Issue
        {
            public string severity { get; set; }
            public string code { get; set; }
            public Details details { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public Patient patient { get; set; }
            public string date { get; set; }
            public string status { get; set; }
            public string name { get; set; }
            public Relationship relationship { get; set; }
            public bool deceasedBoolean { get; set; }
            public List<Condition> condition { get; set; }
            public List<Issue> issue { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class FamilyHistory
        {
            public string resourceType { get; set; }
            public string type { get; set; }
            public int total { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }


    }
}

