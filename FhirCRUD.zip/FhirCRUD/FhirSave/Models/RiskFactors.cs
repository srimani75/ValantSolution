﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class RiskFactor
    {
        public List<string> RiskFactors { get; set; }
    }
}