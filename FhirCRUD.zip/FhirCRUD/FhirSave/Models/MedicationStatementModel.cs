﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class MedicationStatementModel
    {
        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class ValueCodeableConcept
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Extension
        {
            public string url { get; set; }
            public ValueCodeableConcept valueCodeableConcept { get; set; }
            public ValueQuantity valueQuantity { get; set; }
        }

        public class Identifier
        {
            public string use { get; set; }
            public string system { get; set; }
            public string value { get; set; }
        }

        public class Patient
        {
            public string display { get; set; }
            public string reference { get; set; }
        }

        public class InformationSource
        {
            public string display { get; set; }
            public string reference { get; set; }
        }

        public class MedicationCodeableConcept
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class ValueQuantity
        {
            public int value { get; set; }
            public string unit { get; set; }
            public string system { get; set; }
            public string code { get; set; }
        }

        public class Repeat
        {
            public int frequency { get; set; }
            public int period { get; set; }
            public string periodUnits { get; set; }
        }

        public class Code
        {
            public string text { get; set; }
        }

        public class Timing
        {
            public Repeat repeat { get; set; }
            public Code code { get; set; }
        }

        public class Route
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Method
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class QuantityQuantity
        {
            public int value { get; set; }
            public string unit { get; set; }
            public string system { get; set; }
            public string code { get; set; }
        }

        public class Dosage
        {
            public List<Extension> extension { get; set; }
            public string text { get; set; }
            public Timing timing { get; set; }
            public bool asNeededBoolean { get; set; }
            public Route route { get; set; }
            public Method method { get; set; }
            public QuantityQuantity quantityQuantity { get; set; }
        }

        public class Details
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Issue
        {
            public string severity { get; set; }
            public string code { get; set; }
            public Details details { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public List<Extension> extension { get; set; }
            public List<Identifier> identifier { get; set; }
            public Patient patient { get; set; }
            public InformationSource informationSource { get; set; }
            public string status { get; set; }
            public MedicationCodeableConcept medicationCodeableConcept { get; set; }
            public List<Dosage> dosage { get; set; }
            public List<Issue> issue { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public List<Link> link { get; set; }
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class MedicationStatementDetails
        {
            public string resourceType { get; set; }
            public string type { get; set; }
            public int total { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }

    }
}
