﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{     
    public class AllergiesDetails
    {
            public string detail { get; set; }
            public string entrycode { get; set; }
            public string description { get; set; }
            public string section { get; set; }
            public string status { get; set; }
            public string displaydate { get; set; }
            public string reactiontype { get; set; }
            public List<string> reactions { get; set; }
            public List<ICDCode> ICDCodes { get; set; }
    }

    public class Allergies
    {
        public List<AllergiesDetails> AllergiesDetails { get; set; }
    }
}