﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace FhirSave.Models
{

    public class PossibleCausesandDenials
    {
        public List<PossCausandDenDetails> PossCausandDen { get; set; }
    }
    public class PossCausandDenDetails
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public string CategoriesCareDelimited { get; set; }
        public string Prevalence { get; set; }
        public string Acuteness { get; set; }
        public string Severity { get; set; }
        [JsonProperty("ICD10Code")]
        public string ICD10Code { get; set; }

        public string Hint { get; set; }
        public string TriageLevel { get; set; }
        public string RecommendedChannel { get; set; }
        public string Probablity { get; set; }
        public string ShortDescription { get; set; }
        public string MedlineURL { get; set; }
        public string CommonMedlineName { get; set; }

       /*public List<string> PossibleCauses_ID { get; set; }
       public List<string> PossibleCauses_Name { get; set; }
       public List<string> PossibleCauses_CommonName { get; set; }
       public List<string> PossibleCauses_CategoriesCareDelimited { get; set; }
       public List<string> PossibleCauses_Prevalence { get; set; }
       public List<string> PossibleCauses_Acuteness { get; set; }
       public List<string> PossibleCauses_Severity { get; set; }
       public List<string> PossibleCauses_ICD10Code { get; set; }
       public List<string> PossibleCauses_Hint { get; set; }
       public List<string> PossibleCauses_TriageLevel { get; set; }
       public List<string> PossibleCauses_RecommendedChannel { get; set; }
       public List<string> PossibleCauses_Probablity { get; set; }
       public List<string> PossibleCauses_ShortDescription { get; set; }
       public List<string> PossibleCauses_MedlineURL { get; set; }
       public List<string> PossibleCauses_CommonMedlineName { get; set; }*/
    }
}