﻿using System;
using System.Collections.Generic;

namespace FhirSave.Models
{
        public class Vitals
        {
            public List<VitalsDetails> Vitalsdetail { get; set; }
        }

        public class VitalsDetails
        {
            public string section { get; set; }
            public string code { get; set; }
            public string entrycode { get; set; }
            public string status { get; set; }
            public string displaydate { get; set; }
            public string description { get; set; }
            public string detail { get; set; }
            public List<ICDCode> ICDCode { get; set; }
        }

        //public class ICDCode
        //{
        //    public string icd9 { get; set; }
        //    public string icd10 { get; set; }
        //}
}
