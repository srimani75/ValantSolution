﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models.Dto
{
    public class AppointmentDto
    {
        public string id { get; set; }
        public string fullUrl { get; set; } //  Entry[0].fullurl
        public Resource resource { get; set; }
    }

    public class Resource
    {
        public DateTime? created { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public string id { get; set; }
        public List<Participant> participants { get; set; }
        public List<Identifier> identifiers { get; set; }
    }

    public class Participant // loop
    {
        public Actor actor { get; set; }
        public string required { get; set; }
        public string status { get; set; }
    }

    public class Actor
    {
        public string display { get; set; }
        public string reference { get; set; }
    }

    public class Identifier
    {
        public string system { get; set; }
        public string value { get; set; }
    }
}
