﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    /*public class Meta
    {
        public string versionId { get; set; }
        public DateTime lastUpdated { get; set; }
    }

    public class Identifier
    {
        public string system { get; set; }
        public string value { get; set; }
    }*/

    public class Other
    {
        public string reference { get; set; }
    }

    /*public class Link
    {
        public Other other { get; set; }
    }*/

    public class Patientresource
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Meta meta { get; set; }
        public List<Identifier> identifier { get; set; }
        public string gender { get; set; }
        public string birthDate { get; set; }
        public List<Link> link { get; set; }
    }
}
