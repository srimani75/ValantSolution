﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class PatientModel
    {
        public class Getpatientinfo
        {
            public string IsSensitiveHealth { get; set; }
            public string genericattribute { get; set; }
            public string Language { get; set; }
            public string IsInactiveFLAG { get; set; }
            public string PhysLastName { get; set; }
            public string MailingAddressLine2 { get; set; }
            public string PhoneNumber { get; set; }
            public string BirthSex { get; set; }
            public string age { get; set; }
            public string middlename { get; set; }
            public string mrn { get; set; }
            public string nextappointment { get; set; }
            public string MailingZipeCode { get; set; }
            public string CellPhone { get; set; }
            public string Email { get; set; }
            public string MailingAddressLine1 { get; set; }
            public string SexualOrientation { get; set; }
            public string LastName { get; set; }
            public string WorkPhone { get; set; }
            public string gender { get; set; }
            public string ID { get; set; }
            public string AgeDec { get; set; }
            public string Race { get; set; }
            public string enterprisemrn { get; set; }
            public string haswip { get; set; }
            public string ssn { get; set; }
            public string dateofbirth { get; set; }
            public string AddressLine2 { get; set; }
            public string previousappointment { get; set; }
            public string OnClinicalTrialFlag { get; set; }
            public string base64image { get; set; }
            public string ZipCode { get; set; }
            public string State { get; set; }
            public string allmrn { get; set; }
            public string MailingCity { get; set; }
            public string othernumber2 { get; set; }
            public string PhysPhone { get; set; }
            public string Firstname { get; set; }
            public string patientorg { get; set; }
            public string Guarantor { get; set; }
            public string MaritalStatus { get; set; }
            public string PreferredPronoun { get; set; }
            public string Alias { get; set; }
            public string Ethnicity { get; set; }
            public string Addressline1 { get; set; }
            public string SexNormalized { get; set; }
            public string PhysFirstName { get; set; }
            public string othernumber { get; set; }
            public string fmhpatient { get; set; }
            public string PrimaryInsurance { get; set; }
            public string PatientLocation { get; set; }
            public string GenderIdentity { get; set; }
            public string PatientXID { get; set; }
            public string PhysUserName { get; set; }
            public string City { get; set; }
            public string isLocalPtFLAG { get; set; }
            public string HomePhone { get; set; }
            public string MailingState { get; set; }
        }

        public class patientinfo
        {
            public List<Getpatientinfo> getpatientinfo { get; set; }
        }
    }
}
