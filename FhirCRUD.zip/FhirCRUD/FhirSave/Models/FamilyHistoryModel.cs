﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class FamilyHistoryModel
    {
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
        }

        public class Patient
        {
            public string reference { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Relationship
        {
            public List<Coding> coding { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Condition
        {
            public Code code { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string status { get; set; }
            public Patient patient { get; set; }
            public string date { get; set; }
            public string name { get; set; }
            public Relationship relationship { get; set; }
            public List<Condition> condition { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class Root
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }

    }
}
