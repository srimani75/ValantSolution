﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave
{
    class Triage
    {
    }
    public class Extras
    {
        public string icd10_code { get; set; }
        public string hint { get; set; }
    }

    public class Diagnosis
    {
        public string id { get; set; }
        public string name { get; set; }
        public string common_name { get; set; }
        public string sex_filter { get; set; }
        public List<string> categories { get; set; }
        public string prevalence { get; set; }
        public string acuteness { get; set; }
        public string severity { get; set; }
        public Extras extras { get; set; }
        public string triage_level { get; set; }
        public double probability { get; set; }
    }

    public class DiagnosisData
    {
        public List<Diagnosis> diagnosis { get; set; }
    }
    public class CdsQnAPayload
    {
        public Qna[] questions { get; set; }
    }
    public class Qna
    {
        public string quesiton { get; set; }
        public string answer { get; set; }
    }

    public class ChiefComplaint
    {
        public string[] Complaints { get; set; }
    }

    public class HPI
    {
        public string PresentIllness { get; set; }
    }
}
