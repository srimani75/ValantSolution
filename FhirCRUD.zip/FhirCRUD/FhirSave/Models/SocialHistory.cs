﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class ICDCode
    {
        public string icd9 { get; set; }
        public string icd10 { get; set; }
    }

    public class SocialHistorydetail
    {
        public string detail { get; set; }
        public string entrycode { get; set; }
        public string section { get; set; }
        public string status { get; set; }
        public string displaydate { get; set; }
        public List<ICDCode> ICDCode { get; set; }
    }

    public class SocialHistory
    {
        public List<SocialHistorydetail> SocialHistorydetail { get; set; }
    }

    public class FamilyHistorydetail
    {
        public string detail { get; set; }
        public string entrycode { get; set; }
        public string section { get; set; }
        public string status { get; set; }
        public string displaydate { get; set; }
        public List<ICDCode> ICDCode { get; set; }
        public List<string> relations { get; set; }
    }

    public class FamilyHistorydetails
    {
        public List<FamilyHistorydetail> FamilyHistorydetailval { get; set; }
    }
}
