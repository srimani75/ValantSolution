﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class Miscellaneous
    {
        public List<string> CareOptions { get; set; }
        public string TeleconsultationApplicable { get; set; }
        public string TriageLevel { get; set; }
        public string ConsentTimestamp { get; set; }
        public string PatientSelfTriageLevel { get; set; }
        public string LikelihoodToRecommend { get; set; }
    }
}