﻿using System;
using System.Collections.Generic;
namespace FhirSave.Models
{
    public class ReliantImmunizationsModel
    {
        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Identifier
        {
            public string use { get; set; }
            public string system { get; set; }
            public string value { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class VaccineCode
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Patient
        {
            public string reference { get; set; }
            public string display { get; set; }
        }

        public class Encounter
        {
            public string reference { get; set; }
        }

        public class Details
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Issue
        {
            public string severity { get; set; }
            public string code { get; set; }
            public Details details { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public List<Identifier> identifier { get; set; }
            public string status { get; set; }
            public VaccineCode vaccineCode { get; set; }
            public Patient patient { get; set; }
            public Encounter encounter { get; set; }
            public string occurrenceDateTime { get; set; }
            public bool primarySource { get; set; }
            public List<Issue> issue { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public List<Link> link { get; set; }
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class Immunizations
        {
            public string resourceType { get; set; }
            public string type { get; set; }
            public int total { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }
    }
}
