﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class MedicationModelSummary
    {
        List<Medication> medications;
    }

    public class Medication
    {
        public string medicationName;
    }

    public class MedicationModel
    {

        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
        }

        public class Identifier
        {
            public string use { get; set; }
            public string value { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class MedicationCodeableConcept
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Subject
        {
            public string reference { get; set; }
        }

        public class ValueQuantity
        {
            public int value { get; set; }
            public string unit { get; set; }
        }

        public class Extension
        {
            public string url { get; set; }
            public ValueQuantity valueQuantity { get; set; }
        }

        public class Repeat
        {
            public int frequency { get; set; }
            public int period { get; set; }
            public string periodUnit { get; set; }
        }

        public class Code
        {
            public string text { get; set; }
        }

        public class Timing
        {
            public Repeat repeat { get; set; }
            public Code code { get; set; }
        }

        public class Route
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Method
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Dosage
        {
            public List<Extension> extension { get; set; }
            public string text { get; set; }
            public Timing timing { get; set; }
            public bool asNeededBoolean { get; set; }
            public Route route { get; set; }
            public Method method { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public List<Identifier> identifier { get; set; }
            public string status { get; set; }
            public MedicationCodeableConcept medicationCodeableConcept { get; set; }
            public Subject subject { get; set; }
            public List<Dosage> dosage { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class Root
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }
    }
}