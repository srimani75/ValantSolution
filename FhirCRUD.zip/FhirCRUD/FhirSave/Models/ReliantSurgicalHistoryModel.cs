﻿using System;
using System.Collections.Generic;

namespace FhirSave.Models
{
    public class ReliantSurgicalHistoryModel
    {
        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Type
        {
            public string text { get; set; }
        }

        public class Identifier
        {
            public string use { get; set; }
            public Type type { get; set; }
            public string system { get; set; }
            public string value { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Subject
        {
            public string reference { get; set; }
            public string display { get; set; }
        }

        public class Encounter
        {
            public string reference { get; set; }
        }

        public class Details
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Issue
        {
            public string severity { get; set; }
            public string code { get; set; }
            public Details details { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public List<Identifier> identifier { get; set; }
            public string status { get; set; }
            public Code code { get; set; }
            public Subject subject { get; set; }
            public Encounter encounter { get; set; }
            public string performedDateTime { get; set; }
            public List<Issue> issue { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public List<Link> link { get; set; }
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class SurgicalHistory
        {
            public string resourceType { get; set; }
            public string type { get; set; }
            public int total { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }

    }
}
