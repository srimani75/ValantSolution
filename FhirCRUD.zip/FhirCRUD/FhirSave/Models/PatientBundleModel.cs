﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class PatientBundleModel
    {
        public class Meta
        {
            public DateTime lastUpdated { get; set; }
            public string versionId { get; set; }
        }

        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Identifier
        {
            public string system { get; set; }
            public string value { get; set; }
        }

        public class Name
        {
            public string text { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public List<Identifier> identifier { get; set; }
            public List<Name> name { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class PatientBundle
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }
    }
}
