﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class ChiefComplaint
    {
        public List<string> ChiefComplaints { get; set; }
        public List<string> SecondaryComplaints { get; set; }
        public List<string> Denials { get; set; }
    }
}