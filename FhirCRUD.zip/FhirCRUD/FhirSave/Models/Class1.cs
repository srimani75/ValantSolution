﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class Class1
    {
    }
}
