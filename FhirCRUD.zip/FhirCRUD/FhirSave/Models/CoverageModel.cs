﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class CoverageModelSummary
    {
        public string id { get; set; }
        public string insuranceProvider { get; set; }
        public Address insuranceProviderAddress { get; set; }
        public string groupNumber { get; set; }
        public string policyNumber { get; set; }
        public string policyHolderName { get; set; }
        public DateTime? policyHolderDOB { get; set; }
        public string policyHolderRelationToPatient { get; set; }
        public Address policyHolderAddress { get; set; }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Meta
    {
        public DateTime lastUpdated { get; set; }
        public string versionId { get; set; }
    }

    public class Link
    {
        public string relation { get; set; }
        public string url { get; set; }
    }

    public class Identifier
    {
        public string system { get; set; }
        public string value { get; set; }
    }

    public class Coding
    {
        public string system { get; set; }
        public string code { get; set; }
        public string display { get; set; }
    }

    public class Type
    {
        public List<Coding> coding { get; set; }
    }

    public class Subscriber
    {
        public string display { get; set; }
    }

    public class Beneficiary
    {
        public string display { get; set; }
    }

    public class Relationship
    {
        public List<Coding> coding { get; set; }
    }

    public class Payor
    {
        public string display { get; set; }
    }

    public class Resource
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Meta meta { get; set; }
        public List<Identifier> identifier { get; set; }
        public string status { get; set; }
        public Type type { get; set; }
        public Subscriber subscriber { get; set; }
        public Beneficiary beneficiary { get; set; }
        public Relationship relationship { get; set; }
        public List<Payor> payor { get; set; }
    }

    public class Search
    {
        public string mode { get; set; }
    }

    public class Entry
    {
        public string fullUrl { get; set; }
        public Resource resource { get; set; }
        public Search search { get; set; }
    }

    public class CoverageRoot
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Meta meta { get; set; }
        public string type { get; set; }
        public List<Link> link { get; set; }
        public List<Entry> entry { get; set; }
    }
}

