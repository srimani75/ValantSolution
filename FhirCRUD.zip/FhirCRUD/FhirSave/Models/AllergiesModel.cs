﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class AllergiesModel
    {
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
            public List<string> profile { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class ClinicalStatus
        {
            public List<Coding> coding { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
        }

        public class Patient
        {
            public string reference { get; set; }
        }

        public class Substance
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Manifestation
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Reaction
        {
            public Substance substance { get; set; }
            public List<Manifestation> manifestation { get; set; }
            public string severity { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public Meta meta { get; set; }
            public ClinicalStatus clinicalStatus { get; set; }
            public Code code { get; set; }
            public Patient patient { get; set; }
            public List<Reaction> reaction { get; set; }
            public string criticality { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class AllergiesDetails
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }


    }
}
