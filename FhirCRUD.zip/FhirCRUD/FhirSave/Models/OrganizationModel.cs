﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class OrganizationModel
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
        }

        public class Identifier
        {
            public string system { get; set; }
            public string value { get; set; }
        }

        public class Telecom
        {
            public string system { get; set; }
            public string value { get; set; }
            public string use { get; set; }
        }

        public class Address
        {
            public List<string> line { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postalCode { get; set; }
            public string country { get; set; }
        }

        public class Root
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public List<Identifier> identifier { get; set; }
            public string name { get; set; }
            public List<Telecom> telecom { get; set; }
            public List<Address> address { get; set; }
        }
    }
}
