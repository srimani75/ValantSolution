﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class Provider
    {
        public string ID { get; set; }
        public string Providername { get; set; }
    }

    public class RiskFactors
    {
        public string Name { get; set; }
        public string InfermedicaID { get; set; }
    }   
    public class ClinicalResponse
    {
        public string SessionID { get; set; }
        public List<Provider> Providers { get; set; }
        public List<RiskFactors> RiskFactors { get; set; }
    }
}
