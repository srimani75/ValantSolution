﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace FhirSave.Models
{

    public class Immunization
    {
        public List<ImmunizationDetails> ImmunizationList { get; set; }
    }
    public class ImmunizationDetails
    {
        public string Immunizationcode { get; set; }
        public string Vaccinecode { get; set; }
        public string name { get; set; }
        public string Occurencedate { get; set; }
        public string Primarysource { get; set; }
    }
}