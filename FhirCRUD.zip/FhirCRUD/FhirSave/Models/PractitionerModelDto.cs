﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models.Dto
{
    public class PractitionerModelDto
    {
        public string active { get; set; }
        public string telecom { get; set; }
        public string gender { get; set; }
        public string[] given { get; set; }
        public string family { get; set; }
        public string fullName { get; set; }
    }

    //public class name
    //{
    //    public string use { get; set; }
    //    public string family { get; set; }
    //    public string[] given { get; set; }
    //}
}
