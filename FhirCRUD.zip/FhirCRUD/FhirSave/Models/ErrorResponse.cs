﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
   public class ErrorResponse
    {
        public ErrorResponse()
        {
            Id = Utils.ReliantUtlity.GenerateErrorId();
            Type = "ErrorResponse";
        }
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        public string Type { get; }
        public string error { get; set; }
        public string message { get; set; }
        public object detail { get; set; }
    }
    public class Data
    {
        public string content { get; set; }
    }
    public class EventHubErrorResponse
    {
        public string agg { get; set; }
        public string type { get; set; }
        public Data data { get; set; }       

    }
}
