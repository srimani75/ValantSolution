﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class Location
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class Text
        {
            public string status { get; set; }
            public string div { get; set; }
        }

        public class Identifier
        {
            public string value { get; set; }
        }

        public class Telecom
        {
            public string system { get; set; }
            public string value { get; set; }
            public string use { get; set; }
        }

        public class Address
        {
            public string use { get; set; }
            public List<string> line { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postalCode { get; set; }
            public string country { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class PhysicalType
        {
            public List<Coding> coding { get; set; }
        }

        public class Position
        {
            public double longitude { get; set; }
            public double latitude { get; set; }
            public int altitude { get; set; }
        }

        public class ManagingOrganization
        {
            public string reference { get; set; }
        }

        public class Endpoint
        {
            public string reference { get; set; }
        }

        public class Root
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Text text { get; set; }
            public List<Identifier> identifier { get; set; }
            public string status { get; set; }
            public string name { get; set; }
            public List<string> alias { get; set; }
            public string description { get; set; }
            public string mode { get; set; }
            public List<Telecom> telecom { get; set; }
            public Address address { get; set; }
            public PhysicalType physicalType { get; set; }
            public Position position { get; set; }
            public ManagingOrganization managingOrganization { get; set; }
            public List<Endpoint> endpoint { get; set; }
        }


    }
}
