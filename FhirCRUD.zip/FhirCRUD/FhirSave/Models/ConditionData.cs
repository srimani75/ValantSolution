using System;
using System.Collections.Generic;

namespace FhirSave.Models
{
    public class ConditionData
    {
        public string Name { get; set; }
        public string ICDCode { get; set; }
        public string RxNorm { get; set; }
        public string LoincCode { get; set; }
        public string ClinicalStatus { get; set; }
        public string VerificationStatus { get; set; }
    }
    public class ConditionList
    {
        public List<ConditionData> Problems {get; set;}
    }
}