﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class ChiefComplaintsModel
    {
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
        }

        public class ValueCodeableConcept
        {
            public string id { get; set; }
            public string text { get; set; }
        }

        public class Extension
        {
            public string url { get; set; }
            public bool valueBoolean { get; set; }
            public string id { get; set; }
            public ValueCodeableConcept valueCodeableConcept { get; set; }
            public List<Extension> extension { get; set; }
        }

        public class Subject
        {
            public string reference { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
        }

        public class Evidence
        {
            public List<Code> code { get; set; }
        }

        public class Note
        {
            public string text { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public List<Extension> extension { get; set; }
            public Subject subject { get; set; }
            public List<Evidence> evidence { get; set; }
            public List<Note> note { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class Root
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }

    }
}
