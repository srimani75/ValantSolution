﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class SeriousSymptoms
    {
        public List<SeriousSymptomsDet> SeriousSympList { get; set; }
    }

    public class SeriousSymptomsDet
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string CommonName { get; set; }
        public string IsEmergency { get; set; }
    }
}