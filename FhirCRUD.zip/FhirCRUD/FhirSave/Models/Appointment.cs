﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models.Appointments
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Meta
    {
        public DateTime lastUpdated { get; set; }
        public string versionId { get; set; }
    }

    public class Link
    {
        public string relation { get; set; }
        public string url { get; set; }
    }

    public class Identifier
    {
        public string system { get; set; }
        public string value { get; set; }
    }

    public class Coding
    {
        public string system { get; set; }
        public string display { get; set; }
    }

    public class Type
    {
        public List<Coding> coding { get; set; }
    }

    public class Actor
    {
        public string reference { get; set; }
        public string display { get; set; }
    }

    public class Participant
    {
        public List<Type> type { get; set; }
        public Actor actor { get; set; }
        public string required { get; set; }
        public string status { get; set; }
    }

    public class Resource
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Meta meta { get; set; }
        public List<Identifier> identifier { get; set; }
        public string status { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public DateTime created { get; set; }
        public List<Participant> participant { get; set; }
    }

    public class Search
    {
        public string mode { get; set; }
    }

    public class Entry
    {
        public string fullUrl { get; set; }
        public Resource resource { get; set; }
        public Search search { get; set; }
    }

    public class Root
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Meta meta { get; set; }
        public string type { get; set; }
        public List<Link> link { get; set; }
        public List<Entry> entry { get; set; }
    }
}
