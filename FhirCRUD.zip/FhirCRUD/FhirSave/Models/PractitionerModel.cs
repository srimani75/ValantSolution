﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class PractitionerModel
    {
        public string active { get; set; }
        public telecom[] telecom { get; set; }
        public string gender { get; set; }
        public name[] name { get; set; }
    }

    public class name
    {
        public string text { get; set; }
        public string use { get; set; }
        public string family { get; set; }
        public string[] given { get; set; }
    }

    public class telecom
    {
        public string value { get; set; }
    }
}
