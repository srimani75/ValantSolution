﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class SurgicalHistory
    {
        public List<SurgicalHistoryDetails> SurgicalHistoryList { get; set; }
    }
    public class SurgicalHistoryDetails
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public string Date { get; set; }
        public string Status { get; set; }
        public string Laterality { get; set; }
        public string Comment { get; set; }


    }
}