﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    class PatientResponseModel
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
        }

        public class Source
        {
            public string reference { get; set; }
        }

        public class Extension
        {
            public string url { get; set; }
            public string valueString { get; set; }
        }

        public class Item2
        {
            public List<Extension> extension { get; set; }
            public string text { get; set; }
            public List<Answer> answer { get; set; }
        }

        public class Answer
        {
            public List<Item2> item { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string status { get; set; }
            public Source source { get; set; }
            public List<Item2> item { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class PatientAnswerResponse
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }
    }
}
