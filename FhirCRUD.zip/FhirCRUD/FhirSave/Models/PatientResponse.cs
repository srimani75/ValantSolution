﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class Question
    {
        public string question { get; set; }
        public List<string> answer { get; set; }
    }

    public class PatientResponse
    {
        public List<Question> qna { get; set; }
    }

}
