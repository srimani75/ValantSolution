﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class Qna
    {
        public List<string> id { get; set; }
        public string question { get; set; }
        public string answer { get; set; }
        public string type { get; set; }
        public string evidence { get; set; }
    }

    public class SeriousSymptom
    {
        public string id { get; set; }
        public string name { get; set; }
        public string common_name { get; set; }
        public bool is_emergency { get; set; }
    }

    public class Extras
    {
        public string icd10_code { get; set; }
        public string hint { get; set; }
    }

    public class PossibleCaus
    {
        public string id { get; set; }
        public string name { get; set; }
        public string common_name { get; set; }
        public string sex_filter { get; set; }
        public List<string> categories { get; set; }
        public string prevalence { get; set; }
        public string acuteness { get; set; }
        public string severity { get; set; }
        public Extras extras { get; set; }
        public string triage_level { get; set; }
        public string recommended_channel { get; set; }
        public double probability { get; set; }
        public string short_description { get; set; }
        public string medline_url { get; set; }
        public string common_medline_name { get; set; }
    }

    public class TriagePayload
    {
        public List<Qna> qna { get; set; }
        public List<string> chief_complaints { get; set; }
        public List<string> secondary_complaints { get; set; }
        public List<SeriousSymptom> serious_symptoms { get; set; }
        public List<PossibleCaus> possible_causes { get; set; }
        public List<string> present_risk_factors { get; set; }
        public List<string> care_options { get; set; }
        public List<string> denials { get; set; }
        public string gender { get; set; }
        public int age { get; set; }
        public bool teleconsultation_applicable { get; set; }
        public string triage_level { get; set; }
        public int nps_score { get; set; }
    }
}
