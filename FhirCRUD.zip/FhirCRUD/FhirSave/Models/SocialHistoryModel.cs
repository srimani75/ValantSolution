﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class SocialHistoryModel
    {
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Category
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Subject
        {
            public string reference { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string status { get; set; }
            public List<Category> category { get; set; }
            public Code code { get; set; }
            public Subject subject { get; set; }
            public DateTime effectiveDateTime { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class Root
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }

    }

}
