﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class GarberSurgicalHistoryModel
    {
        public class SurgicalHistory
        {
            public string Status { get; set; }
            public string Comment { get; set; }
            public List<string> ProcedureName { get; set; }
            public List<string> ProcedureCode { get; set; }
            public List<string> CodeType { get; set; }
            public List<string> ProcedureDate { get; set; }
            public List<string> ProcedureLaterality { get; set; }
            public List<string> ProcedureComment { get; set; }
        }
    }
}
