﻿using System;
using System.Collections.Generic;
namespace FhirSave.Models
{
    public class ReliantLabsModel
    {
        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Category
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Code
        {
            public string text { get; set; }
        }

        public class Subject
        {
            public string display { get; set; }
            public string reference { get; set; }
        }

        public class ValueQuantity
        {
            public double value { get; set; }
            public string unit { get; set; }
        }

        public class Interpretation
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Details
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Issue
        {
            public string severity { get; set; }
            public string code { get; set; }
            public Details details { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public string status { get; set; }
            public Category category { get; set; }
            public Code code { get; set; }
            public Subject subject { get; set; }
            public DateTime effectiveDateTime { get; set; }
            public ValueQuantity valueQuantity { get; set; }
            public Interpretation interpretation { get; set; }
            public string valueString { get; set; }
            public List<Issue> issue { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public List<Link> link { get; set; }
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class ReliantLabsResponse
        {
            public string resourceType { get; set; }
            public string type { get; set; }
            public int total { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }


    }
}
