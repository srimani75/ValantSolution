﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class DemographicsModel
    {
        public class Meta
        {
            public DateTime lastUpdated { get; set; }
            public string versionId { get; set; }
        }

        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Identifier
        {
            public string system { get; set; }
            public string value { get; set; }
        }

        public class Extension
        {
            public string url { get; set; }
            public string valueString { get; set; }
        }

        public class Given
        {
            public List<Extension> extension { get; set; }
        }

        public class Name
        {
            public string text { get; set; }
            public string family { get; set; }
            public List<Given> _given { get; set; }
        }

        public class Telecom
        {
            public string value { get; set; }
            public string use { get; set; }
        }

        public class Address
        {
            public string text { get; set; }
        }

        public class MaritalStatus
        {
            public string text { get; set; }
        }

        public class Language
        {
            public string text { get; set; }
        }

        public class Communication
        {
            public Language language { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public List<Identifier> identifier { get; set; }
            public List<Name> name { get; set; }
            public List<Telecom> telecom { get; set; }
            public string gender { get; set; }
            public string birthDate { get; set; }
            public List<Address> address { get; set; }
            public MaritalStatus maritalStatus { get; set; }
            public List<Communication> communication { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class DemographicsDetails
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }

    }
}
