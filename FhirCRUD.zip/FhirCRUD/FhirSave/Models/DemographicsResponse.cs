﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Address
    {
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string country { get; set; }
        public string zipcode { get; set; }
        public string CellPhone { get; set; }
        public string WorkPhone { get; set; }
        public string Email { get; set; }
        public string workEmail { get; set; }
    }

    public class DemographicsDetails
    {
        public string SensitiveHealth { get; set; }
        public string InactiveFlag { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public string age { get; set; }
        public string BirthGender { get; set; }
        public string DOB { get; set; }
        public string Ethnicity { get; set; }
        public string Insurance { get; set; }
        public string Race { get; set; }
        public string MaritalStatus { get; set; }
        public Address address { get; set; }
    }
    public class Demographics
    {
        public List<DemographicsDetails> DemographicsDetails { get; set; }
    }


}
