﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirSave.Models
{
    public class VitalsModel
    {
        public class Meta
        {
            public string versionId { get; set; }
            public DateTime lastUpdated { get; set; }
            public List<string> profile { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class Category
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Subject
        {
            public string reference { get; set; }
        }

        public class Performer
        {
            public string display { get; set; }
        }

        public class ValueQuantity
        {
            public double value { get; set; }
            public string unit { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string status { get; set; }
            public List<Category> category { get; set; }
            public Code code { get; set; }
            public Subject subject { get; set; }
            public DateTime effectiveDateTime { get; set; }
            public List<Performer> performer { get; set; }
            public ValueQuantity valueQuantity { get; set; }
        }

        public class Entry
        {
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
        }

        public class VitalsDetails
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public Meta meta { get; set; }
            public string type { get; set; }
            public List<Entry> entry { get; set; }
        }
    }
}
