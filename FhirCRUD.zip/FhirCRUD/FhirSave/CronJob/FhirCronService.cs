using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;


namespace FhirCronService
{
    public class FhirCronService
    {
        [FunctionName("FhirCronService")]
        public static void Run([TimerTrigger("0 10 0 * * *", RunOnStartup = false, UseMonitor = true)] TimerInfo myTimer, ILogger log)
        {
            //"0 */5 * * * *"
            //"0 10 0 * * *"

            log?.LogInformation($"FhirCronService Timer trigger function started execution at: {DateTime.Now}");
            string strPracticeId = "195900";
            ApppointmentProcessor.RetrieveAndSaveAppointments(strPracticeId, log);
            log?.LogInformation($"FhirCronService Timer trigger function finished execution at: {DateTime.Now}");
        }

    }
}
