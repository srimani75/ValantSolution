﻿using Hl7.Fhir.Rest;
using Hl7.Fhir.Model;
using FhirCronService.Processors;
using Microsoft.Extensions.Logging;

namespace FhirCronService.Models
{
    public class FhirStore
    {
        public Patient FhirPatient { get; set; }
        public Practitioner FhirProvider { get; set; }

        public Location FhirLocation { get; set; }
    }
    public class ProcessorParams
    {
        public FhirStore FhirObjects
        {
            get;set;
        }
        public string PatientId { get; set; }
        public string PracticeId { get; set; }

        public string AppointmentId { get; set; }

        public string PractitionerId { get; set; }

        public string AthenaToken { get; set; }

        public string LocationId { get; set; }

        public string DepartmentId { get; set; }

        public FhirClient FhirClientObject { get; set; }

        public AppoinementInfo ApptInfo { get; set; }

        public PractitionerInformation ProviderInfo { get; set; }

        public PatientInformation PatientInfo { get; set; }

        public CoverageInformation CoverageInfo { get; set; }

        public LocationInfo LocInfo { get; set; }

        public ILogger LogggerObject;
        public void RelaodInfoObjects()
        {
            if (ProviderInfo == null)
            {
                ProviderInfo = ProviderProcessor.RetrieveAndBuildPractitioner(LogggerObject, PracticeId, PractitionerId, AthenaToken);
            }
            if (PatientInfo == null)
            {
                PatientInfo = PatientProcessor.RetrieveAndBuildPatient(PracticeId, PatientId, AthenaToken, LogggerObject);
            }
            if (LocInfo == null)
            {
                LocInfo = LocationProcessor.RetrieveAndBuildLocation(DepartmentId, AthenaToken);
            }
        }
    }
}
