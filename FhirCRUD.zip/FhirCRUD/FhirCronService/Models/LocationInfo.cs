﻿using System.Collections.Generic;

namespace FhirCronService.Models
{
    public class PositionInfo
    {
        public decimal? Latitude { get; set; }
        public  decimal? Longtitude { get; set; }
        public decimal? altitude { get; set; }
    }
    public class LocationInfo
    {
        /*

        [
    {
        "creditcardtypes": [
            "AX",
            "DS",
            "MC",
            "VI"
        ],
        "timezoneoffset": -5,
        "singleappointmentcontractmax": "3000",
        "state": "MA",
        "placeofservicefacility": false,
        "latitude": "34.25597",
        "departmentid": "1",
        "address": "311 arsenal street",
        "placeofservicetypeid": "11",
        "longitude": "-85.17026",
        "clinicals": "ON",
        "timezone": -4,
        "name": "Cruickshank HEALTH CARE",
        "patientdepartmentname": "Rome Office - this is a test to see how long this field actually is. 75 ch",
        "chartsharinggroupid": "42",
        "placeofservicetypename": "OFFICE",
        "zip": "02472-2785",
        "timezonename": "America/New_York",
        "communicatorbrandid": "1",
        "medicationhistoryconsent": false,
        "ishospitaldepartment": false,
        "providergroupid": "1",
        "portalurl": "1959-1.portal.athenahealth.com",
        "city": "WATERTOWN",
        "servicedepartment": true,
        "oneyearcontractmax": "1500",
        "fax": "72009333688608",
        "providergroupname": "7 Hills Medical Group",
        "doesnotobservedst": false,
        "phone": "(555) 004-0271",
        "ecommercecreditcardtypes": [
            "AX",
            "DS",
            "MC",
            "VI"
        ]
    }
]
        */



        public AddressInfo LocationAddress { get; set; }
        public string Name { get; set; }

        public List<TelecomInfo> ContactInfo { get; set; }

        public PositionInfo LocationPosition { get; set; }

        public string Description { get; set; }

        public List<IdentifierInfo> Ids { get; set; }
    }
}
