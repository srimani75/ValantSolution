﻿using System.Collections.Generic;

namespace FhirCronService
{
    public class ValueCodeableConcept
    {
        public List<CodingInfo> coding { get; set; }
        public string text { get; set; }
    }
}
