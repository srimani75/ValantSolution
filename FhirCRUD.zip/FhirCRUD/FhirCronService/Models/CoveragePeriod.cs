﻿using System;

namespace FhirCronService
{
    public class CoveragePeriod
    {
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }
}
