﻿namespace FhirCronService
{
    /*
     [
    {
        "firstname": "Abcd",
        "specialty": "Child and Adolescent Psychiatry",
        "homedepartment": "Cruickshank HEALTH CARE",
        "acceptingnewpatients": true,
        "specialtyid": 670,
        "schedulingname": "1",
        "providertypeid": "MD",
        "billable": true,
        "scheduleresourcetype": "Physical Therapy",
        "ansinamecode": "Allopathic & Osteopathic Physicians : Internal Medicine (207R00000X)",
        "lastname": "711",
        "providerid": 1096,
        "supervisingproviderusername": "P1871559229",
        "supervisingproviderid": 500,
        "ansispecialtycode": "207R00000X",
        "hideinportal": false,
        "sex": "M",
        "entitytype": "Person",
        "npi": 1234567890,
        "providertype": "MD",
        "createencounteroncheckin": false
        }
    ]
    */
    public class CodingInfo
    {
        public string system { get; set; }
        public string code { get; set; }
        public string display { get; set; }
    }
}
