﻿namespace FhirCronService
{
    public class TelecomInfo
    {
        public string system { get; set; }
        public string value { get; set; }
        public string use { get; set; }
    }
}
