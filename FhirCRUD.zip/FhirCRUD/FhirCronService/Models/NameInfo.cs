﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace FhirCronService
{
    public class NameInfo
    {
        [JsonProperty("use")]
        public string NameUse { get; set; }
        [JsonProperty("text")]
        public string NameText { get; set; }
        [JsonProperty("family")]
        public string FamilyName { get; set; }
        [JsonProperty("given")]
        public List<string> GivenName { get; set; }
    }
}
