﻿using System.Collections.Generic;

namespace FhirCronService
{
    public class IssueInfo
    {
        public string severity { get; set; }
        public string code { get; set; }
        public Details details { get; set; }
        public List<string> location { get; set; }
    }
}
