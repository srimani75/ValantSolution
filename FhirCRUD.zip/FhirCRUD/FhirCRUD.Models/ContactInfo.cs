﻿using FhirCronService;
using System.Collections.Generic;

namespace Optum.Fhir.Models
{
    public class ContactInfo
    {
        public bool active { get; set; }
        public string ContactType { get; set; }
        public NameInfo name { get; set; }
        public List<TelecomInfo> telecom { get; set; }
        public string gender { get; set; }
        public AddressInfo address { get; set; }
    }
}