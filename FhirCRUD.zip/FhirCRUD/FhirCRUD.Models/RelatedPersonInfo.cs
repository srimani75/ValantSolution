﻿using FhirCdaProcessor.Models;
using FhirCronService;
using System;
using System.Collections.Generic;
using System.Text;

/*namespace Optum.Fhir.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    /*public class Text
    {
        public string status { get; set; }
        public string div { get; set; }
    }

    public class Type
    {
        public string text { get; set; }
    }

    public class Identifier
    {
        public string use { get; set; }
        public Type type { get; set; }
        public string system { get; set; }
        public string value { get; set; }
    }

    public class Patient
    {
        public string reference { get; set; }
    }

    public class Coding
    {
        public string system { get; set; }
        public string code { get; set; }
    }

    public class Relationship
    {
        public List<Coding> coding { get; set; }
    }

    public class Extension
    {
        public string url { get; set; }
        public string valueString { get; set; }
    }

    public class Family
    {
        public List<Extension> extension { get; set; }
    }

    public class Name
    {
        public string family { get; set; }
        public Family _family { get; set; }
        public List<string> given { get; set; }
    }

    public class Telecom
    {
        public string system { get; set; }
        public string value { get; set; }
    }

    public class Address
    {
        public List<string> line { get; set; }
        public string city { get; set; }
        public string postalCode { get; set; }
        public string country { get; set; }
    }

    public class Photo
    {
        public string contentType { get; set; }
        public string url { get; set; }
    }
}*/

namespace Optum.Fhir.Models
{
    public class RelatedPersonInfo
    {
        public List<FhirCdaProcessor.Models.IdentifierInfo> identifier { get; set; }
        public bool active { get; set; }
        //public Patient patient { get; set; }
        public string relationship { get; set; }
        public List<NameInfo> name { get; set; }
        public List<TelecomInfo> telecom { get; set; }
        public string gender { get; set; }
        public List<AddressInfo> address { get; set; }
        public List<Image> photo { get; set; }

        public string ssn { get; set; }
    }
}