﻿using Newtonsoft.Json;

namespace Optum.Fhir.Models
{
    [JsonObject("image")]
    public class Image
    {
        [JsonProperty("imageContents")]
        public string ImageContents { get; set; }
        [JsonProperty("title")]
        public string Title { get; set; }
    }
}
