﻿using Newtonsoft.Json;
using Optum.Fhir.Models;
using System.Collections.Generic;


namespace FhirCronService.Models
{
    [JsonObject("patientDemographics")]
    public class PatientDemographics
    {
        [JsonProperty("patientId")]
        public string PatientId { get; set; }

        [JsonProperty("fhitPatientId")]
        public string FhirPatientId { get; set; }
        [JsonProperty("name")]
        public List<NameInfo> Names { get; set; }
        [JsonProperty("address")]
        public List<AddressInfo> Addresses { get; set; }

        [JsonProperty("photoIdentifiers")]
        public Image[] PhotoIdentifiers { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        public List<TelecomInfo> telecom { get; set; }

        public string Gender { get; set; }

        public string Race { get; set; }

        public string SSN { get; set; }

        public string Ethnicity { get; set; }

        public string ReligioisAffiliation { get; set; }

        public RelatedPersonInfo GurantorInformation { get; set; }

        public ContactInfo EmergencyContact { get; set; }

        public  ContactInfo EmployerInformation { get; set; }
        public object Gurantor { get; set; }


        /*SSN- this doesn't need to be modified at this time.
Home Phone Number
Cell Phone number
Work Number
Primary Language
Sex Assigned at birth
Marital Status
Race
Ethnicity
Religious Affiliation
Emergency Contact Information
Name
Relationship
Phone Number
Employer Information
Employer Name
Employer Phone Number
Employer Address
Apartment/Suite
City
State
Zip Code
Guarantor Information
First Name
Last Name
DOB
Gender
Home Phone
Address 1
Apartment/Suite
City
State
Zip Code
SSN*/
    }


}
