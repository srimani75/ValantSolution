﻿using FhirCronService;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;

namespace FhirSave
{
    public static class FhirToken
	{
		public static string GetBearerToken(ILogger log)
		{
			/*var clientSecret = Utilities.GetEnvironmentVariable("Client_Secret");
			var clientId = Utilities.GetEnvironmentVariable("Client_Id");
			var grantType = Utilities.GetEnvironmentVariable("Grant_Type");
			var resource = Utilities.GetEnvironmentVariable("resource");
			var tenantId = Utilities.GetEnvironmentVariable("Tenant_Id");*/

			var grantType = "Client_Credentials";
			var resource = "https://optum-fhirserver-dev.azurehealthcareapis.com";
			var tenantId = "db05faca-c82a-4b9d-b9c5-0f64b6755421";
			var clientId = "1337859b-6fd6-45b8-9fe6-8c6b59aee739";
			var clientSecret = "_sp0Vc00NZsq.H-t7kZqPI4w~4vf2PTKog";


			//var clientSecret = "g8JNWG0_Z0IMLEj9-2foGJTfS.q9.~YKR-";
			//var clientId = "f5f2e01d-1fe4-43ef-a86c-27e1f384b40a";
			//var grantType = "Client_Credentials";
			//var resource = "https://optum-fhirserver-prod.azurehealthcareapis.com";
			//var tenantId = "db05faca-c82a-4b9d-b9c5-0f64b6755421";
			log?.LogInformation(clientSecret);
			log?.LogInformation(clientId);

			var authUrl = string.Format("https://login.microsoftonline.com/{0}/oauth2/token", tenantId);
			var client = new RestClient(authUrl);
			var request = new RestRequest(Method.POST);
			log?.LogInformation(authUrl);

			request.AddParameter("grant_type", grantType);
			request.AddParameter("client_id", clientId);
			request.AddParameter("client_secret", clientSecret);
			request.AddParameter("resource", resource);

			IRestResponse fhirTokenResponse = client.Execute(request);

			//var fhirTokenResponse = fhirTokenClient.Execute<FhirBearerToken>(request);
			//string jsonData = JsonConvert.DeserializeObject<string>(fhirTokenResponse.Content);

			var jObject = JsonConvert.DeserializeObject<FhirBearerToken>(fhirTokenResponse.Content);
			log?.LogInformation(jObject.access_token);
			return jObject.access_token;
		}

		public static string GetBearerTokenDirect(ILogger log)
		{
			/*var clientSecret = Utilities.GetEnvironmentVariable("Client_Secret");
			var clientId = Utilities.GetEnvironmentVariable("Client_Id");
			var grantType = Utilities.GetEnvironmentVariable("Grant_Type");
			var resource = Utilities.GetEnvironmentVariable("resource");
			var tenantId = Utilities.GetEnvironmentVariable("Tenant_Id");*/

			var authUrl = string.Format("https://getfhirtokentst.azurewebsites.net/api/GetFhirToken?code=HfL4FEW16bkGW8zrZlCO4gVCz98Clsy07OAr9d8OfBWfzX3LlqJfkw==");
			var client = new RestClient(authUrl);
			var request = new RestRequest(Method.GET);

			IRestResponse fhirTokenResponse = client.Execute(request);
			fhirTokenResponse.Content = fhirTokenResponse.Content.Replace("\\\"", "\"").TrimStart('\"').TrimEnd('\"');
			var jObject = JsonConvert.DeserializeObject<FhirBearerToken>(fhirTokenResponse.Content);

			return jObject.access_token;
		}

	}
	public class FhirBearerToken
	{
		public string token_type { get; set; }
		public string expires_in { get; set; }
		public string ext_expires_in { get; set; }
		public string expires_on { get; set; }
		public string not_before { get; set; }
		public string resource { get; set; }
		public string access_token { get; set; }
	}

	/*
	 		public static string GetBearerToken(ILogger log)
		{
			//return GetBearerTokenDirect(log);

			var clientSecret = Utils.ReliantUtlity.GetEnvironmentVariable("Client_Secret");
			var clientId = Utils.ReliantUtlity.GetEnvironmentVariable("Client_Id");
			var grantType = Utils.ReliantUtlity.GetEnvironmentVariable("Grant_Type");
			var resource = Utils.ReliantUtlity.GetEnvironmentVariable("resource");
			var tenantId = Utils.ReliantUtlity.GetEnvironmentVariable("Tenant_Id");


			//var tenantId = "db05faca-c82a-4b9d-b9c5-0f64b6755421";

			log.LogInformation(clientSecret);

			var authUrl = string.Format("https://login.microsoftonline.com/{0}/oauth2/token", tenantId);
			var client = new RestClient(authUrl);
			var request = new RestRequest(Method.POST);

			request.AddParameter("grant_type", grantType);
			request.AddParameter("client_id", clientId);
			request.AddParameter("client_secret", clientSecret);
			request.AddParameter("resource", resource);

			IRestResponse fhirTokenResponse = client.Execute(request);
			//var fhirTokenResponse = fhirTokenClient.Execute<FhirBearerToken>(request);		

			//string jsonData = JsonConvert.DeserializeObject<string>(fhirTokenResponse.Content);
			var jObject = JsonConvert.DeserializeObject<FhirBearerToken>(fhirTokenResponse.Content);

			return jObject.access_token;
		}

	*/
}