﻿using FhirSave;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;

namespace FhirCronService
{
    public class TokenHandler
    {
        public static string GetAthenaToken(ILogger log)
        {
            string authUrl = "https://api.preview.platform.athenahealth.com/oauth2/v1/token";
            string grant_type = "client_credentials";
            string scope = "athena/service/Athenanet.MDP.*";
            string auth = "Basic MG9hOHVhOXoyaHhJdWxVWVEyOTc6OS1udTdsRGE5UU1LQmhkVEpLQU5jYlBXUTZZV3BTYzlWTzlJdzhXcQ==";
            string contentType = "application/x-www-form-urlencoded";
            string cookie = "dtCookie=C001B1F3C44F75E3BB85AF31580264F9|RUM+Default+Application|1";

            var client = new RestClient(authUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", auth);
            request.AddHeader("Content-Type", contentType);
            request.AddHeader("Cookie", cookie);
            request.AddParameter("grant_type", grant_type);
            request.AddParameter("scope", scope);
            IRestResponse tokenResponse = client.Execute(request);
            //Console.WriteLine(tokenResponse.Content);
            //string jsonData = JsonConvert.DeserializeObject<string>(tokenResponse.Content);
            dynamic tokenObj = JsonConvert.DeserializeObject(tokenResponse.Content);
            log?.LogInformation(tokenResponse.Content);
            return tokenObj.access_token;
        }

        public static string GetFhirToken(ILogger log = null)
        {
            return FhirToken.GetBearerToken(log);
        }
       /*public static string GetFhirToken()
        {
            var tknClient = new RestClient("https://fhirservicesapi.azurewebsites.net/api/FHIRTokenService?code=PlH63rldpjj/qzK06K4hpaMmcfeeZa8Xv4aeyfrp6ZZTl1IXH8dX9g==");
            tknClient.Timeout = -1;
            var tknRequest = new RestRequest(Method.GET);
            tknRequest.AddHeader("clientId", "92c5bbe2-5333-4114-bbd4-d4072b2c7c0b");
            tknRequest.AddHeader("clientSecret", "JMh7Q~VLLMam51HU2glfDf31mnF3MkxwcOwSY");
            tknRequest.AddHeader("Content-Type", "application/json");

            IRestResponse tknResponse = tknClient.Execute(tknRequest);
            tknResponse.Content = tknResponse.Content.Replace("\\\"", "\"").TrimStart('\"').TrimEnd('\"');

            dynamic tokenObj = JsonConvert.DeserializeObject(tknResponse.Content.ToString());
            //Console.WriteLine(tknResponse.Content);
            //Console.WriteLine("-----------------------------------------------");
            return tokenObj.access_token;

        }*/
    }
}
