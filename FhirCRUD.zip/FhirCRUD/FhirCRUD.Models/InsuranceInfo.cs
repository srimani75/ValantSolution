﻿using Newtonsoft.Json;

namespace Optum.Fhir.Models
{
    [JsonObject("insuranceInfo")]
    public class InsuranceInfo
    {
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("fhirInsuranceId")]
        public string FhirInsuranceId { get; set; }
        [JsonProperty("policyHolder")]
        public string PolicyHolder { get; set; }
        [JsonProperty("memberId")]
        public string MemberId { get; set; }
        [JsonProperty("groupNumber")]
        public string GroupNumber { get; set; }
        [JsonProperty("insuranceProvider")]
        public string InsuranceProvider { get; set; }
        [JsonProperty("payerId")]
        public string PayerId { get; set; }
        [JsonProperty("relationshipToIinsured")]
        public string RelationshipToIinsured { get; set; }
        //status: "idle" | "loading" | "failed";
        [JsonProperty("insuranceCardImages")]
        public Image[] InsuranceCardImages { get; set; }

        [JsonProperty("patientId")]
        public string PatientId { get; set; }
    }
}
