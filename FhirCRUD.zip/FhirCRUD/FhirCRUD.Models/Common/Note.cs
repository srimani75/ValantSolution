﻿namespace FhirCdaProcessor.Models
{
    public class Note
    {
        public string text { get; set; }
    }
}
