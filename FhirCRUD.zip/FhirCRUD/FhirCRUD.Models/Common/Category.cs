﻿using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{
    public class Category
    {
        public List<Coding> coding { get; set; }
    }
}
