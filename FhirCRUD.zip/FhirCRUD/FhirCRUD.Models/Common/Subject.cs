﻿namespace FhirCdaProcessor.Models
{
    public class Subject
    {
        public string reference { get; set; }
        public string display { get; set; }
    }
}
