﻿using FhirCronService;
using System;
using System.Collections.Generic;
using System.Text;

namespace FhirCdaProcessor.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    /*public class Text
    {
        public string status { get; set; }
        public string div { get; set; }
    }

    public class Coding
    {
        public string system { get; set; }
        public string code { get; set; }
        public string display { get; set; }
    }*/

    public class Form
    {
        public List<Coding> coding { get; set; }
        public string text { get; set; }
    }

    public class ItemCodeableConcept
    {
        public List<CodingInfo> coding { get; set; }
    }

    public class Numerator
    {
        public double value { get; set; }
        public string system { get; set; }
        public string code { get; set; }
    }

    public class Denominator
    {
        public int value { get; set; }
        public string system { get; set; }
        public string code { get; set; }
    }

    public class Strength
    {
        public Numerator numerator { get; set; }
        public Denominator denominator { get; set; }
    }

    public class Ingredient
    {
        public ItemCodeableConcept itemCodeableConcept { get; set; }
        public Strength strength { get; set; }
    }

    public class Contained
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Form form { get; set; }
        public List<Ingredient> ingredient { get; set; }
    }

    public class PartOf
    {
        public string reference { get; set; }
    }

    

    public class MedicationReference
    {
        public string reference { get; set; }
    }

   

    public class Context
    {
        public string reference { get; set; }
        public string display { get; set; }
    }

    public class EffectivePeriod
    {
        public DateTime start { get; set; }
        public DateTime end { get; set; }
    }

    public class ReasonCode
    {
        public List<Coding> coding { get; set; }
    }

    public class Request
    {
        public string reference { get; set; }
    }

    

    public class Route
    {
        public List<Coding> coding { get; set; }
    }

    public class Method
    {
        public string text { get; set; }
    }

    public class DoseInfo
    {
        public int value { get; set; }
        public string unit { get; set; }
        public string system { get; set; }
        public string code { get; set; }
    }

    public class RateRatio
    {
        public Numerator numerator { get; set; }
        public Denominator denominator { get; set; }
    }

    public class DosageInfo
    {
        public string text { get; set; }
        public Site site { get; set; }
        public Route route { get; set; }
        public Method method { get; set; }
        public DoseInfo dose { get; set; }
        public RateRatio rateRatio { get; set; }
    }



    public class MedicationInfo
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Text text { get; set; }
        public List<Contained> contained { get; set; }
        public List<PartOf> partOf { get; set; }
        public string status { get; set; }
        public Category category { get; set; }
        public MedicationReference medicationReference { get; set; }
        public Subject subject { get; set; }
        public Context context { get; set; }
        public EffectivePeriod effectivePeriod { get; set; }
        public List<Performer> performer { get; set; }
        public List<ReasonCode> reasonCode { get; set; }
        public Request request { get; set; }
        public DosageInfo dosage { get; set; }
    }
}
