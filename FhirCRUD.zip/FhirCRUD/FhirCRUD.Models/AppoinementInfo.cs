﻿using System;
using Hl7.Fhir.Model;
using System.Collections.Generic;

namespace FhirCronService
{
    public class AppoinementInfo
    {
        public string PatientId { get; set; }
        public Patient ApptPatient { get; set; }
        public string Id { get; set; }
        public string AppointmentId { get; set; }

        public Practitioner ApptPractitioner { get; set; }
        public Location ApptLocation { get; set; }
        public string PractitionerId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public List<IdentifierInfo> Ids { get; set; }

        public string ScheduleDateTime { get; set; }

        public string ApptStatus { get; set; }

        public string PatientAppointmentTypeName { get; set; }
        public string PatientAppointmentType { get; set; }

        public List<string> PatientIds { get; set; }
        public List<string> PractitionerIds { get; set; }

        public string DepartmentId { get; set; }


    }
}
