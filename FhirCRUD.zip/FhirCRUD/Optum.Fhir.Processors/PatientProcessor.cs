﻿using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using static Hl7.Fhir.Model.ContactPoint;

namespace FhirCronService
{
    public class PatientProcessor
    {
        /*
        [
        {
        "email": "benjamin.ziemeitaque8179356@bode.info",
        "departmentid": "1",
        "homephone": "5553516538",
        "portalaccessgiven": true,
        "driverslicense": false,
        "contactpreference_appointment_email": true,
        "contactpreference_appointment_sms": false,
        "contactpreference_billing_phone": true,
        "contactpreference_announcement_phone": true,
        "contactpreference_lab_sms": false,
        "zip": "43799",
        "guarantoraddresssameaspatient": false,
        "portaltermsonfile": true,
        "status": "active",
        "lastname": "O'Conner",
        "city": "EAST FORD",
        "sex": "F",
        "privacyinformationverified": false,
        "primarydepartmentid": "1",
        "contactpreference_lab_email": true,
        "balances": [
            {
                "balance": 0,
                "departmentlist": "1,21,102,145,148,150,157,162,166,168",
                "providergroupid": 1,
                "cleanbalance": true
            }
        ],
        "contactpreference_announcement_sms": false,
        "primaryproviderid": "71",
        "patientphoto": false,
        "contactpreference_billing_email": true,
        "contactpreference_announcement_email": true,
        "registrationdate": "07/02/2012",
        "firstname": "Jamey",
        "guarantorcountrycode": "USA",
        "state": "ME",
        "contactpreference_appointment_phone": true,
        "patientid": "1096",
        "dob": "12/23/1980",
        "guarantorrelationshiptopatient": "1",
        "address1": "85166 Alexys Streets, La",
        "contactpreference_billing_sms": false,
        "maritalstatus": "U",
        "countrycode": "USA",
        "maritalstatusname": "UNKNOWN",
        "consenttotext": false,
        "countrycode3166": "US",
        "onlinestatementonly": true,
        "contactpreference_lab_phone": true,
        "guarantorcountrycode3166": "US"
        }
        ]
    */

        #region Private Methods to Build Patient Object...

        private static PatientInformation BuildPatientInfo(string patResponse)
        {
            dynamic objPatient = JsonConvert.DeserializeObject(patResponse);
            dynamic objPat = objPatient[0];
            PatientInformation ptInfo = new PatientInformation();
            ptInfo.address = new List<AddressInfo>();
            ptInfo.telecom = new List<TelecomInfo>();
            ptInfo.Ids = new List<IdentifierInfo>();
            ptInfo.ConsentToText = objPat.contactpreference_lab_sms;

            ptInfo.id = objPat.patientid;
            ptInfo.name = new List<NameInfo>
                {
                    new NameInfo
                    {
                         FamilyName= objPat.lastname?.ToString(),
                        GivenName = new List<string>() { objPat.firstname?.ToString() },
                        NameUse = HumanName.NameUse.Usual.ToString(),
                        NameText = objPat.firstname?.ToString()


                    }
                };
            ptInfo.active = objPat.status != null && objPat.statuscc == "active";
            if (objPat.sex != null)
                ptInfo.gender = Utilities.GetGender(objPat.sex?.ToString());
            if (objPat.dob != null)
                ptInfo.birthDate = DateTime.Parse(objPat.dob?.ToString())?.ToString("yyyy-MM-dd");
            if (!(objPat.maritalstatus == null && objPat.maritalstatusname == null))
            {
                ptInfo.MaritalStatus = new CodingInfo
                {
                    system = "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
                    code = objPat.maritalstatus,
                    display = objPat.maritalstatusname
                };
            }
            if (!(objPat.city == null && objPat.zip == null && objPat.state == null && objPat.zip == null && objPat.country == null && objPat.address1 == null && objPat.address2 == null))
            {
                ptInfo.address.Add(new AddressInfo
                {
                    AddressUse = Address.AddressUse.Home.ToString(),
                    City = objPat.city,
                    PostalCode = objPat.zip,
                    State = objPat.state,
                    Country = objPat.countrycode,
                    
                    Lines = new List<string>()
                        {
                            objPat.address1?.ToString(),
                            objPat.address2?.ToString(),
                        }
                });
            }

            if (objPat.cellphone != null)
            {
                ptInfo.telecom.Add(
                    new TelecomInfo
                    {
                        system = ContactPointSystem.Phone.ToString(),
                        use = ContactPointUse.Mobile.ToString(),
                        value = objPat.cellphone
                    }
                  );
            }
            if (objPat.workphone != null)
            {
                ptInfo.telecom.Add(
                    new TelecomInfo
                    {
                        system = ContactPointSystem.Phone.ToString(),
                        use = ContactPointUse.Work.ToString(),
                        value = objPat.workphone
                    }
                    );
            }
            if (objPat.homephone != null)
            {
                ptInfo.telecom.Add(
                    new TelecomInfo
                    {
                        system = ContactPointSystem.Phone.ToString(),
                        use = ContactPointUse.Home.ToString(),
                        value = objPat.homephone
                    }
                    );
            }
            if (objPat.email != null)
            {
                ptInfo.telecom.Add(
                    new TelecomInfo
                    {
                        system = ContactPointSystem.Email.ToString(),
                        value = objPat.email,
                        use = ContactPointUse.Home.ToString()
                    }
                    );
            }
            ptInfo.Ids.Add(
                new IdentifierInfo
                {
                    IdName = "AthenaMRN",
                    IdValue = objPat.patientid
                }
             );
            ptInfo.Ids.Add(
                new IdentifierInfo
                {
                    IdName = "OID",
                    IdValue = "2.16.840.1.113883.3.2966.500.2.2.6.3.56.2"
                }
             );
            ptInfo.Ids.Add(
                new IdentifierInfo
                {
                    IdName = "ODXMRN",
                    IdValue = objPat.patientid
                }
             );


            return ptInfo;
        }
        private static Patient BuildPatient(PatientInformation ptInfo)
        {
            Patient patientObj = new Patient();

            patientObj.Identifier = new List<Identifier>();
            patientObj.Telecom = new List<ContactPoint>();
            patientObj.Name = new List<HumanName>();
            patientObj.Address = new List<Address>();
            patientObj.GeneralPractitioner = new List<ResourceReference>();

            foreach (var id in ptInfo.Ids)
            {
                patientObj.Identifier.Add(
                    new Identifier
                    {
                        System = id.IdName,
                        Value = id.IdValue
                    }
                    );
            }

            foreach (var ci in ptInfo.telecom)
            {
                patientObj.Telecom.Add(
                    new ContactPoint
                    {
                        Use = Enum.Parse<ContactPointUse>(ci.use),
                        System = Enum.Parse<ContactPointSystem>(ci.system),
                        Value = ci.value
                    }
                    );
            }

            patientObj.Name = new List<HumanName>();
            foreach (var nm in ptInfo.name)
            {
                HumanName hmnName = new HumanName
                {
                    Family = nm.FamilyName,
                    Given = nm.GivenName,
                    Text = nm.NameText,
                    Use = Enum.Parse<HumanName.NameUse>(nm.NameUse),
                    GivenElement = new List<FhirString>()
                };
                foreach(string  givenNm in nm.GivenName)
                {
                    FhirString phygn = new FhirString();
                    phygn.SetStringExtension("https://www.hl7.org/fhir/datatypes.html#HumanName", givenNm);
                    hmnName.GivenElement.Add(phygn);
                }
                patientObj.Name.Add(hmnName);
            }
            
            patientObj.Address = new List<Address>();

            foreach (var addr in ptInfo.address)
            {
                patientObj.Address.Add(
                    new Address
                    {
                        City = addr.City,
                        Country = addr.Country,
                        PostalCode = addr.PostalCode,
                        State = addr.State,
                        Line = addr.Lines,
                        Use = Enum.Parse<Address.AddressUse>(addr.AddressUse),
                        Text = addr.Lines.FirstOrDefault()
                    }
                    );
            }


            if (ptInfo.birthDate != null)
                patientObj.BirthDate = ptInfo.birthDate;
            if (ptInfo.gender != null)
                patientObj.Gender = Enum.Parse<AdministrativeGender>(ptInfo.gender);

            if (patientObj.MaritalStatus != null)
            {
                patientObj.MaritalStatus = new CodeableConcept
                {
                    Coding = new List<Coding>() {
                        new Coding
                        {
                            System = ptInfo.MaritalStatus.system,
                            Code = ptInfo.MaritalStatus.code,
                            Display = ptInfo.MaritalStatus.display
                        }
                    }
                };
            }
            
            if(ptInfo.GeneralPractitionerIds != null)
            {
                foreach(var pracId in ptInfo.GeneralPractitionerIds)
                {
                    patientObj.GeneralPractitioner.Add(
                        new ResourceReference
                        {
                            Display = string.Format("Practitioner/{0}", pracId)
                        }
                        );
                }
            }
            return patientObj;
        }

        private static string  RetrievePatient(string practiceId, string patientId, string athenaToken, ILogger log)
        {
            //string accessToken = TokenHandler.GetAthenaToken(log);
            var client = new RestClient(string.Format("https://api.preview.platform.athenahealth.com/v1/{0}/patients/{1}", practiceId, patientId));
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("accept", "application/json");
            request.AddHeader("Authorization", string.Format("Bearer {0}", athenaToken));
            IRestResponse patResponse = client.Execute(request);
            //Console.WriteLine(patResponse.Content);
            return patResponse.Content;
        }

        #endregion

        public static Patient SavePatient(PatientInformation ptInfo,  ILogger log)
        {
            log.LogInformation("Saving Patient.....");
            Patient patientObj = BuildPatient(ptInfo);
            FhirClient fhClient = Utilities.BuildFhirClient();
            return fhClient.Create(patientObj);

        }

        public static Patient SavePatientAndProvider(PatientInformation ptInfo,string fhitProviderId,  FhirClient fhClient,ILogger log)
        {
            ptInfo.GeneralPractitionerIds = new List<string>()
            {
                fhitProviderId
            };
            Patient patientObj = BuildPatient(ptInfo);
            
            //fhClient = Utilities.BuildFhirClient();
            return  fhClient.Create(patientObj);
        }

        public static PatientInformation RetrieveAndBuildPatient(string practiceId, string patientId, string athenaToken, ILogger log)
        {
            return BuildPatientInfo(RetrievePatient(practiceId, patientId, athenaToken, log));
        }

        public static Patient LookupOrSavePatient(ref ProcessorParams input, ILogger log)
        {
            Patient retPatient = Utilities.LookupResource<Patient>(input.PatientId, input.FhirClientObject);
            Practitioner retPrac = ProviderProcessor.LookupOrSavePractitioner(log, ref input);
            input.FhirObjects.FhirProvider = retPrac;
            if (retPatient == null)
            {
                PatientInformation ptInfo = RetrieveAndBuildPatient(input.PracticeId, input.PatientId, input.AthenaToken, log);
                input.PatientInfo = ptInfo;
                retPatient = SavePatientAndProvider(ptInfo, input.FhirObjects.FhirProvider.Id,input.FhirClientObject, log);
                input.LogggerObject?.LogInformation("Successfully saved Patient : {0}.", input.PatientId);
            }
            else
            {
                input.LogggerObject?.LogInformation("Didnt save Patient : {0} as the reource existed already.", input.PatientId);
            }
            return retPatient;

        }
        

        #region Commented...
        /*
         * 
                    
                    /*StringBuilder sb = new StringBuilder();
            JsonTextWriter tw = new JsonTextWriter(new StringWriter(sb));
            JsonSerializer.Create().Serialize(tw, retPatient);
            Console.WriteLine(sb.ToString());

        Getpatientinfo patInfo = new Getpatientinfo

            {
                 
                mrn = patientId,
                HomePhone = objPatient.homephone,
                Email = objPat.email,
                LastName = objPat.lastname,
                Firstname = objPat.firstname,
                City = objPat.city,
                ZipCode = objPat.zip,
                State = objPat.state,

                CountryCode = objPat.countrycode,
                Addressline1 = objPat.address1.ToString(),
                AddressLine2 = objPat.address2.ToString(),
                dateofbirth = DateTime.Parse(objPat.dob.ToString()).ToString("yyyy-MM-dd"),
                BirthSex = objPat.sex,
                MaritalStatus = objPat.maritalstatusname,
                CellPhone = objPat.cellphone,
                WorkPhone = objPat.workphone,
                DL = new DriversLicense
                { 
                     DLNumber = objPat.driverslicensenumer,
                     ExpirationDate = DateTime.Parse(objPat.driverslicenseexpirationdate),
                     IssuedState = objPat.driverslicensestateid
                },
                Ethnicity = objPat.ethnicitycode,
                GuarantorAddress = new GenericAddress
                {
                    AddressLine1 = objPat.guarantoraddress1,
                    AddressLine2 = objPat.guarantoraddress2,
                    City = objPat.guarantorcity,
                    State = objPat.guarantorstate,
                    ZipCode = objPat.guarantorzip,
                    CountryCode = objPat.guarantorcountrycode3166
                }
            };

        private static Patient UpsertPatient(string resource, FhirSave.Models.ReliantPatientModel.Patientinfo PatientDemoData, FhirClient client,
        List<FhirSave.Models.Provider> lstprv, ILogger log)
        {
            string ErrorVal = "";
            string lstcodes = "";
            var pat = new Patient();
            var pat1 = new Patient();
            var upsertpat = new Patient();
            try
            {
                if (PatientDemoData.id != null)
                {
                    switch (PatientDemoData.gender)
                    {
                        case "Female":
                        case "female":
                            pat.Gender = AdministrativeGender.Female;
                            lstcodes = lstcodes + "\"" + "F" + "\"" + ",";
                            break;
                        case "Male":
                        case "male":
                            pat.Gender = AdministrativeGender.Male;
                            lstcodes = lstcodes + "\"" + "M" + "\"" + ",";
                            break;
                        case "Other":
                        case "other":
                            pat.Gender = AdministrativeGender.Other;
                            break;
                        default:
                            pat.Gender = AdministrativeGender.Unknown;
                            break;
                    }
                    HumanName phyname = new HumanName();
                    List<HumanName> lsthumannames = new List<HumanName>();
                    if (PatientDemoData.name != null)
                    {
                        phyname.Text = PatientDemoData.name.FirstOrDefault().text;
                        phyname.Family = PatientDemoData.name.FirstOrDefault().family.FirstOrDefault();
                        List<FhirString> lstphygivenname = new List<FhirString>();
                        FhirString phygn = new FhirString();
                        phygn.SetStringExtension("https://www.hl7.org/fhir/datatypes.html#HumanName", PatientDemoData.name.FirstOrDefault().given.FirstOrDefault());
                        lstphygivenname.Add(phygn);
                        phyname.GivenElement = lstphygivenname;

                        lsthumannames.Add(phyname);

                        pat.Name = lsthumannames;
                    }
                    if (PatientDemoData.birthDate != null)
                    {
                        pat.BirthDate = DateTime.Parse(PatientDemoData.birthDate).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                        DateTime now = DateTime.Now;
                        DateTime givenDate = DateTime.Parse(pat.BirthDate);
                        int days = now.Subtract(givenDate).Days;
                        int age = (int)Math.Floor(days / 365.24219);
                        if (age > 5 && age < 17)
                            lstcodes = lstcodes + "\"" + "school" + "\"" + ",";
                    }


                    Address pataddress = new Address();
                    if (PatientDemoData.address != null)
                    {
                        switch (PatientDemoData.address.FirstOrDefault().use)
                        {
                            case "Home":
                            case "home":
                                pataddress.Use = Address.AddressUse.Home;
                                break;
                            case "Billing":
                            case "billing":
                                pataddress.Use = Address.AddressUse.Billing;
                                break;
                            case "Old":
                            case "old":
                                pataddress.Use = Address.AddressUse.Old;
                                break;
                            case "Temp":
                            case "temp":
                                pataddress.Use = Address.AddressUse.Temp;
                                break;
                            case "Work":
                            case "work":
                                pataddress.Use = Address.AddressUse.Work;
                                break;
                            default:
                                pataddress.Use = Address.AddressUse.Home;
                                break;
                        }

                        pataddress.Text = PatientDemoData.address.FirstOrDefault().line.FirstOrDefault();
                        pataddress.City = PatientDemoData.address.FirstOrDefault().city;
                        pataddress.State = PatientDemoData.address.FirstOrDefault().state;
                        pataddress.Country = PatientDemoData.address.FirstOrDefault().country;
                        pataddress.PostalCode = PatientDemoData.address.FirstOrDefault().postalCode;
                        List<Address> lstpataddr = new List<Address>();
                        lstpataddr.Add(pataddress);
                        pat.Address = lstpataddr;
                    }


                    List<ContactPoint> lstcontact = new List<ContactPoint>();
                    if (PatientDemoData.telecom != null)
                    {
                        foreach (var tel in PatientDemoData.telecom)
                        {
                            ContactPoint patMcontact = new ContactPoint();
                            //patMcontact.Value = tel.System.Value;
                            switch (tel.system)
                            {
                                case "Phone":
                                case "phone":
                                    patMcontact.System = ContactPoint.ContactPointSystem.Phone;
                                    patMcontact.Value = tel.value;
                                    break;
                                case "email":
                                case "Email":
                                    patMcontact.System = ContactPoint.ContactPointSystem.Email;
                                    patMcontact.Value = tel.value;
                                    break;
                                case "fax":
                                case "Fax":
                                    patMcontact.System = ContactPoint.ContactPointSystem.Fax;
                                    patMcontact.Value = tel.value;
                                    break;
                                case "pager":
                                case "Pager":
                                    patMcontact.System = ContactPoint.ContactPointSystem.Pager;
                                    patMcontact.Value = tel.value;
                                    break;
                                case "url":
                                case "URL":
                                    patMcontact.System = ContactPoint.ContactPointSystem.Url;
                                    patMcontact.Value = tel.value;
                                    break;
                                default:
                                    patMcontact.System = ContactPoint.ContactPointSystem.Other;
                                    patMcontact.Value = tel.value;
                                    break;
                            }
                            switch (tel.use)
                            {
                                case "Home":
                                case "home":
                                    patMcontact.Use = ContactPoint.ContactPointUse.Home;
                                    break;
                                case "Old":
                                case "old":
                                    patMcontact.Use = ContactPoint.ContactPointUse.Old;
                                    break;
                                case "Temp":
                                case "temp":
                                    patMcontact.Use = ContactPoint.ContactPointUse.Temp;
                                    break;
                                case "Work":
                                case "work":
                                    patMcontact.Use = ContactPoint.ContactPointUse.Work;
                                    break;
                                default:
                                    patMcontact.Use = ContactPoint.ContactPointUse.Home;
                                    break;
                            }

                            lstcontact.Add(patMcontact);
                        }

                        pat.Telecom = lstcontact;
                    }


                    var conditions = new SearchParams();
                    conditions.Add("identifier", PatientDemoData.id);

                    Bundle results = client.Search<Patient>(conditions);
                    if (results.Entry.Count > 0)
                    {

                        var fhirpatientId = results.Entry[0].Resource.Id;
                        var location = new Uri(resource + "/Patient/" + fhirpatientId);
                        pat1 = client.Read<Patient>(location);

                        var existpract = pat1.GeneralPractitioner;
                        var existlinkpract = pat1.Link;
                        foreach (var prv in lstprv)
                        {
                            var Practitionerconditions = new SearchParams();
                            Practitionerconditions.Add("identifier", prv.ID);

                            Bundle Practitionerresults = client.Search<Practitioner>(Practitionerconditions);
                            if (Practitionerresults.Entry.Count > 0)
                            {
                                Practitioner pract = new Practitioner();
                                var fhirpractitionerId = Practitionerresults.Entry[0].Resource.Id;
                                if (existpract.Count > 0)
                                {
                                    if (prv.Providername.Contains("PCP") && existpract[0].Reference != resource + "/Practitioner/" + fhirpractitionerId)
                                    {
                                        pat.GeneralPractitioner.Add(new ResourceReference(resource + "/Practitioner/" + fhirpractitionerId));
                                    }
                                    else
                                    {
                                        if (prv.Providername.Contains("PCP") == false)
                                        {
                                            foreach (var linkpract in existlinkpract)
                                            {
                                                if (linkpract.Other.Reference != resource + "/Practitioner/" + fhirpractitionerId)
                                                {
                                                    Patient.LinkComponent patlnkcomp = new Patient.LinkComponent();
                                                    patlnkcomp.Other = new ResourceReference(resource + "/Practitioner/" + fhirpractitionerId);
                                                    pat.Link.Add(patlnkcomp);
                                                }

                                            }

                                        }

                                    }
                                }
                                else
                                {
                                    if (prv.Providername.Contains("PCP"))
                                    {
                                        pat.GeneralPractitioner.Add(new ResourceReference(resource + "/Practitioner/" + fhirpractitionerId));
                                    }
                                    else
                                    {
                                        if (prv.Providername.Contains("PCP") == false)
                                        {
                                            Patient.LinkComponent patlnkcomp = new Patient.LinkComponent();
                                            patlnkcomp.Other = new ResourceReference(resource + "/Practitioner/" + fhirpractitionerId);
                                            pat.Link.Add(patlnkcomp);
                                        }

                                    }
                                }


                            }
                            else
                            {
                                Practitioner pract = new Practitioner();
                                Practitioner upsertpract = new Practitioner();
                                HumanName name = new HumanName();
                                name.Text = prv.Providername.Split("^")[0];
                                pract.Name.Add(name);
                                pract.Identifier.Add(new Identifier("RelientPractitionerID", prv.ID));
                                ContactPoint ctPract = new ContactPoint();
                                ctPract.Value = prv.Providername.Split("^")[1];
                                pract.Telecom.Add(ctPract);
                                upsertpract = client.Create(pract);
                                if (prv.Providername.Contains("PCP"))
                                {
                                    pat.GeneralPractitioner.Add(new ResourceReference(resource + "/Practitioner/" + upsertpract.Id));
                                }
                                else
                                {
                                    Patient.LinkComponent patlnkcomp = new Patient.LinkComponent();
                                    patlnkcomp.Other = new ResourceReference(resource + "/Practitioner/" + upsertpract.Id);
                                    pat.Link.Add(patlnkcomp);
                                }
                            }
                        }
                        var Newpat = client.Create(pat);
                        Newpat.Identifier.Add(new Identifier("RelientPatientID", PatientDemoData.id));
                        upsertpat = client.Update(Newpat);
                    }
                    else
                    {
                        foreach (var prv in lstprv)
                        {
                            var Practitionerconditions = new SearchParams();
                            Practitionerconditions.Add("identifier", prv.ID);

                            Bundle Practitionerresults = client.Search<Practitioner>(Practitionerconditions);
                            if (Practitionerresults.Entry.Count > 0)
                            {
                                Practitioner pract = new Practitioner();
                                var fhirpractitionerId = Practitionerresults.Entry[0].Resource.Id;
                                if (prv.Providername.Contains("PCP"))
                                {
                                    pat.GeneralPractitioner.Add(new ResourceReference(resource + "/Practitioner/" + fhirpractitionerId));
                                }
                                else
                                {
                                    Patient.LinkComponent patlnkcomp = new Patient.LinkComponent();
                                    patlnkcomp.Other = new ResourceReference(resource + "/Practitioner/" + fhirpractitionerId);
                                    pat.Link.Add(patlnkcomp);
                                }

                            }
                            else
                            {
                                Practitioner pract = new Practitioner();
                                Practitioner upsertpract = new Practitioner();
                                HumanName name = new HumanName();
                                name.Text = prv.Providername.Split("^")[0];
                                pract.Name.Add(name);
                                pract.Identifier.Add(new Identifier("RelientPractitionerID", prv.ID));
                                ContactPoint ctPract = new ContactPoint();
                                ctPract.Value = prv.Providername.Split("^")[1];
                                pract.Telecom.Add(ctPract);
                                upsertpract = client.Create(pract);
                                if (prv.Providername.Contains("PCP"))
                                {
                                    pat.GeneralPractitioner.Add(new ResourceReference(resource + "/Practitioner/" + upsertpract.Id));
                                }
                                else
                                {
                                    Patient.LinkComponent patlnkcomp = new Patient.LinkComponent();
                                    patlnkcomp.Other = new ResourceReference(resource + "/Practitioner/" + upsertpract.Id);
                                    pat.Link.Add(patlnkcomp);
                                }
                            }
                        }
                        var Newpat = client.Create(pat);
                        Newpat.Identifier.Add(new Identifier("RelientPatientID", PatientDemoData.id));
                        upsertpat = client.Update(Newpat);
                    }


                }
                else
                {
                    var errorResonse = new FhirSave.Models.ErrorResponse();
                    //replace with actual id
                    errorResonse.error = Guid.NewGuid().ToString();
                    errorResonse.message = "Application do not have access to Patient resource";
                    errorResonse.detail = "Application do not have access to Patient resource";

                    ErrorVal = "Application do not have access to Patient resource";
                    var evehubresponse = new Models.EventHubErrorResponse();
                    var eventhubdata = new Models.Data();
                    eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                    evehubresponse.data = eventhubdata;
                    evehubresponse.agg = env;
                    evehubresponse.type = "Error";
                    Utils.ReliantUtlity.SendMessagesToEventHub(eventhubclient, log, JsonConvert.SerializeObject(evehubresponse));
                }

            }
            catch (Exception ex)
            {
                var errorResonse = new Models.ErrorResponse();
                //replace with actual id
                errorResonse.error = Guid.NewGuid().ToString();
                errorResonse.message = ex.Message;
                errorResonse.detail = ex;

                ErrorVal = "Patient Create or Update: " + ex.Message;
                var evehubresponse = new Models.EventHubErrorResponse();
                var eventhubdata = new Models.Data();
                eventhubdata.content = JsonConvert.SerializeObject(errorResonse);
                evehubresponse.data = eventhubdata;
                evehubresponse.agg = env;
                evehubresponse.type = "Error";
                FhirSave.Utils.ReliantUtlity.SendMessagesToEventHub(eventhubclient, log, JsonConvert.SerializeObject(evehubresponse));
                //SendingRandomMessagesAsync(log, errorResonse);               
            }
            return upsertpat;
        }
        */

        #endregion

    }
}
