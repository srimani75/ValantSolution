﻿using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using System;
using System.Collections.Generic;
using static Hl7.Fhir.Model.ContactPoint;

namespace FhirCronService.Processors
{
    /*
         "insurancepolicyholdercountrycode": "USA",
            "sequencenumber": 1,
            "insurancepolicyholderlastname": "23",
            "insuredentitytypeid": 1,
            "insuranceidnumber": "2323",
            "relationshiptoinsured": "Self",
            "eligibilitystatus": "Unverified",
            "insurancepackageaddress1": "PO BOX 182223",
            "insurancepolicyholdersex": "M",
            "eligibilityreason": "Athena",
            "ircname": "Cigna",
            "insuranceplanname": "CIGNA HEALTHCARE",
            "insurancetype": "Commercial",
            "insurancephone": "(800) 882-4462",
            "insurancepackagestate": "TN",
            "insurancepackagecity": "CHATTANOOGA",
            "relationshiptoinsuredid": 1,
            "insuranceid": "22593",
            "insurancepolicyholder": "23 23",
            "eligibilitylastchecked": "10/05/2021",
            "insurancepolicyholderfirstname": "23",
            "insurancepackageid": 74,
            "ircid": 131,
            "insurancepolicyholdercountryiso3166": "US",
            "insuranceplandisplayname": "Cigna",
            "insurancepackagezip": "37422-7223"
         */
    public class OrganizationProcessor
    {
        public static OrganizationInfo BuildOrgInfo(dynamic objOrg)
        {
            OrganizationInfo orgInfo = new OrganizationInfo();
            //dynamic objOrg = JsonConvert.DeserializeObject(respOrg);
            orgInfo.Name = objOrg.insuranceplanname;
            orgInfo.Addresses = new List<AddressInfo>();
            orgInfo.ContactInfo = new List<TelecomInfo>();
            orgInfo.Ids = new List<IdentifierInfo>();


            if (objOrg.insuranceidnumber != null)
            {
                orgInfo.Ids.Add(
                    new IdentifierInfo
                    {
                        IdName = "AthenaInsuranceIdNumber",
                        IdValue = objOrg.insuranceidnumber.ToString()
                    }
                    );
            }

            if (objOrg.insuranceid != null)
            {

                orgInfo.Ids.Add(
                    new IdentifierInfo
                    {
                        IdName = "AthenaInsuranceId",
                        IdValue = objOrg.insuranceid.ToString()
                    }
                    );
            }
            if (objOrg.insurancepackageid != null)
                orgInfo.Ids.Add(
                    new IdentifierInfo
                    {
                        IdName = "AthenaInsurancePackageId",
                        IdValue = objOrg.insurancepackageid.ToString()
                    }
                    );

            if (objOrg.insurancephone != null)
            {
                orgInfo.ContactInfo.Add(
                    new TelecomInfo
                    {
                        system = ContactPointSystem.Phone.ToString(),
                        use = ContactPointUse.Work.ToString(),
                        value = objOrg.insurancephone
                    }
                    );
            }



            if (!(objOrg.insurancepackagecity == null && objOrg.insurancepackagezip == null && objOrg.insurancepackagestate == null 
                && objOrg.insurancepackagezip == null && objOrg.insurancepackageaddress1 == null && objOrg.insurancepackageaddress2 == null))
            {
                orgInfo.Addresses.Add(new AddressInfo
                {
                    AddressUse = Address.AddressUse.Billing.ToString(),
                    City = objOrg.insurancepackagecity,
                    PostalCode = objOrg.insurancepackagezip,
                    State = objOrg.insurancepackagestate,
                    Country = objOrg.insurancepolicyholdercountrycode,

                    Lines = new List<string>()
                        {
                            objOrg.insurancepackageaddress1?.ToString(),
                            objOrg.insurancepackageaddress2?.ToString(),
                        }
                });
            }
            return orgInfo;
        }

        public static Organization BuildFhirOrg(OrganizationInfo prgInfo)
        {
            Organization fhirOrg = new Organization();

            fhirOrg.Address = new List<Address>();
            fhirOrg.Telecom = new List<ContactPoint>();
            fhirOrg.Identifier = new List<Identifier>();
            fhirOrg.Name = prgInfo.Name;

            if (prgInfo.Ids != null)
            {
                foreach (var ident in prgInfo.Ids)
                {
                    fhirOrg.Identifier.Add(
                        new Identifier
                        {
                            System = ident.IdName,
                            Value = ident.IdValue
                        }
                        );
                }
            }

            if(prgInfo.ContactInfo != null)
            {
                foreach(var ci in prgInfo.ContactInfo)
                {
                    if(ci != null)
                    fhirOrg.Telecom.Add(
                        new ContactPoint
                        {
                            Use = Enum.Parse<ContactPointUse>(ci.use),
                            System = Enum.Parse<ContactPointSystem>(ci.system),
                            Value = ci.value
                        }
                        );
                }
            }

            foreach (var addr in prgInfo.Addresses)
            {
                if (addr != null)
                {
                    fhirOrg.Address.Add(
                        new Address
                        {
                            City = addr.City,
                            State = addr.State,
                            PostalCode = addr.PostalCode,
                            Country = addr.Country,
                            Line = addr.Lines
                        }
                        );
                }
            }
            return fhirOrg;
        }

        public static Organization LookupOrSaveOrganization(dynamic orgInfo,FhirClient orgClient)
        {
            string insurancePackageId = orgInfo.insurancepackageid?.ToString();
            Organization retOrg = Utilities.LookupResource<Organization>(insurancePackageId, orgClient);
            
            if(retOrg == null)
            {
                retOrg = orgClient.Create(BuildFhirOrg(BuildOrgInfo(orgInfo)));
            }

            return retOrg;
        }
    }
}
