﻿using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using static Hl7.Fhir.Model.ContactPoint;

namespace FhirCronService.Processors
{
    /*

        [
    {
        "creditcardtypes": [
            "AX",
            "DS",
            "MC",
            "VI"
        ],
        "timezoneoffset": -5,
        "singleappointmentcontractmax": "3000",
        "state": "MA",
        "placeofservicefacility": false,
        "latitude": "34.25597",
        "departmentid": "1",
        "address": "311 arsenal street",
        "placeofservicetypeid": "11",
        "longitude": "-85.17026",
        "clinicals": "ON",
        "timezone": -4,
        "name": "Cruickshank HEALTH CARE",
        "patientdepartmentname": "Rome Office - this is a test to see how long this field actually is. 75 ch",
        "chartsharinggroupid": "42",
        "placeofservicetypename": "OFFICE",
        "zip": "02472-2785",
        "timezonename": "America/New_York",
        "communicatorbrandid": "1",
        "medicationhistoryconsent": false,
        "ishospitaldepartment": false,
        "providergroupid": "1",
        "portalurl": "1959-1.portal.athenahealth.com",
        "city": "WATERTOWN",
        "servicedepartment": true,
        "oneyearcontractmax": "1500",
        "fax": "72009333688608",
        "providergroupname": "7 Hills Medical Group",
        "doesnotobservedst": false,
        "phone": "(555) 004-0271",
        "ecommercecreditcardtypes": [
            "AX",
            "DS",
            "MC",
            "VI"
        ]
    }
]
        */
    public class LocationProcessor
    {
        //static ILogger log = null;
        private static string RetrieveLocation(string departmentId, string athenaToken)
        {
            var client = new RestClient(string.Format("https://api.preview.platform.athenahealth.com/v1/195900/departments/{0}?showalldepartments=false&providerlist=false",departmentId));
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", string.Format("Bearer {0}",athenaToken));
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);
            return response.Content;
        }
        public static LocationInfo BuildLocation(string respLocation)
        {
            dynamic objLocs = JsonConvert.DeserializeObject(respLocation);
            dynamic objPracs = objLocs[0];
            LocationInfo locInfo = new LocationInfo();
            locInfo.ContactInfo = new List<TelecomInfo>();
            locInfo.Ids = new List<IdentifierInfo>();

            locInfo.Name = objPracs.name;

            locInfo.LocationPosition = new PositionInfo
            {
                Latitude = objPracs.latitude,
                Longtitude = objPracs.longtitude
            };

            if (objPracs.phone != null)
            {
                locInfo.ContactInfo.Add(
                    new TelecomInfo
                    {
                        system = ContactPointSystem.Phone.ToString(),
                        use = ContactPointUse.Work.ToString(),
                        value = objPracs.phone

                    }
                    );
            }

            if (objPracs.fax != null)
            {
                locInfo.ContactInfo.Add(
                new TelecomInfo
                {
                    system = ContactPointSystem.Fax.ToString(),
                    use = ContactPointUse.Work.ToString(),
                    value = objPracs.fax
                }
                );
            }

            locInfo.LocationAddress = new AddressInfo
            {

                City = objPracs.city,
                PostalCode = objPracs.zip,
                Lines = new List<string>() { objPracs.address.ToString() },
                State = objPracs.state
            };
            
            locInfo.Ids.Add(new IdentifierInfo
            {
                IdName = "AthenaDepartmentId",
                IdValue = objPracs.departmentid
            });


            locInfo.Description = objPracs.patientdepartmentname;
            return locInfo;
        }

        public static Location BuildFhirLocation(LocationInfo locInfo)
        {
            Location objLoc = new Location();
            objLoc.Name = locInfo.Name;
            objLoc.Description = locInfo.Description;
            objLoc.Telecom = new List<ContactPoint>();
            objLoc.Identifier = new List<Identifier>();
            objLoc.Position = new Location.PositionComponent
            {
                 //Altitude = locInfo.LocationPosition.altitude,
                 Longitude = locInfo.LocationPosition.Longtitude,
                Latitude = locInfo.LocationPosition.Latitude,
            };

            objLoc.Address = new Address
            {
                City = locInfo.LocationAddress.City,
                Country = locInfo.LocationAddress.Country,
                Line = new List<string>(locInfo.LocationAddress.Lines),
                State = locInfo.LocationAddress.State,
                PostalCode = locInfo.LocationAddress.PostalCode
            };
            foreach (var ci in locInfo.ContactInfo)
            {
                objLoc.Telecom.Add(
                    new ContactPoint
                    {
                        Use = Enum.Parse<ContactPointUse>(ci.use),
                        System = Enum.Parse<ContactPointSystem>(ci.system),
                        Value = ci.value

                    }
                );
            }
            foreach (var id in locInfo.Ids)
            {
                objLoc.Identifier.Add(
                    new Identifier
                    {
                        System = id.IdName,
                        Value = id.IdValue
                    }
                    );
            }
            return objLoc;
        }

        public static LocationInfo RetrieveAndBuildLocation(string deptId, string athenaToken)
        {   
            return  BuildLocation(RetrieveLocation(deptId, athenaToken));
        }
        public static Location SaveLocation(LocationInfo locInfo)
        {
            FhirClient fhClient = Utilities.BuildFhirClient();
            return fhClient.Create<Location>(BuildFhirLocation(locInfo));
        }
        public static Location LookupOrSaveLocation(ref ProcessorParams input)
        {
            if (input.DepartmentId == null) return null;
            Location retLoc = Utilities.LookupResource<Location>(input.DepartmentId, input.FhirClientObject);
            if(retLoc == null)
            {
                input.LocInfo = RetrieveAndBuildLocation(input.DepartmentId,input.AthenaToken);
                retLoc = SaveLocation(input.LocInfo);
                input.LogggerObject?.LogInformation("Successfully saved Location : {0}.", input.DepartmentId);
            }
            else
            {
                input.LogggerObject?.LogInformation("Didnt save Location : {0} as it existed already.", input.DepartmentId);
            }
            return retLoc;
        }
    }
}
