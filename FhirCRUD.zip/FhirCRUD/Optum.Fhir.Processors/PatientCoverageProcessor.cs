﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FhirCronService.Processors
{
    public class PatientCoverageProcessor
    {
        /*
            id: "",
            policy_holder: "",
            member_id: "",
            group_number: "",
            insurance_provider: "",
            payer_id: "",
            relationship_to_insured: "",
            insurance_card_image: "",
        */

        /*
  "insurancepolicyholdercountrycode": "USA",
     "sequencenumber": 1,
     "insurancepolicyholderlastname": "23",
     "insuredentitytypeid": 1,
     "insuranceidnumber": "2323",
     "relationshiptoinsured": "Self",
     "eligibilitystatus": "Unverified",
     "insurancepackageaddress1": "PO BOX 182223",
     "insurancepolicyholdersex": "M",
     "eligibilityreason": "Athena",
     "ircname": "Cigna",
     "insuranceplanname": "CIGNA HEALTHCARE",
     "insurancetype": "Commercial",
     "insurancephone": "(800) 882-4462",
     "insurancepackagestate": "TN",
     "insurancepackagecity": "CHATTANOOGA",
     "relationshiptoinsuredid": 1,
     "insuranceid": "22593",
     "insurancepolicyholder": "23 23",
     "eligibilitylastchecked": "10/05/2021",
     "insurancepolicyholderfirstname": "23",
     "insurancepackageid": 74,
     "ircid": 131,
     "insurancepolicyholdercountryiso3166": "US",
     "insuranceplandisplayname": "Cigna",
     "insurancepackagezip": "37422-7223"
  */

    }

}
