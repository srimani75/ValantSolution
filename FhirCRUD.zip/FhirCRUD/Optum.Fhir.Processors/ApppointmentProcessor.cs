﻿using FhirCronService.Models;
using FhirCronService.Processors;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace FhirCronService
{
    public class ApppointmentProcessor
    {
        /*
          {
         "date": "08/26/2021",
         "appointmentid": "1194714",
         "starttime": "02:51",
         "departmentid": "1",
         "appointmentstatus": "f",
         "scheduledby": "API-21206",
         "patientid": "32001",
         "duration": 30,
         "startcheckin": "08/16/2021 20:50:35",
         "templateappointmenttypeid": "62",
         "hl7providerid": 1096,
         "lastmodifiedby": "API-21206",
         "appointmentcopay": {
           "collectedforother": 0,
           "collectedforappointment": 0,
           "insurancecopay": 0
         },
         "copay": 0,
         "renderingproviderid": 1096,
         "appointmenttypeid": "62",
         "lastmodified": "08/16/2021 20:50:35",
         "appointmenttype": "Consult",
         "providerid": "1096",
         "chargeentrynotrequired": false,
         "scheduleddatetime": "08/16/2021 20:48:02",
         "coordinatorenterprise": false,
         "templateappointmentid": "1194714",
         "patientappointmenttypename": "Consultation Visit"
       },
       */

        #region PrivateRegion
        private static string ProcessAppointment(string apptStatus)
        {
            //ents as a no show when appropriate to do so.) o=open. 2=checked in. 3=checked out. 4=charge entered (i.e. a past appointment).
            switch (apptStatus)
            {
                case "x":
                    return Appointment.AppointmentStatus.Cancelled.ToString();
                case "f":
                    return Appointment.AppointmentStatus.Booked.ToString();
                case "o":
                    return Appointment.AppointmentStatus.Waitlist.ToString();
                case "2":
                    return Appointment.AppointmentStatus.CheckedIn.ToString();
                case "3":
                    return Appointment.AppointmentStatus.Fulfilled.ToString();
            }
            return string.Empty;
        }

        private static AppoinementInfo BuildAppointmentInfo(dynamic objAppt)
        {
            //dynamic objAppt = JsonConvert.DeserializeObject(apptResponse);
            AppoinementInfo apptInfo = new AppoinementInfo();
            //apptInfo.ApptPatient = (Patient) Utilities.LookupResource(objAppt.patientid);
            //apptInfo.ApptPractitioner = (Practitioner)Utilities.LookupResource(objAppt.providerid);
            apptInfo.AppointmentId = objAppt.appointmentid;
            apptInfo.DepartmentId = objAppt.departmentid;
            apptInfo.Ids = new List<IdentifierInfo>() {
                new IdentifierInfo
                {
                    IdName = "AthenaApptId",
                    IdValue = objAppt.appointmentid
                },
                new IdentifierInfo
                {
                    IdName = "AthenaMRN",
                    IdValue =objAppt.patientid
                },
                new IdentifierInfo
                {
                    IdName = "AthenaProviderId",
                    IdValue = objAppt.providerid
                },
            };
            DateTime apptDate = DateTime.Parse(objAppt.date?.ToString());
            apptInfo.StartTime = apptDate;
            apptInfo.EndTime = apptDate.AddMinutes(double.Parse(objAppt.duration?.ToString()));
            
                apptInfo.ApptStatus = ProcessAppointment(objAppt.appointmentstatus?.ToString());
            if (objAppt.scheduleddatetime != null)
                apptInfo.ScheduleDateTime = DateTime.Parse(objAppt.scheduleddatetime?.ToString())?.ToString("yyyy-MM-ddThh:mm:ss.FF");
            apptInfo.PatientAppointmentTypeName = objAppt.patientappointmenttypename;
            apptInfo.PatientAppointmentType = objAppt.patientappointmenttype;
            return apptInfo;
        }

        private static Appointment BuildFhirAppointment(AppoinementInfo objAppt)
        {
            Appointment appt = new Appointment();

            appt.Start = objAppt.StartTime;
            appt.End = objAppt.EndTime;
            appt.Status = Enum.Parse<Appointment.AppointmentStatus>(objAppt.ApptStatus);
            if(objAppt.ScheduleDateTime != null)
            appt.Created = objAppt.ScheduleDateTime;
            appt.Comment = "";
            appt.Participant = new List<Appointment.ParticipantComponent>();
            appt.Identifier = new List<Identifier>();


            appt.Participant.Add(new Appointment.ParticipantComponent
            {
                Type = new List<CodeableConcept>(){

                     new CodeableConcept
                     {
                          Coding = new List<Coding>(){
                              new Coding{
                                System = "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
                                Display = "ATND"
                              }
                          }
                     }
                    }
            });

            if (objAppt.ApptPatient != null)
            {
                appt.Participant.Add(new Appointment.ParticipantComponent
                {
                    Actor = new ResourceReference
                    {
                        Reference = string.Format("Patient/{0}", objAppt.ApptPatient?.Id),
                        Display = objAppt.ApptPatient?.Name != null && objAppt.ApptPatient?.Name.Count > 0 ? objAppt.ApptPatient?.Name[0].Text : null
                    },
                    Required = Appointment.ParticipantRequired.Required,
                    Status = ParticipationStatus.Accepted
                });
            }

            if (objAppt.ApptPractitioner != null)
            {
                appt.Participant.Add(new Appointment.ParticipantComponent
                {
                    Actor = new ResourceReference
                    {
                        Reference = string.Format("Practitioner/{0}", objAppt.ApptPractitioner?.Id),
                        Display = objAppt.ApptPractitioner?.Name != null && objAppt.ApptPractitioner?.Name.Count > 0 ? objAppt.ApptPractitioner?.Name[0].Text : null
                    },
                    Required = Appointment.ParticipantRequired.Required,
                    Status = ParticipationStatus.Accepted
                });
            }

            if (objAppt.ApptLocation != null)
            {
                appt.Participant.Add(new Appointment.ParticipantComponent
                {
                    Actor = new ResourceReference
                    {
                        Reference = string.Format("Location/{0}", objAppt.ApptLocation?.Id),
                        Display = objAppt.ApptLocation.Name
                    },
                    Required = Appointment.ParticipantRequired.Required,
                    Status = ParticipationStatus.Accepted
                });
            }


            foreach (var idt in objAppt.Ids)
            {
                appt.Identifier.Add(
                new Identifier
                {
                    System = idt.IdName,
                    Value = idt.IdValue
                }
                );
            }
            if (!string.IsNullOrEmpty(objAppt.PatientAppointmentType))
                appt.AppointmentType = new CodeableConcept
                {
                    Coding = new List<Coding>()
                   {
                       new Coding
                       {
                           System = "http://terminology.hl7.org/CodeSystem/v2-0276",
                           Code = objAppt.PatientAppointmentType,
                           Display = objAppt.PatientAppointmentTypeName
                       }
                   }
                };
            
            
            return appt;
        }

        private static Appointment SaveAppointment(AppoinementInfo apptInfo, FhirClient fhClient)
        {
            return fhClient.Create(BuildFhirAppointment(apptInfo));
        }

        private static string RetrievePatientAppointment(string patientId, string practiceId, ILogger log)
        {
            string url = string.Format("https://api.preview.platform.athenahealth.com/v1/{0}/patients/{1}/appointments", practiceId, patientId);
            RestClient client = new RestClient(url);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("accept", "application/json");
            request.AddHeader("Authorization", string.Format("Bearer {0}", TokenHandler.GetAthenaToken(log)));
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);
            return response.Content;
        }

        private static string RetrieveAppoinements(string practiceId, string athenaToken, ILogger log)
        {
            string startDate = DateTime.Now.ToShortDateString();
            string endDate = DateTime.Now.AddDays(1).ToShortDateString();

            string apptUrl = string.Format("https://api.preview.platform.athenahealth.com/v1/{0}/appointments/booked?departmentid=1&startdate={1}&enddate={2}",practiceId, startDate, endDate);

            var client = new RestClient(apptUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("accept", "application/json");
            request.AddHeader("Authorization", string.Format("Bearer {0}", athenaToken));

            IRestResponse apptResponse = client.Execute(request);
            //Console.WriteLine(apptResponse.Content);
            log?.LogInformation(apptResponse.Content);
            return apptResponse.Content;
        }

        private static string RetrieveAppoinement(string practiceId, string apptId , string athenaToken,ILogger log)
        {

            string apptUrl = string.Format("https://api.preview.platform.athenahealth.com/v1/{0}/appointments/{1}", practiceId, apptId);

            var client = new RestClient(apptUrl);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("accept", "application/json");
            request.AddHeader("Authorization", string.Format("Bearer {0}", athenaToken));

            IRestResponse apptResponse = client.Execute(request);
            log?.LogInformation(apptResponse.Content);
            return apptResponse.Content;
        }

        #endregion

        public static Appointment SaveAppointment(AppoinementInfo apptInfo)
        {
            return SaveAppointment(apptInfo, Utilities.BuildFhirClient());
        }

        public static void LookupAndSavePatientAppointment(string patientId, string practiceId, string athenaToken, ILogger log)
        {
            ProcessAppointments(RetrievePatientAppointment(patientId,practiceId,log),athenaToken,practiceId, log);
        }

        public static void ProcessAppointments(string appts, string athenaId, string practiceId, ILogger log)
        {
            dynamic objAppts = JsonConvert.DeserializeObject(appts);
            List<String> lst = new List<string>();
            foreach (var appt in objAppts.appointments)
            {
                RetrieveAndSaveAppointment(appt,athenaId,practiceId, log);
            }
            Console.Write(lst.Count);
        }

        public static Appointment RetrieveAndSaveAppointment(string practiceId,string  apptId, string athenaToken,ILogger log)
        {
            Appointment aptLookup = Utilities.LookupResource<Appointment>(apptId?.ToString());
            if(aptLookup == null)
            {
                string respAppt = RetrieveAppoinement(practiceId, apptId, athenaToken, log);
                dynamic objAppt= JsonConvert.DeserializeObject(respAppt);
                aptLookup =  RetrieveAndSaveAppointment(objAppt[0], athenaToken,  practiceId,log);
            }
            return aptLookup;
        }

        public static Appointment RetrieveAndSaveAppointment(dynamic appt, string athenaToken,string practiceId, ILogger log)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Appointment aptLookup = Utilities.LookupResource<Appointment>(appt.appointmentid?.ToString());

            try
            {
                FhirClient fhClient = Utilities.BuildFhirClient();


                ProcessorParams prms = new ProcessorParams
                {
                    PatientId = appt.patientid.ToString(),
                    PracticeId = practiceId,
                    PractitionerId = appt.providerid.ToString(),
                    AppointmentId = appt.appointmentid.ToString(),
                    LocationId = appt.departmentid.ToString(),
                    DepartmentId = appt.departmentid.ToString(),
                    AthenaToken = athenaToken,
                    FhirClientObject = fhClient,
                    FhirObjects = new FhirStore(),
                    LogggerObject = log
                };

                Console.WriteLine("Processing PatientId.. {0}", prms.PatientId);
                Console.WriteLine("Processing ProviderIdId.. {0}", prms.PractitionerId);
                Console.WriteLine("Processing AppointmentId.. {0}", prms.AppointmentId);


                prms.FhirObjects.FhirPatient = PatientProcessor.LookupOrSavePatient(ref prms, log);

                log?.LogInformation("Completed processing Patient : {0} & Provider : {1}", prms.PatientId, prms.PractitionerId);
            

                if (appt.departmentid != null)
                    prms.FhirObjects.FhirLocation = LocationProcessor.LookupOrSaveLocation(ref prms);

                log?.LogInformation("Completed processing Location : {0} ", prms.FhirObjects.FhirLocation.Id);

                Console.WriteLine("---------------------------------------------------------------");
                prms.RelaodInfoObjects();

                AppoinementInfo apptInfo = BuildAppointmentInfo(appt);

                apptInfo.ApptPatient = prms.FhirObjects.FhirPatient;
                apptInfo.ApptPractitioner = prms.FhirObjects.FhirProvider;
                apptInfo.ApptLocation = prms.FhirObjects.FhirLocation;
                prms.ApptInfo = apptInfo;

                if (aptLookup == null)
                {
                    aptLookup = SaveAppointment(apptInfo, fhClient);
                    log?.LogInformation("Completed saving Appointment : {0} ", prms.AppointmentId);
                }
                else
                {
                    log?.LogInformation("Fhir Cron Job: Didnt have to save appointment {0}  as it existed already.", prms.AppointmentId);
                }

                log?.LogInformation("Completed processing Appointment : {0} ", prms.AppointmentId);
                Console.WriteLine("---------------------------------------------------------------");
                Coverage cvrg = InsuranceProcessor.RetrieveOrSaveCoverage(ref prms);

                log?.LogInformation("Completed processing Coverage : {0} ", prms.CoverageInfo.id);

                CosmosProcessor.SaveAppointmentData(prms);

                log?.LogInformation("Completed Writing info. cosmos for appointment id : {0}", prms.AppointmentId);
                Console.WriteLine("---------------------------------------------------------------");
                Console.WriteLine("Total Time taken to process {0}", sw.Elapsed);
                Console.WriteLine("---------------------------------------------------------------");
                Console.WriteLine("---------------------------------------------------------------");

            }
            catch (Exception exc)
            {
                Console.WriteLine("An error occurred while processing..");
                Console.WriteLine(exc.ToString());
            }
            return aptLookup;
        }

        public static bool RetrieveAndSaveAppointments(string practiceId, ILogger log)
        {
            string athenaToken = TokenHandler.GetAthenaToken(log);
            ProcessAppointments( RetrieveAppoinements(practiceId, athenaToken, log), athenaToken, practiceId,log);
            return true;
        }
    }
}
