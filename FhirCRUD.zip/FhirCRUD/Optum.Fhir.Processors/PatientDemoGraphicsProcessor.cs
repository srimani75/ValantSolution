﻿using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using static Hl7.Fhir.Model.ContactPoint;

namespace FhirCronService.Processors
{
    public class PatientDemoGraphicsProcessor
    {
        /*
        //data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAADElEQVQImWNgoBMAAABpAAFEI8ARAAAAAElFTkSuQmCC
        // from Element: extension
        "contentType" : "<code>", // Mime type of the content, with charset etc.
        "language" : "<code>", // Human language of the content (BCP-47)
        "data" : "<base64Binary>", // Data inline, base64ed
        "url" : "<url>", // Uri where the data can be found
        "size" : "<unsignedInt>", // Number of bytes of content (if url provided)
        "hash" : "<base64Binary>", // Hash of the data (sha-1, base64ed)
        "title" : "<string>", // Label to display in place of the data
        "creation" : "<dateTime>" // Date attachment was first created
        */

        public static async System.Threading.Tasks.Task<Patient> SavePatientDemographics(PatientDemographics objPat, ILogger log)
        {
            FhirClient fhClient = Utilities.BuildFhirClient(log);
            Patient retPat = Utilities.LookupResource<Patient>(objPat.PatientId, fhClient);

            if (retPat != null)
            {
                log?.LogInformation("Patient found successfully...");

                retPat.Name = new List<HumanName>();
                retPat.Address = new List<Address>();
                retPat.Photo = new List<Attachment>();

                bool isChanged = false;

                if (!string.IsNullOrEmpty(objPat.Email))
                {
                    if (retPat.Telecom == null)
                        retPat.Telecom = new List<ContactPoint>();
                    else
                    {
                        retPat.Telecom.RemoveAll(x => x.System == ContactPointSystem.Email);
                    }
                    retPat.Telecom.Add(
                        new ContactPoint
                        {
                            System = ContactPointSystem.Email,
                            Value = objPat.Email,
                            Use = ContactPointUse.Home
                        });
                    isChanged = true;
                }

                if (objPat.Names != null)
                {
                    foreach (var nm in objPat.Names)
                    {
                        HumanName hmnName = new HumanName
                        {
                            Family = nm?.FamilyName,
                            Given = nm?.GivenName,
                            Text = nm?.NameText,
                            Use = Enum.Parse<HumanName.NameUse>(nm.NameUse),
                            GivenElement = new List<FhirString>()
                        };
                        foreach (string givenNm in nm?.GivenName)
                        {
                            FhirString phygn = new FhirString();
                            phygn.SetStringExtension("https://www.hl7.org/fhir/datatypes.html#HumanName", givenNm);
                            hmnName.GivenElement.Add(phygn);
                        }
                        retPat.Name.Add(hmnName);
                        isChanged = true;
                    }
                }

                if (objPat.Addresses != null)
                {
                    foreach (var addr in objPat.Addresses)
                    {
                        retPat.Address.Add(
                            new Address
                            {
                                City = addr?.City,
                                Country = addr?.Country,
                                PostalCode = addr?.PostalCode,
                                State = addr?.State,
                                Line = addr?.Lines,
                                Use = Enum.Parse<Address.AddressUse>(addr?.AddressUse),
                                Text = addr?.Lines?.FirstOrDefault()
                            }
                            );
                        isChanged = true;
                    }
                }
                
                if (!string.IsNullOrEmpty(objPat.PhotoId))
                {

                    var base64Data = Regex.Match(objPat.PhotoId, @"data:image/(?<type>.+?),(?<data>.+)").Groups["data"].Value;
                    var binData = Convert.FromBase64String(base64Data);

                    retPat.Photo.Add(
                        new Attachment
                        {
                            ContentType = "image/png",
                            Language = "en",
                            Data = binData,
                            Title = "Photo Id"
                            //Creation = DateTime.Now.ToLongDateString()
                            //ToString("yyyy-MM-dd :hh: mm :SS")
                        }
                        ); ;
                    isChanged = true;
                }
                if(isChanged)
                    return await fhClient.UpdateAsync(retPat);
            }
            else
            {
                log?.LogInformation("Could not find patient...");
            }
            return retPat;
        }
    }
}
