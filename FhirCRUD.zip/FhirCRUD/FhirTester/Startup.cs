﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs.Host.Bindings;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System.Configuration;

namespace FHIRTester
{
    //[assembly: FunctionsStartup(typeof(FHIRTokenService.Startup))]
    public class Startup 
    {
        public Configuration Configuration { get; set; }
        public  void Configure(IFunctionsHostBuilder builder)
        {
            var executioncontextoptions = builder.Services.BuildServiceProvider().GetService<IOptions<ExecutionContextOptions>>().Value;
            var currentDirectory = executioncontextoptions.AppDirectory;
            
            builder.Services.AddLogging();
            builder.Services.AddSingleton(typeof(IConfiguration), Configuration);
        }
    }
}
