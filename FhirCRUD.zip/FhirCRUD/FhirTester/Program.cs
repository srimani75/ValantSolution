﻿using System;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Logging;
using RestSharp;
using FhirCronService;
using FhirCronService.Models;
using Newtonsoft.Json;
//using Optum.Fhir.Processors;
//using Optum.Fhir.Processors.Cda;
//using FhirSave;
//using Optum.Fhir.Processors.Cda;
using Optum.Fhir.Models;
using System.Collections.Generic;
using FhirSave.Processors;

namespace FHIRTester
{

    class Program
    {
        static ILogger log;
        public static  void Main(string[] args)
        {
            //PatientProcessor.SavePatient("195900", "32001", "26", null);
            //FhirCronService.ProviderProcessor.SaveProvider(log, "195900", "1096");
            //InsuranceProcessor.RetrieveOrSaveCoverage("195900", "32001",log) ;
            //Console.WriteLine(RetrieveCDADocument(""));
            //Utilities.CleanupAllResources<Appointment>();

            //object p = ApppointmentProcessor.RetrieveAndSaveAppointment("195900", "1195956", TokenHandler.GetAthenaToken(log), log);


            //CleanupResources();

            /*Console.WriteLine("ToTal Patients... {0}", Utilities.GetResourceCount<Patient>());
            Console.WriteLine("ToTal Practitioners... {0}", Utilities.GetResourceCount<Practitioner>());
            Console.WriteLine("ToTal Appointments... {0}", Utilities.GetResourceCount<Appointment>());
            Console.WriteLine("ToTal Coverages... {0}", Utilities.GetResourceCount<Coverage>());
            Console.WriteLine("ToTal Location... {0}", Utilities.GetResourceCount<Location>());*/

            //string strCda = ClinicalDocumentProcessor.RetrieveCDADocument("7582444");
            //var token = FhirToken.GetBearerToken(log);

            //ApppointmentProcessor.RetrieveAndSaveAppointment("195900", "1197303", TokenHandler.GetAthenaToken(log), log);
            //if (objPlans?.totalcount == 0) return null;
            //1196928

            //ClinicalDocumentProcessor.RetrieveAndProcessCda("4abaf279-f9ad-4223-b60a-73216221b4cd", log);
            //var strCda = RetrieveCDADocument("");
            //Console.WriteLine(strCda);
            ProcessInsurance();
            //ProcessDemoGraphics();

        }

        public async static void ProcessInsurance()
        {
            InsuranceInfo ip = new InsuranceInfo
            {
                GroupNumber = "2020",
                FhirInsuranceId = "0b65ed59-424b-40e5-8bd5-5a8868aab666",
                InsuranceProvider = "Athena",
                MemberId = "21",
                PatientId = "8218",
                PayerId = "21",
                PolicyHolder = "LALA Lolo",
                RelationshipToIinsured = "Father",
                InsuranceCardImages = new List<Image>
                {
                    new Image
                    {
                        ImageContents = "data:image / png; base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAADElEQVQImWNgoBMAAABpAAFEI8ARAAAAAElFTkSuQmCC",
                        Title = "InsuranceCard"
                    }
                }.ToArray()
            };
            string objPlans = JsonConvert.SerializeObject(ip);
            Console.WriteLine(objPlans);
            Patient pat = await CoverageProcessor.SavePatientInsurance(ip);

        }

        public static  void ProcessDemoGraphics()
        {
            PatientDemographics data = new PatientDemographics();
            data.PatientId = "8218";
            data.Email = "test@test.com";
            //data.PhotoId = "data:image / png; base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAADElEQVQImWNgoBMAAABpAAFEI8ARAAAAAElFTkSuQmCC";
            data.PhotoIdentifiers = new List<Image>
                {
                    new Image
                    {
                        ImageContents = "data:image / png; base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAADElEQVQImWNgoBMAAABpAAFEI8ARAAAAAElFTkSuQmCC",
                        Title = "InsuranceCard"
                    }
                }.ToArray();
            data.Addresses = new List<AddressInfo>()
            {
                new AddressInfo
                {
                    AddressUse= "Home",
                     City = "test",
                      Country = "USA",
                       Lines = new System.Collections.Generic.List<string>(){"2444 199th ave NE"},
                        PostalCode = "88888",
                         State="PA"
                }
            };
            data.Names = new System.Collections.Generic.List<NameInfo>()
            {
                new NameInfo
                {
                    GivenName = new System.Collections.Generic.List<string>()
                    {
                        "Given1", "Given2","Given3"
                    },
                     FamilyName = "FamilyName",
                      NameUse = "Official"
                }
            };

            string objPlans = JsonConvert.SerializeObject(data);

            Console.WriteLine(objPlans);
            //PatientDemographics input = JsonConvert.DeserializeObject<PatientDemographics>(objPlans);
            //Patient pat = await PatientDemoGraphicsProcessor.SavePatientDemographics(input, log);
        }

        public static void CleanupResources()
        {
            Utilities.CleanupAllResources<Practitioner>();
            Utilities.CleanupAllResources<Patient>();
            Utilities.CleanupAllResources<Coverage>();
            Utilities.CleanupAllResources<Location>();
            Utilities.CleanupAllResources<Appointment>();
        }


        private static string RetrieveCDADocument(string patientId)
        {

            string cdaUrl = "https://mobilecheckin-ccd-parser.azurewebsites.net/api/GetCCD";
            var client = new RestClient(cdaUrl);
            var request = new RestRequest(Method.GET);
            string oid = "2.16.840.1.113883.3.2966.500.2.2.6.3.56.2";
            string mrn = "7582444";
            string code = "4mlat/Grg685ETqCqDfRJ6l6JCQ5/b5xKnLwg9fPgrwZFaX1Va2rkQ==";
            request.AddParameter("oid", oid);
            request.AddParameter("code", code);
            request.AddParameter("mrn", mrn);


            IRestResponse cdaResponse = client.Execute(request);

            return cdaResponse.Content;
        }

        /* private static void TestCda()
         {
             Patient pt = new Patient();

             //log.LogInformation("C# HTTP trigger function processed a request.");
             BadRequestResult badresult = new BadRequestResult();

             CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
             cancellationTokenSource.CancelAfter(8000);

             //var resource = FhirSave.Utils.ReliantUtlity.GetEnvironmentVariable("resource");
             //var resource = "https://optum-fhirserver-dev.azurehealthcareapis.com";
             var resource = "https://optum-fhirserver-nonprod.azurehealthcareapis.com";
             //"https://optum-fhirserver-dev.azurehealthcareapis.com";
             //https://optum-fhirserver-dev.azurehealthcareapis.com/Patient?RealiantPatientID=T2LOd0hOOUTAAH2YZIyRPgc5c6PhfF.o-1dQTgE7q.60B
             var bearerToken = FhirToken.GetBearerToken(log);

             var messageHandler = new HttpClientEventHandler();
             messageHandler.OnBeforeRequest += (object sender, BeforeHttpRequestEventArgs e) =>
             {
                 e.RawRequest.Headers
                 .Add("Authorization", $"Bearer {bearerToken}");
             };

             FhirClient client = new FhirClient(resource, messageHandler: messageHandler, settings: new FhirClientSettings()
             {
                 PreferredFormat = ResourceFormat.Json
             });


             //var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
             var mrn = "T2LOd0hOOUTAAH2YZIyRPgc5c6PhfF.o-1dQTgE7q.60B";
             //"7582444";// query.Get("patientID");
             //InsurancePlan

             Patient patresource = FhirSave.Utils.ReliantUtlity.GetPatient(client, resource, mrn);

             Bundle MedicationBundle = new Bundle();
             MedicationBundle.Type = Bundle.BundleType.Collection;

             /*
             < code code = "84100007" codeSystem = "2.16.840.1.113883.6.96" codeSystemName = "SNOMED CT" displayName = "history taking (procedure)" />
             < value xsi: type = "CD" code = "91936005" codeSystem = "2.16.840.1.113883.6.96" codeSystemName = "SNOMED CT" displayName = "Allergy to penicillin" />
                   CodeableConcept cc = new CodeableConcept { Text = "", }


             Coding cd = new Coding
             {
                 Code = "84100007",
                 Display = "Allergy to penicillin",
                 System = "2.16.840.1.113883.6.96"
             };
             CodeableConcept cc = new CodeableConcept
             {
                 //Coding = new System.Collections.Generic.List<Coding>().Add(new Coding { Display})

             };

             AllergyIntolerance allergy = new AllergyIntolerance
             {
                 Category = null,// AllergyIntolerance.AllergyIntoleranceCategory.Biologic,
                 ClinicalStatus = new CodeableConcept(),
                 Criticality = AllergyIntolerance.AllergyIntoleranceCriticality.High,
                 Contained = null,
                 CriticalityElement = null,
                 Encounter = new ResourceReference(),
                 Patient = new ResourceReference(mrn),
                 Note = null,//new List<Annotation>(),
                 Code = new CodeableConcept(),
                 Meta = null,
                 Reaction = null,
                 ResourceBase = null,
                 Id = "",
                 Identifier = null,
                 Onset = null


             };
             /*
              {
     "firstname": "Abcd",
     "specialty": "Child and Adolescent Psychiatry",
     "homedepartment": "Cruickshank HEALTH CARE",
     "acceptingnewpatients": true,
     "specialtyid": 670,
     "schedulingname": "1",
     "providertypeid": "MD",
     "billable": true,
     "scheduleresourcetype": "Physical Therapy",
     "ansinamecode": "Allopathic & Osteopathic Physicians : Internal Medicine (207R00000X)",
     "lastname": "711",
     "providerid": 1096,
     "supervisingproviderusername": "P1871559229",
     "supervisingproviderid": 500,
     "ansispecialtycode": "207R00000X",
     "hideinportal": false,
     "sex": "M",
     "entitytype": "Person",
     "npi": 1234567890,
     "providertype": "MD",
     "createencounteroncheckin": false
   }


             Practitioner pc = new Practitioner
             {
                 Address = null
                 //Name = nu
                 //Id = 1096,


             };

             MedicationStatement ReliantMedStatement = new MedicationStatement();
             //ReliantMedStatement.

             var bundleId = client.Create(MedicationBundle);
             patresource.Identifier.Add(new Identifier("MedicationBundle", bundleId.Id));
             var updated_pat = client.Update(patresource);
         }

         private static string RetrieveCDADocument(string patientId)
         {

             string cdaUrl = "https://mobilecheckin-ccd-parser.azurewebsites.net/api/GetCCD";
             var client = new RestClient(cdaUrl);
             var request = new RestRequest(Method.GET);
             string oid = "2.16.840.1.113883.3.2966.500.2.2.6.3.56.2";
             string mrn = "7582444";
             string code = "4mlat/Grg685ETqCqDfRJ6l6JCQ5/b5xKnLwg9fPgrwZFaX1Va2rkQ==";
             request.AddParameter("oid", oid);
             request.AddParameter("code", code);
             request.AddParameter("mrn", mrn);


             IRestResponse cdaResponse = client.Execute(request);

             return cdaResponse.Content;
         }*/
    }
}
