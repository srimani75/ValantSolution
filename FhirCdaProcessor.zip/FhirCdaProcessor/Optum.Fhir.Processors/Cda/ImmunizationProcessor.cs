﻿using FhirCdaProcessor.Models;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Optum.Fhir.Processors.Cda.Utils;
using System;
using System.Collections.Generic;

namespace Optum.Fhir.Processors.Cda
{
    public class ImmunizationProcessor
    {
        public static List<ImmunizationInfo> BuildImmunizations(dynamic objImmunizations)
        {
            List<ImmunizationInfo> objInfo = new List<ImmunizationInfo>();
            foreach (var immu in objImmunizations)
            {
                ImmunizationInfo immInfo = new ImmunizationInfo();
                var immuCode = immu.consumable?.manufacturedProduct?.manufacturedMaterial?.code?.translation;
                if (immuCode is JArray)
                    immuCode = immuCode?.First;
                
                immInfo.vaccineCode = new VaccineCode
                {
                    coding = new List<FhirCdaProcessor.Models.Coding>()
                     {
                         new FhirCdaProcessor.Models.Coding
                         {
                             code = immuCode?.code,
                             codingSystemName = immuCode?.codeSystemName,
                             display = immuCode?.displayName,
                             system = immuCode?.codeSystem
                         }
                     }
                };

                var objDose = immu?.entryRelationship?.observation;
                if (objDose != null)
                {
                    if (objDose.code?.displayName.ToString().ToLower().Contains("dose"))
                    {
                        immInfo.doseQuantity = new DoseQuantity
                        {
                            Code = objDose?.code?.code,
                            System = objDose?.code?.codeSystemName,
                            Value = objDose?.value?.value
                        };
                    }
                }
                //if(DateTime.TryParse(immu.effectiveTime.ToString(), out DateTime occurDateTime)){
                //    immInfo.occurrenceDateTime = occurDateTime.ToString("yyyy-mm-dd");
                //}
                if (DateTime.TryParseExact(immu.effectiveTime?.ToString(),
                           "yyyyMMdd",
                           System.Globalization.CultureInfo.InvariantCulture,
                           System.Globalization.DateTimeStyles.None,
                           out DateTime occurDateTime))
                {
                    immInfo.occurrenceDateTime = occurDateTime.ToString("yyyy-MM-dd");
                }
                if(immu?.entryRelationship?.observation?.statusCode?.code != null)
                {
                    immInfo.status = immu.entryRelationship.observation.statusCode.code;
                }
                    //immInfo.lotNumber = "";
                    objInfo.Add(immInfo);
            }
            return objInfo;
        }

        public static List<Immunization> BuildFhirImmunizations(List<ImmunizationInfo> immunizationInfos, string fhirPatientId)
        {
            List<Immunization> lstImmu = new List<Immunization>();
            foreach (var immInfo in immunizationInfos)
            {
                Immunization fhirImmu = new Immunization();

                if (immInfo.occurrenceDateTime != null)
                    fhirImmu.Occurrence = new FhirDateTime(immInfo.occurrenceDateTime);
                //else
                //{
                //    //donot process a record with no occurence date.
                //    continue;
                //}


                fhirImmu.Patient = new ResourceReference
                {
                    Reference = string.Format("Patient/{0}", fhirPatientId)
                };
                fhirImmu.VaccineCode = new CodeableConcept
                {
                    Coding = new List<Hl7.Fhir.Model.Coding>()
                };
                foreach (var vacc in immInfo.vaccineCode.coding)
                {
                    fhirImmu.VaccineCode.Coding.Add(
                        new Hl7.Fhir.Model.Coding
                        {
                            Code = vacc.code,
                            Display = vacc.display,
                            System = vacc.codingSystemName
                        }
                        );
                }
                if (immInfo.doseQuantity != null)
                {
                    fhirImmu.DoseQuantity = new Quantity
                    {
                        Code = immInfo.doseQuantity.Code,
                        System = immInfo.doseQuantity.System,
                        Value = immInfo.doseQuantity.Value
                    };
                }
                
                if(Enum.TryParse(immInfo.status, out Immunization.ImmunizationStatusCodes immStatus))                
                {

                        fhirImmu.Status = immStatus;
                }
                else
                {
                    fhirImmu.Status = Immunization.ImmunizationStatusCodes.Completed;
                }

                lstImmu.Add(fhirImmu);
            }

            return lstImmu;
        }

        public static Bundle SaveImmunizationsBundle(ILogger log, string patientId, dynamic sectImmu)
        {
            BundleParameters bndlPrms = CdaUtilities.BuildBundleParameters(patientId, "ImmunizationBundle", log);
            return CdaUtilities.SaveBundle(bndlPrms, BuildFhirImmunizations(BuildImmunizations(sectImmu), bndlPrms.FhirPatient?.Id));
        }

    }
}
