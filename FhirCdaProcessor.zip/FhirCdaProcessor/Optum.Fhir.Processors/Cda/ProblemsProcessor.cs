﻿using FhirCdaProcessor.Models;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Optum.Fhir.Processors.Cda.Utils;

namespace Optum.Fhir.Processors.Cda
{
    public class ProblemsProcessor
    {
        public static List<ProblemInfo> BuildProblems(dynamic  objProbs)
        {
            //dynamic objProbs = JsonConvert.DeserializeObject(txtProbs);
            List<ProblemInfo> lstProbs = new List<ProblemInfo>();
            foreach (var prob in objProbs)
            {
                ProblemInfo infoProb = new ProblemInfo();

                var objCode = prob.entryRelationship.observation.observation.value;
                if(objCode == null || objCode.displayName == null)
                {
                    if(prob.entryRelationship.observation.observation.translation.Count > 0)
                    objCode = prob.entryRelationship.observation.observation.translation.First;
                }
                if (objCode != null && objCode.displayName != null)
                {
                    infoProb.Code = new Code
                    {
                        coding = new List<Coding>()
                    {
                        new Coding
                        {
                            code = objCode.code,
                            system = objCode.codeSystem,
                            display= objCode.displayName,
                            codingSystemName = objCode.codeSystemName
                        }
                    }
                    };
                }
                var objValue = prob.entryRelationship.entryRelationship.observation.value;

                if(objValue == null)
                {
                    objValue = prob.entryRelationship.entryRelationship.observation.translation.FirstOrDefault();
                }
                
                if (objValue != null && objValue.code != null && objValue.codeSystemName != null && objValue.displayName != null &&
                    objValue.codeSystem != null)
                {
                    infoProb.clinicalStatus = new ClinicalStatus
                    {
                        Coding = new List<Coding>()
                        {
                            new Coding
                            {
                                code = objValue.code,
                                system = objValue.codeSystem,
                                display= objValue.displayName,
                                codingSystemName = objValue.codeSystemName
                            }
                        }
                    };
                }
                lstProbs.Add(infoProb);
            }
            return lstProbs;
        }

        public static List<Hl7.Fhir.Model.Condition> BuildFhirProblems(List<ProblemInfo> lstProblems, string fhirPatientId)
        {
            List<Hl7.Fhir.Model.Condition> lstProbs = new List<Hl7.Fhir.Model.Condition>();
            foreach (var prob in lstProblems)
            {
                Hl7.Fhir.Model.Condition fhirProb = new Hl7.Fhir.Model.Condition();
                fhirProb.Subject = new Hl7.Fhir.Model.ResourceReference(string.Format("Patient/{0}", fhirPatientId));
                fhirProb.Code = new Hl7.Fhir.Model.CodeableConcept();
                fhirProb.Code.Coding = new List<Hl7.Fhir.Model.Coding>();
                fhirProb.ClinicalStatus = new Hl7.Fhir.Model.CodeableConcept();
                fhirProb.ClinicalStatus.Coding = new List<Hl7.Fhir.Model.Coding>();

                foreach (var probCode in prob.Code.coding)
                {
                    fhirProb.Code.Coding.Add(
                        new Hl7.Fhir.Model.Coding
                        {
                            Code = probCode.code,
                            System = probCode.codingSystemName,
                            Display = probCode.display,
                        });
                };

                foreach (var probStat in prob.clinicalStatus.Coding)
                {
                    fhirProb.ClinicalStatus.Coding.Add(
                    new Hl7.Fhir.Model.Coding
                    {
                        Code = probStat.code,
                        System = probStat.codingSystemName,
                        Display = probStat.display
                    });
                }
                lstProbs.Add(fhirProb);
            }
            return lstProbs;
        }

        public static Hl7.Fhir.Model.Bundle SaveProblemsBundle(ILogger log, string patientId, dynamic probsSection)
        {
            BundleParameters prmBundle = CdaUtilities.BuildBundleParameters(patientId, "ProblemsBundle", log);
            return CdaUtilities.SaveBundle(prmBundle, BuildFhirProblems(BuildProblems(probsSection), prmBundle.FhirPatient?.Id));
        }
    }
}
