﻿using FhirCronService;
using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Optum.Fhir.Processors.Cda.Utils
{

    public class CdaUtilities
    {
        public static BundleParameters BuildBundleParameters(string patientId, string bundleName, ILogger log)
        {
            BundleParameters prmBundle = new BundleParameters { BundleName = bundleName, LoggerObject = log, PatientId = patientId };
            prmBundle.InitObjects();
            return prmBundle;
        }

        public static BundleParameters BuildBundleParameters(ProcessorParams prmsProcessor, string bundleName)
        {
            BundleParameters prmBundle = new BundleParameters
            {
                BundleName = bundleName,
                LoggerObject = prmsProcessor.LogggerObject,
                PatientId = prmsProcessor.PatientId,
                FhirPatient = prmsProcessor.FhirObjects.FhirPatient,
                FhirRestClient = prmsProcessor.FhirClientObject
            };
            prmBundle.InitObjects();
            return prmBundle;
        }

        public static string GetBundleId(string bundle, Patient patResponse)
        {
            return patResponse.Identifier.FirstOrDefault(a => a.System.Contains(bundle))?.Value;
        }


        public static Bundle SaveBundle<T>(BundleParameters prmBundle, List<T> lstRsrc) where T : DomainResource
        {
            
            Bundle resBndl = new Bundle();
            resBndl.Type = Bundle.BundleType.Collection;
            if (lstRsrc.Count == 0) 
                return resBndl;
                
            FhirClient fhClient = prmBundle.FhirRestClient;
            Patient fhirPat = prmBundle.FhirPatient;
            if (fhirPat != null)
            {
                var ExistingbundleId = GetBundleId(prmBundle.BundleName, fhirPat);

                if (!string.IsNullOrEmpty(ExistingbundleId))
                {
                    fhirPat.Identifier.Remove(new Identifier(prmBundle.BundleName, ExistingbundleId));
                    fhClient.Update(fhirPat);
                    fhClient.Delete("Bundle", new SearchParams().Add("id", ExistingbundleId));
                }


                foreach (var objRes in lstRsrc)
                {
                    try
                    {
                        //prmBundle.LoggerObject?.LogInformation(JsonConvert.SerializeObject(objRes));
                        Resource retAllergy = fhClient.Create(objRes);
                        resBndl.AddResourceEntry(retAllergy, string.Format("{0}/{1}", retAllergy.TypeName, retAllergy.Id));
                    }
                    catch(Exception exc)
                    {
                        prmBundle.LoggerObject?.LogError("Cannot save resource.");
                        prmBundle.LoggerObject?.LogError(exc.ToString());
                    }
                }

                
                resBndl = fhClient.Create(resBndl);
                prmBundle.LoggerObject?.LogInformation(string.Format("{0} : {1}", prmBundle.BundleName, resBndl.Id));

                fhirPat.Identifier.Add(new Identifier(prmBundle.BundleName, resBndl.Id));
                fhClient.Update(fhirPat);
            }
            return resBndl;
        }
    }
}
