﻿using FhirCronService;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;

namespace Optum.Fhir.Processors.Cda.Utils
{
    public class BundleParameters
    {
        public ILogger LoggerObject { get; set; }
        public string PatientId { get; set; }
        public string BundleName { get; set; }

        public Patient FhirPatient { get; set; }

        public FhirClient FhirRestClient { get; set; }

        public void InitObjects()
        {
            FhirRestClient = Utilities.BuildFhirClient();
            FhirPatient = Utilities.LookupResource<Patient>(PatientId, FhirRestClient);
        }
    }
}
