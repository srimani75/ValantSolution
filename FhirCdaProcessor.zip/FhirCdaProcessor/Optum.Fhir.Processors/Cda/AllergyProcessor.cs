﻿using FhirCdaProcessor.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Optum.Fhir.Processors.Cda.Utils;
using System.Collections.Generic;


namespace Optum.Fhir.Processors.Cda
{

    public class AllergyProcessor
    {
        public static List<AllergyInfo> BuildAllergies(dynamic objAllergies, ILogger log)
        {
            List<AllergyInfo> lstAllergy = new List<AllergyInfo>();
            //dynamic objAllergies = JsonConvert.DeserializeObject(txtAllergies);
            //entryRelationship.observation.observation.participant.participantRole.playingEntity.code.translation
            foreach (var allerg in objAllergies)
            {
                AllergyInfo infoAllerg = new AllergyInfo();
                infoAllerg.code = new Code();
                infoAllerg.code.coding = new List<Coding>();

                var objValue = allerg.entryRelationship?.observation?.observation?.participant?.participantRole?.playingEntity?.code?.translation;
                if (objValue == null)
                    objValue = allerg?.entryRelationship?.entryRelationship?.observationAssertion?.value?.participant?.participantRole?.playingEntity?.code?.translation;
                if (objValue != null && objValue.code != null && objValue.codeSystemName != null && objValue.displayName != null && objValue != null
                    )
                {
                    infoAllerg.code.coding.Add(new Coding
                    {
                        code = objValue.code,
                        codingSystemName = objValue.codeSystemName,
                        display = objValue.displayName,
                        system = objValue.codeSystem
                    });
                    //log?.LogInformation(JsonConvert.SerializeObject(infoAllerg));
                    lstAllergy.Add(infoAllerg);
                }
            }
            return lstAllergy;
        }

        public static List<Hl7.Fhir.Model.AllergyIntolerance> BuildFhirAllergies(List<AllergyInfo> lstData, string fhirPatientId, ILogger log)
        {
            List<Hl7.Fhir.Model.AllergyIntolerance> lstAllergies = new List<Hl7.Fhir.Model.AllergyIntolerance>();

            foreach(var allerg in lstData)
            {
                Hl7.Fhir.Model.AllergyIntolerance fhirAllerg = new Hl7.Fhir.Model.AllergyIntolerance();
                fhirAllerg.Reaction = new List<Hl7.Fhir.Model.AllergyIntolerance.ReactionComponent>();

                fhirAllerg.Reaction.Add(
                    new Hl7.Fhir.Model.AllergyIntolerance.ReactionComponent
                    {
                        Manifestation = new List<Hl7.Fhir.Model.CodeableConcept>()
                        {
                            new Hl7.Fhir.Model.CodeableConcept
                            {
                                Text = ""
                            }
                        }
                    }
                    ) ;
                fhirAllerg.Patient = new Hl7.Fhir.Model.ResourceReference
                {
                    Reference = string.Format("patient/{0}", fhirPatientId)
                };
                fhirAllerg.Code = new Hl7.Fhir.Model.CodeableConcept
                {
                    Coding = new List<Hl7.Fhir.Model.Coding>()
                };
                foreach (var allrgyCode in allerg.code.coding)
                {
                    fhirAllerg.Code.Coding.Add(new Hl7.Fhir.Model.Coding
                    {
                        Code = allrgyCode.code,
                        Display = allrgyCode.display,
                        System = allrgyCode.codingSystemName
                    });
                }
                //log?.LogInformation(JsonConvert.SerializeObject(fhirAllerg));
                lstAllergies.Add(fhirAllerg);
            }
            return lstAllergies;
        }

        public static Hl7.Fhir.Model.Bundle SaveAllergiesBundle(ILogger log, string patientId, dynamic sectAllergies)
        {
            BundleParameters bndlPrms = CdaUtilities.BuildBundleParameters(patientId, "AllergiesBundle", log);
            return CdaUtilities.SaveBundle(bndlPrms, BuildFhirAllergies(BuildAllergies(sectAllergies, bndlPrms.LoggerObject), bndlPrms.FhirPatient?.Id, bndlPrms.LoggerObject));
        }
    }
}
