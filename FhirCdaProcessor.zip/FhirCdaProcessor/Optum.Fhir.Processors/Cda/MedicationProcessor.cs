﻿using FhirCdaProcessor.Models;
using FhirCronService;
using Hl7.Fhir.Model;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Optum.Fhir.Processors.Cda.Utils;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Optum.Fhir.Processors.Cda
{
    public class MedicationProcessor
    {
        public static List<MedicationInfo> BuildMedications(dynamic objMeds)
        {
            //dynamic objMeds = JsonConvert.DeserializeObject(txtMeds);
            
            List<MedicationInfo> lstMedInfo = new List<MedicationInfo>();
            foreach (var med in objMeds)
            {
                MedicationInfo medInfo = new MedicationInfo();
                medInfo.contained = new List<Contained>();
                medInfo.status = med?.entryRelationship?.observation?.observation?.value?.displayName;

                DateTime startDt = DateTime.Now;
                DateTime endDt = DateTime.Now;
                bool hasStart = false;


                    if (med?.effectiveTime?.startDate != null)
                {

                    var start = ((JToken)med.effectiveTime?.startDate)?["value"];
                    hasStart = DateTime.TryParseExact(start?.ToString(),
                           "yyyyMMdd",
                           System.Globalization.CultureInfo.InvariantCulture,
                           System.Globalization.DateTimeStyles.None,
                            out startDt);
                }

                bool hasEnd = false;


                    if (med?.effectiveTime?.endDate != null) {
                    var end = ((JToken)med.effectiveTime?.endDate)?["value"];
                    hasEnd = DateTime.TryParseExact(end?.ToString(),
                           "yyyyMMdd",
                           System.Globalization.CultureInfo.InvariantCulture,
                           System.Globalization.DateTimeStyles.None,
                            out endDt);
                }



                if (hasStart || hasEnd)
                {
                    medInfo.effectivePeriod = new EffectivePeriod();
                    if (hasStart) medInfo.effectivePeriod.start = startDt;
                    if (hasEnd) medInfo.effectivePeriod.end = endDt;
                }

                if (int.TryParse(med?.entryRelationship?.supply?.quantity, out int quantity))
                {
                    medInfo.dosage = new DosageInfo
                    {
                        dose = new DoseInfo
                        {
                            value = quantity,
                            unit = "meq",
                            code = "meq",
                            system = "http://unitsofmeasure.org"
                        }
                    };
                }
                var objCoding = med?.consumable?.manufacturedMaterial?.code;
                if(objCoding == null)
                {
                   
                    objCoding = med.consumable?.manufacturedProduct?.manufacturedMaterial?.translation?.First;
                }
                if (objCoding?.code != null || objCoding?.display != null)
                {
                    medInfo.contained.Add(
                        new Contained
                        {
                            ingredient = new List<Ingredient>()
                             {
                             new Ingredient
                             {
                                  itemCodeableConcept = new ItemCodeableConcept
                                  {
                                       coding = new List<CodingInfo>()
                                       {
                                           new CodingInfo
                                            {
                                                 code = objCoding?.code,
                                                 display = objCoding?.displayName,
                                                 system = objCoding?.codeSystem
                                            }
                                       }
                                  }
                             }
                             }
                        }
                        );
                    medInfo.status = med.entryRelationship?.observation?.observation?.value?.displayName;
                    lstMedInfo.Add(medInfo);
                
                }
            }
            return lstMedInfo;
        }

        public static List<MedicationStatement> BuildFhirMedications(List<MedicationInfo> lstMedInfo, string fhirPatientId)
        {
            List<MedicationStatement> lstFhirMed = new List<MedicationStatement>();

            foreach (var medInfo in lstMedInfo)
            {

                MedicationStatement fhirMed = new MedicationStatement();
                fhirMed.Contained = new List<Resource>();
                fhirMed.Subject = new ResourceReference(string.Format("Patient/{0}", fhirPatientId));
                fhirMed.Dosage = new List<Dosage>();
                if (Enum.TryParse(medInfo.status, out MedicationStatement.MedicationStatusCodes statCode))
                {
                    fhirMed.Status = statCode;// medInfo.status;
                }
                var eff = new Period();
                if (medInfo.effectivePeriod != null)
                {
                    eff.Start = medInfo.effectivePeriod.start.ToString("yyyy-mm-dd");
                    eff.End = medInfo.effectivePeriod.end.ToString("yyyy-mm-dd");
                    fhirMed.Effective = eff;
                }

                if (Enum.TryParse(medInfo.status, out MedicationStatement.MedicationStatusCodes status))
                {
                    fhirMed.Status = status;
                }
                else
                {
                    fhirMed.Status = MedicationStatement.MedicationStatusCodes.Unknown;
                }

                CodingInfo info = medInfo.contained.FirstOrDefault().ingredient.FirstOrDefault().itemCodeableConcept.coding.FirstOrDefault();
                CodeableConcept ccMed = new CodeableConcept
                {
                    Coding = new List<Hl7.Fhir.Model.Coding>
                  {
                       new Hl7.Fhir.Model.Coding
                       {
                           Code = info.code,
                           Display= info.display,
                           System= info.system
                       }
                  }
                };
                fhirMed.Medication = ccMed;

                Dosage dose = new Dosage();
                Hl7.Fhir.Model.Extension extdose = new Hl7.Fhir.Model.Extension();
                
                if (medInfo.dosage?.dose != null)
                {
                    extdose.Url = medInfo.dosage.dose.system;
                    Quantity quan = new Quantity();
                    quan.Unit = medInfo.dosage.dose.unit;
                    quan.Value = medInfo.dosage.dose.value;
                    quan.Code = medInfo.dosage.dose.code;
                    quan.System = medInfo.dosage.dose.system;
                    extdose.Value = quan;
                    dose.Extension.Add(extdose);
                    //dose.Text = item.resource.dosage.FirstOrDefault().text;
                    fhirMed.Dosage.Add(dose);
                }

                lstFhirMed.Add(fhirMed);
            }
            return lstFhirMed;
        }

        public static Bundle SaveMedicationsBundle(ILogger log, string patientId, dynamic  sectMeds)
        {
            BundleParameters bndlPrms = CdaUtilities.BuildBundleParameters(patientId, "MedicationBundle", log);
            return CdaUtilities.SaveBundle(bndlPrms, BuildFhirMedications(BuildMedications(sectMeds), bndlPrms.FhirPatient?.Id));
        }
    }
}
