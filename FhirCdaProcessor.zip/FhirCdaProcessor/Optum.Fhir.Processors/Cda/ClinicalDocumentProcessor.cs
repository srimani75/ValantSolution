﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Threading.Tasks;

namespace Optum.Fhir.Processors.Cda
{
    public class ClinicalDocumentProcessor
    {
        public async static   Task RetrieveAndProcessCda(string patientId, ILogger log)
        {
            string cdaDoc = await RetrieveCDADocument(patientId, log);
             ProcessSections(patientId, cdaDoc, log);
        }

        private async static Task<string> RetrieveCDADocument(string patientId, ILogger log)
        {
            //https://mobilecheckin-ccd-parser.azurewebsites.net/api/GetCCD?oid=1.3.6.1.4.1.22812.3.8147202.3&mrn=1515757&code=4mlat/Grg685ETqCqDfRJ6l6JCQ5/b5xKnLwg9fPgrwZFaX1Va2rkQ==
            string cdaUrl = "https://mobilecheckin-ccd-parser.azurewebsites.net/api/GetCCD";
            var client = new RestClient(cdaUrl);
            var request = new RestRequest(Method.GET);
            //string oid = "1.3.6.1.4.1.22812.3.8147202.3";
            string oid = "2.16.840.1.113883.3.2966.100.1.0.341";
            //string mrn = "7582444";
            string code = "4mlat/Grg685ETqCqDfRJ6l6JCQ5/b5xKnLwg9fPgrwZFaX1Va2rkQ==";
            request.AddParameter("oid", oid);
            request.AddParameter("code", code);
            request.AddParameter("mrn", patientId);
            var cdaResponse =  client.Execute(request);
            log?.LogInformation("Successfully retrieved the CDA docuemnt.. for patient Id :{0}", patientId);
            log?.LogInformation(cdaResponse.Content);
            return cdaResponse.Content;
        }

        public  static void  ProcessSections(string patientId, string txtCda, ILogger log)
        {
            //dynamic sectionObj = cdaDoc.FirstOrDefault(i => sectionTitle == sectionName);
            dynamic cdaDoc = JsonConvert.DeserializeObject(txtCda);
            foreach (var sect in cdaDoc)
            {
                try
                {
                    Console.WriteLine(sect.title);
                    //switch (sect.title.trim())
                    {
                        if (sect.title == "Problems")
                        {
                            Console.WriteLine("Processing problems..");
                            ProblemsProcessor.SaveProblemsBundle(log, patientId, sect.problems);
                            //break;
                        }
                        if (sect.title == "Alerts, allergies and adverse reactions")
                        {
                            AllergyProcessor.SaveAllergiesBundle(log, patientId, sect.allergies);
                            //break;
                        }
                        if (sect.title == "Medications")
                        {

                            MedicationProcessor.SaveMedicationsBundle(log, patientId, sect.medications);
                            //break;
                        }
                        if (sect.title == "Immunizations")
                        {
                            ImmunizationProcessor.SaveImmunizationsBundle(log, patientId, sect.immunizations);
                            //break;
                        }
                    }
                }
                catch(Exception exc)
                {
                    string err = string.Format("An error occuirred while processing section : {0}", sect.title);
                    log?.LogError(err);
                    log?.LogError(exc.ToString());
                    Console.WriteLine(exc.ToString());
                }
            }

        }
    }
}

