﻿using FhirCronService;
using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Optum.Fhir.Processors.Cda.Utils;
using RestSharp;
using System;
using System.Collections.Generic;

namespace Optum.Fhir.Processors
{

    public class InsuranceProcessor
    {
        /*
        "insurances": [
        {
            "sequencenumber": 1,
            "insurancepolicyholderlastname": "CARTER",
            "insuranceidnumber": "123456789",
            "insurancepolicyholderdob": "04/06/1976",
            "eligibilitystatus": "Eligible",
            "insurancepolicyholderaddress1": "SUITE 319 384 SIMONIS IS",
            "ircname": "Self-Pay (cash)",
            "insuranceplanname": "*SELF PAY*",
            "insurancetype": "Personal Payment (Cash - No Insurance)",
            "relationshiptoinsuredid": 1,
            "insuranceid": "9543",
            "insurancepolicyholder": "KRAIG CARTER",
            "insurancepolicyholderfirstname": "KRAIG",
            "insurancepackageid": 0,
            "ircid": 40,
            "insurancepolicyholdercity": "LUBOWITZFURT"
        }
        ],
        "totalcount": 1
        }
        */

        /*
         "insurancepolicyholdercountrycode": "USA",
            "sequencenumber": 1,
            "insurancepolicyholderlastname": "23",
            "insuredentitytypeid": 1,
            "insuranceidnumber": "2323",
            "relationshiptoinsured": "Self",
            "eligibilitystatus": "Unverified",
            "insurancepackageaddress1": "PO BOX 182223",
            "insurancepolicyholdersex": "M",
            "eligibilityreason": "Athena",
            "ircname": "Cigna",
            "insuranceplanname": "CIGNA HEALTHCARE",
            "insurancetype": "Commercial",
            "insurancephone": "(800) 882-4462",
            "insurancepackagestate": "TN",
            "insurancepackagecity": "CHATTANOOGA",
            "relationshiptoinsuredid": 1,
            "insuranceid": "22593",
            "insurancepolicyholder": "23 23",
            "eligibilitylastchecked": "10/05/2021",
            "insurancepolicyholderfirstname": "23",
            "insurancepackageid": 74,
            "ircid": 131,
            "insurancepolicyholdercountryiso3166": "US",
            "insuranceplandisplayname": "Cigna",
            "insurancepackagezip": "37422-7223"
         */

        #region Private Methods
        private static List<CoverageInformation> BuildCoverageInfo(string coverageResponse, string patientId, FhirClient cvrgClient)
        {
            dynamic objPlans = JsonConvert.DeserializeObject(coverageResponse);
            
            //dynamic objPlan = objPlans.insurances[0];
            List<CoverageInformation> lstCoverage = new List<CoverageInformation>();
            if (objPlans?.totalcount == 0) return lstCoverage;
            foreach (var objPlan in objPlans.insurances)
            {
                CoverageInformation covInfo = new CoverageInformation();
                covInfo.Active = true;
                covInfo.InsuranceId = objPlan.insuranceidnumber;

                covInfo.PatientResourceId = Utilities.LookupResourceId<Patient>(patientId);

                if (objPlan.relationshiptoinsuredid != null)
                {
                    PatientRelationship pr = Enum.Parse<PatientRelationship>(objPlan.relationshiptoinsuredid.ToString());
                    covInfo.RelationshipToPatient = Utilities.GetDescription(pr);
                }
                if (objPlan.relationshiptoinsured != null)
                {
                    covInfo.RelationshipToPatient = objPlan.relationshiptoinsured.ToString();
                }
                covInfo.BeneficiaryId = patientId;

                covInfo.Ids = new List<IdentifierInfo>();
                if (objPlan.insuranceidnumber != null)
                    covInfo.id = objPlan.insuranceidnumber.ToString();

                if (objPlan.insuranceplanname != null && objPlan.insuranceplanname.ToString().ToLower().Contains("self"))
                {
                    covInfo.Payor = covInfo.PatientResourceId;
                    covInfo.PlanType = new CodingInfo
                    {
                        system = "http://terminology.hl7.org/CodeSystem/coverage-selfpay",
                        code = "pay",
                        display = "Pay"
                    };
                }
                else
                {
                    Organization fhirOrg = OrganizationProcessor.LookupOrSaveOrganization(objPlan, cvrgClient);
                    covInfo.Payor = string.Format("Organization/{0}", fhirOrg.Id);
                    covInfo.PlanType = new CodingInfo
                    {
                        system = "http://terminology.hl7.org/CodeSystem/v3-ActCode",
                        code = "EHCPOL",
                        display = "extended healthcare"
                    };
                }

                if (objPlan.insuranceidnumber != null)
                {
                    covInfo.Ids.Add(
                        new IdentifierInfo
                        {
                            IdName = "AthenaInsuranceIdNumber",
                            IdValue = covInfo.id
                        }
                        );
                }

                if (objPlan.insuranceid != null)
                {

                    covInfo.Ids.Add(
                        new IdentifierInfo
                        {
                            IdName = "AthenaInsuranceId",
                            IdValue = covInfo.id
                        }
                        );
                }
                covInfo.Ids.Add(
                    new IdentifierInfo
                    {
                        IdName = "AthenaMRN",
                        IdValue = patientId
                    }
                    );

                if (objPlan.insurancepackageid != null)
                    covInfo.Ids.Add(
                        new IdentifierInfo
                        {
                            IdName = "AthenaInsurancePackageId",
                            IdValue = objPlan.insurancepackageid.ToString()
                        }
                        );
                if (objPlan.payor != null)
                    covInfo.Payor = objPlan.payor;

                if (objPlan.insurancepolicyholder != null)
                    covInfo.insurancepolicyholder = objPlan.insurancepolicyholder;
                lstCoverage.Add(covInfo);
            }
            return lstCoverage;
        }
        private static List<Coverage> BuildFhirCoverage(List<CoverageInformation> lstPlans)
        {
            List<Coverage> lstCoverages = new List<Coverage>();
            foreach (var objPlan in lstPlans)
            {
                Coverage fhirPlan = new Coverage();
                fhirPlan.Identifier = new List<Identifier>();
                fhirPlan.Status = FinancialResourceStatusCodes.Active;

                foreach (var id in objPlan.Ids)
                {
                    fhirPlan.Identifier.Add(
                        new Identifier
                        {
                            System = id.IdName,
                            Value = id.IdValue,

                        }
                        );
                }
                if (objPlan.RelationshipToPatient != null)
                {
                    fhirPlan.Relationship = new CodeableConcept
                    {
                        Coding = new List<Coding>()
                     {
                        new Coding{
                            Code = objPlan.RelationshipToPatient
                        }
                     }
                    };
                }
                if (objPlan.Period != null)
                {
                    fhirPlan.Period = new Period
                    {
                        Start = objPlan.Period.Start.ToShortDateString(),
                        End = objPlan.Period.End.ToShortDateString()
                    };
                }
                if (objPlan.PlanType != null)
                {
                    fhirPlan.Type = new CodeableConcept
                    {
                        Coding = new List<Coding>()
                   {
                       new Coding
                       {
                            System = objPlan.PlanType.system,
                            Code = objPlan.PlanType.code,
                            Display = objPlan.PlanType.display
                       }
                   }
                    };
                }
                if (objPlan.Payor != null)
                {
                    fhirPlan.Payor = new List<ResourceReference>()
                {
                    new ResourceReference
                    {
                        Display = objPlan.Payor
                    }
                };
                }
                if (objPlan.insurancepolicyholder != null)
                {
                    fhirPlan.Subscriber = new ResourceReference()
                    {
                        Display = "Patient/" + objPlan.insurancepolicyholder
                    };
                }
                fhirPlan.Beneficiary = new ResourceReference()
                {
                    Display = "Patient/" + objPlan?.PatientResourceId
                };
                lstCoverages.Add(fhirPlan);
            }
            return lstCoverages;
        }

        private static string RetrieveCoverage(string practiceId, string patientId, string athenaToken, ILogger log)
        {
            //string bearer = TokenHandler.GetAthenaToken(log);
            var client = new RestClient(string.Format("https://api.preview.platform.athenahealth.com/v1/{0}/patients/{1}/insurances", practiceId, patientId));
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("accept", "application/json");
            request.AddHeader("Authorization", string.Format("Bearer {0}", athenaToken));
            IRestResponse response = client.Execute(request);

            //Console.WriteLine(response.Content);
            return response.Content;
        }

        #endregion Private Methods

        public static Bundle SaveCoverage(List<CoverageInformation> cvrgInfo, ProcessorParams prmsProcessor)
        {
            prmsProcessor.LogggerObject?.LogInformation("Saving Coverage ...");
            List<Coverage> lstPlans = BuildFhirCoverage(cvrgInfo);
            var bndlPrms = CdaUtilities.BuildBundleParameters(prmsProcessor, "CoverageBundle");
            return CdaUtilities.SaveBundle<Coverage>(bndlPrms, lstPlans);
        }

        public static List<CoverageInformation> RetrieveAndBuildCoverage(string practiceId, string patientId, string athenaToken, ILogger log, FhirClient fhClient)
        {
            return BuildCoverageInfo(RetrieveCoverage(practiceId, patientId, athenaToken, log), patientId, fhClient);
        }
        public static Bundle RetrieveOrSaveCoverage(ref ProcessorParams input)
        {
            input.CoverageInfo = RetrieveAndBuildCoverage(input.PracticeId, input.PatientId, input.AthenaToken, input.LogggerObject, input.FhirClientObject);
            return SaveCoverage(input.CoverageInfo, input);

            /*Coverage retCvrg = Utilities.LookupResource<Coverage>(input.CoverageInfo.InsuranceId, input.FhirClientObject);
            ILogger log = input.LogggerObject;
            if (retCvrg == null)
            {
                retCvrg = SaveCoverage(input.CoverageInfo, input.FhirClientObject, input.LogggerObject);
                
                input.CoverageInfo.ForEach(i => log?.LogInformation("Successfully saved Coverage {0}.", i.InsuranceId));
                //input.LogggerObject?.LogInformation("Successfully saved Coverage {0}.", input.CoverageInfo);
            }
            else
            {
                //input.LogggerObject?.LogInformation("Didint save Coverage {0}  as it existed already.", input.CoverageInfo.InsuranceId);
                input.CoverageInfo.ForEach(i => log?.LogInformation("Successfully saved Coverage {0}.", i.InsuranceId));
            }
            return retCvrg;*/
        }
    }
}
