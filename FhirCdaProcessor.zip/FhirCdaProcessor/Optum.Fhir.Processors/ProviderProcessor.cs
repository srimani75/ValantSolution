﻿using FhirCronService;
using FhirCronService.Models;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;

namespace Optum.Fhir.Processors
{
    public class ProviderProcessor
    {
        #region Private methods...
        private static PractitionerInformation BuildPractitioner(string respPrac)
        {

            dynamic objPracs = JsonConvert.DeserializeObject(respPrac);
            dynamic objPrac = objPracs[0];
            PractitionerInformation pInfo = new PractitionerInformation
            {
                id = objPrac.providerid.ToString(),
                name = new List<NameInfo>()
                {
                    new NameInfo
                    {
                        FamilyName = objPrac.lastname,
                        GivenName = new List<string>(){ objPrac.firstname?.ToString() },
                        NameUse = HumanName.NameUse.Official.ToString()
                    }
                },
                address = new List<AddressInfo>(),
                gender = Utilities.GetGender(objPrac.sex?.ToString()),
                Ids = new List<IdentifierInfo>()
                {
                    new IdentifierInfo
                    {
                        IdName = "AthenaProviderId",
                        IdValue = objPrac.providerid.ToString()
                    }
                },
                active = true
            };
            return pInfo;
        }

        private static Practitioner BuildFhirPractitioner(PractitionerInformation objPrac)
        {
            Practitioner prac = new Practitioner();
            prac.Active = objPrac.active;
            prac.Name = new List<HumanName>();
            prac.Identifier = new List<Identifier>();

            if (objPrac.name != null)
            {
                foreach (var objName in objPrac.name)
                {
                    prac.Name.Add(

                        new HumanName
                        {
                            Family = objName.FamilyName,
                            Given = objName.GivenName,

                            Use = Enum.Parse<HumanName.NameUse>(objName.NameUse)
                        }
                        );
                }
            }
            prac.Gender = Enum.Parse<AdministrativeGender>(objPrac.gender);

            if (objPrac.birthDate != null)
                prac.BirthDate = objPrac.birthDate;
            foreach (var id in objPrac.Ids)
            {
                prac.Identifier.Add(
                    new Identifier
                    {
                        System = id.IdName,
                        Value = id.IdValue
                    }
                    );
            }
            return prac;
        }

        private static string RetrievePractitioner(ILogger log, string practiceId, string practitionerId, string athenaToken)
        {
            //string bearer = TokenHandler.GetAthenaToken(log);
            var client = new RestClient(string.Format("https://api.preview.platform.athenahealth.com/v1/{0}/providers/{1}", practiceId, practitionerId));
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("accept", "application/json");
            request.AddHeader("Authorization", string.Format("Bearer {0}", athenaToken));
            IRestResponse response = client.Execute(request);
            //Console.WriteLine(response.Content);
            return response.Content;
        }

        #endregion

        public static Practitioner SavePractitioner(PractitionerInformation pracInfo, ILogger log)
        {
            return SavePractitioner(pracInfo, Utilities.BuildFhirClient(), log);
        }
        public static Practitioner SavePractitioner(PractitionerInformation pracInfo, FhirClient fhClient, ILogger log)
        {
            return fhClient.Create(BuildFhirPractitioner(pracInfo));
        }

        public static PractitionerInformation RetrieveAndBuildPractitioner(ILogger log, string practiceId, string practitionerId, string athenaToken)
        {
            return BuildPractitioner(RetrievePractitioner(log, practiceId, practitionerId, athenaToken));
        }
        public static Practitioner LookupOrSavePractitioner(ILogger log, ref ProcessorParams input)
        {
            Practitioner retPrac = Utilities.LookupResource<Practitioner>(input.PractitionerId, input.FhirClientObject);
            if (retPrac == null)
            {
                PractitionerInformation pracInfo = RetrieveAndBuildPractitioner(log, input.PracticeId, input.PractitionerId, input.AthenaToken);
                Practitioner pracObj = BuildFhirPractitioner(pracInfo);
                input.ProviderInfo = pracInfo;
                retPrac = input.FhirClientObject.Create(pracObj);
                input.LogggerObject?.LogInformation("Successfully saved Practitioner : {0}.", input.PractitionerId);
            }
            else
            {
                input.LogggerObject?.LogInformation("Didnt save Practitioner : {0} as the reource existed already.", input.PractitionerId);
            }
            return retPrac;
        }

        //public static Practitioner LookupOrSavePractitioner(ILogger log, string practiceId, string practitionerId, string athenaToken)
        //{
        //    Practitioner retPrac = Utilities.LookupResource<Practitioner>(practitionerId);

        //    if (retPrac == null)
        //    {
        //        PractitionerInformation pracInfo = RetrieveAndBuildPractitioner(log, practiceId, practitionerId,athenaToken);
        //        Practitioner pracObj = BuildFhirPractitioner(pracInfo);
        //        FhirClient fhClient = Utilities.BuildFhirClient();

        //        retPrac = fhClient.Create(pracObj);
        //    }
        //    return retPrac;
        //}
    }
}
