﻿using FhirCronService;
using FhirCronService.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Optum.Fhir.Processors
{
    public class CosmosProcessor
    {
        public class SMS_Event
        {
            public string event_type { get; set; }
            public int time { get; set; }
            public bool success { get; set; }
            public string response { get; set; }
            public int response_time { get; set; }
        }
        public class CosmosApptInfo
        {
            public CosmosApptInfo()
            {
                resend = false;
                confirmation = false;
                pre_reg = false;

                //SMS Related Info.
                sms_count = 0;
                sms_type = null;
                sms_delivered_time = 0;
                sms_delivered = false;
                sms_response = null;
                sms_response_time = 0;
                sms_events = new SMS_Event[0];
                //create_datetime = 0;
            }

            //Appointment Information..
            public string appt_id { get; set; }
            public string appt_date { get; set; }
            public string appt_time { get; set; }
            public string reminder_time { get; set; }

            //Patient Information..
            public string patient_id { get; set; }
            public string first_name { get; set; }
            public string mobile_phone { get; set; }
            public string home_phone_no { get; set; }
            public bool consenttotext { get; set; }
            public string provider_name { get; set; }

            //Hospital Information......
            public string dept_name { get; set; }
            public string dept_phone { get; set; }
            public string dept_address { get; set; }

            //SMS related
            public bool resend { get; set; }
            public bool confirmation { get; set; }
            public bool pre_reg { get; set; }

            //SMS Related Info.
            public int sms_count { get; set; }
            string sms_type { get; set; }
            public int sms_delivered_time { get; set; }
            public bool sms_delivered { get; set; }
            public string sms_response { get; set; }
            public int sms_response_time { get; set; }
            public SMS_Event[] sms_events { get; set; }
            public int create_datetime { get; set; }

            public string id { get; set; }
            public string _rid { get; set; }
            public string _self { get; set; }
            public string _etag { get; set; }
            public string _attachments { get; set; }
            public int _ts { get; set; }
        }

        public static string GetName(List<NameInfo> lst)
        {
            if (lst != null && lst.Count > 0)
            {
                NameInfo info = lst[0];
                StringBuilder bldr = new StringBuilder();
                if (info.FamilyName != null)
                {
                    bldr.AppendFormat("{0}, ", info.FamilyName);
                }
                if (info.GivenName != null && info.GivenName.Count > 0)
                    bldr.Append(info.GivenName[0]);
                return bldr.ToString();

            }
            return null;
        }
        public static CosmosApptInfo BuildApptInfo(AppoinementInfo apptInfo, PatientInformation patInfo, PractitionerInformation pracInfo, LocationInfo locInfo)
        {
            CosmosApptInfo objCosmos = new CosmosApptInfo();
            objCosmos.appt_id = apptInfo.AppointmentId;
            objCosmos.appt_date = apptInfo.StartTime.ToShortDateString();
            objCosmos.appt_time = apptInfo.StartTime.ToString("hh:mm:ss");
            objCosmos.create_datetime = 0;// DateTime.Now.ToFileTimeUtc();

            objCosmos.patient_id = patInfo.id;
            objCosmos.first_name = GetName(patInfo.name);
            objCosmos.mobile_phone = patInfo.telecom.FirstOrDefault(a => a.use == "Work" && a.system == "Phone")?.value;
            objCosmos.home_phone_no = patInfo.telecom.FirstOrDefault(a => a.use == "Home" && a.system == "Phone")?.value;
            objCosmos.consenttotext = patInfo.ConsentToText;
            objCosmos.provider_name = GetName(pracInfo.name);

            objCosmos.dept_name = locInfo.Name;
            objCosmos.dept_phone = locInfo.ContactInfo.FirstOrDefault(a => a.use == "Work" && a.system == "Phone")?.value;// locInfo.ContactInfo[0].value;
            objCosmos.dept_address = locInfo.LocationAddress.ToString();

            objCosmos.id = Guid.NewGuid().ToString();

            return objCosmos;
        }


        public static CosmosApptInfo SaveAppointmentData(ProcessorParams input)
        {
            string EndpointURI = "https://mobile-checkin-cosmosdb.documents.azure.com:443/"; //Utilities.GetEnvironmentVariable("CosmosDBEndpoint");
            string PrimaryKey = "FDCds5bSLxAa1UOk0AhTJaZDljZHgirP2ft3OXVwl7MNyDFkvGVlP8BkkjDnVHSzu4vQX0ZkOB2Ey4lsydwLgw==";
            //Utilities.GetEnvironmentVariable("CosmosDBKey"); 
            string DatabaseId = "mobile-checkin-db";// Utilities.GetEnvironmentVariable("ApptDatabase"); //"mobile-checkin-db"
            string ContainerId = "appt_data";// Utilities.GetEnvironmentVariable("ApptContainer"); //appointment_data



            CosmosApptInfo objCosmos = BuildApptInfo(input.ApptInfo, input.PatientInfo, input.ProviderInfo, input.LocInfo);
            //string objPracs = JsonConvert.SerializeObject(value: objCosmos);

            var ccOptions = new CosmosClientOptions() { ConnectionMode = ConnectionMode.Gateway };
            var cosmosClient = new CosmosClient(EndpointURI, PrimaryKey, ccOptions);
            var container = cosmosClient.GetContainer(DatabaseId, ContainerId);


            //objCosmos.appt_id = "25000";
            //objCosmos.id = Guid.NewGuid().ToString();
            //TODO: Add config Settings, UpsertItem, Populate CreateDateTime
            Task<ItemResponse<CosmosApptInfo>> ret = container.UpsertItemAsync(objCosmos);
            input.LogggerObject?.LogInformation("Successfully saved Appointment details to Cosmos .");
            input.LogggerObject?.LogInformation(JsonConvert.SerializeObject(value: objCosmos));
            return ret.Result;


        }

    }
}
