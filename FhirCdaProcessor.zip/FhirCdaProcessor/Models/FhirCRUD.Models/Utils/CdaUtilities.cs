﻿using FhirCronService;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace FhirCdaProcessor
{
    public class BundlePrms
    {
        public ILogger LoggerObject { get; set; }
        public string PatientId { get; set; }
        public string BundleName { get; set; }

        public Patient FhirPatient { get; set; }

        public FhirClient FhirRestClient { get; set; }

        public void InitObjects()
        {
            FhirRestClient = Utilities.BuildFhirClient();
            FhirPatient = Utilities.LookupResource<Patient>(PatientId, FhirRestClient);
        }
    }
    
    public class CDAUtilities
    {
        public static BundlePrms BuildBundleParameters(string patientId, string bundleName, ILogger log)
        {
            BundlePrms prmBundle = new BundlePrms { BundleName = bundleName, LoggerObject = log, PatientId = patientId };
            prmBundle.InitObjects();
            return prmBundle;
        }
        public static Bundle SaveBundle<T>(BundlePrms prmBundle, List<T> lstRsrc) where T:DomainResource
        {
            Bundle resBndl = new Bundle();
            FhirClient fhClient = prmBundle.FhirRestClient;
            Patient fhirPat = prmBundle.FhirPatient;
            if (fhirPat != null)
            {
                var ExistingbundleId = Utilities.GetBundleId(prmBundle.BundleName, fhirPat);

                if (!string.IsNullOrEmpty(ExistingbundleId))
                {
                    fhirPat.Identifier.Remove(new Identifier(prmBundle.BundleName, ExistingbundleId));
                    fhClient.Update(fhirPat);
                    fhClient.Delete("Bundle", new SearchParams().Add("id", ExistingbundleId));
                }


                foreach (var objRes in lstRsrc)
                {
                    Resource retAllergy = fhClient.Create(objRes);
                    resBndl.AddResourceEntry(retAllergy, string.Format("{0}/{1}",retAllergy.TypeName , retAllergy.Id));
                }

                resBndl = fhClient.Create(resBndl);
                prmBundle.LoggerObject.LogInformation(string.Format("{0} : {1}", prmBundle.BundleName, resBndl.Id));

                fhirPat.Identifier.Add(new Identifier(prmBundle.BundleName, resBndl.Id));
                fhClient.Update(fhirPat);
            }
            return resBndl;
        }
    }
}
