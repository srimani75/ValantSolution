﻿using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 

    public class VaccineCode
    {
        public List<Coding> coding { get; set; }
        public string text { get; set; }
    }

    //public class Patient
    //{
    //    public string reference { get; set; }
    //}

    public class Encounter
    {
        public string Reference { get; set; }
    }

    public class Location
    {
        public string Reference { get; set; }
    }

    public class Manufacturer
    {
        public string Reference { get; set; }
    }

    //public class Site
    //{
    //    public List<Coding> Coding { get; set; }
    //}


    public class DoseQuantity
    {
        public int Value { get; set; }
        public string System { get; set; }
        public string Code { get; set; }
    }

    //public class Function
    //{
    //    public List<Coding> Coding { get; set; }
    //}

    //public class Actor
    //{
    //    public string Reference { get; set; }
    //}

    public class Performer
    {
        public Function Function { get; set; }
        public Actor Actor { get; set; }
    }

    public class Education
    {
        public string DocumentType { get; set; }
        public string PublicationDate { get; set; }
        public string PresentationDate { get; set; }
    }

    public class ProgramEligibility
    {
        public List<Coding> Coding { get; set; }
    }

    public class FundingSource
    {
        public List<Coding> Coding { get; set; }
    }

    public class ImmunizationInfo
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Text text { get; set; }
        public List<IdentifierInfo> identifier { get; set; }
        public string status { get; set; }
        public VaccineCode vaccineCode { get; set; }
        public PatientRef patient { get; set; }
        public Encounter encounter { get; set; }
        public string occurrenceDateTime { get; set; }
        public bool primarySource { get; set; }
        public Location location { get; set; }
        public Manufacturer manufacturer { get; set; }
        public string lotNumber { get; set; }
        public string expirationDate { get; set; }
        public Site site { get; set; }
        public Route route { get; set; }
        public DoseQuantity doseQuantity { get; set; }
        public List<Performer> performer { get; set; }
        public List<Note> note { get; set; }
        public List<ReasonCode> reasonCode { get; set; }
        public bool isSubpotent { get; set; }
        public List<Education> education { get; set; }
        public List<ProgramEligibility> programEligibility { get; set; }
        public FundingSource fundingSource { get; set; }
    }
}
