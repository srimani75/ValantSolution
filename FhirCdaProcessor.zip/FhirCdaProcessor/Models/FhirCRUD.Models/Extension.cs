﻿namespace FhirCronService
{
    public class Extension
    {
        public string url { get; set; }
        public ValueCodeableConcept valueCodeableConcept { get; set; }
    }
}
