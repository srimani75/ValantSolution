﻿using Hl7.Fhir.Model;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace FhirCronService.Models
{
    public class PatientDemographics
    {
        [JsonProperty("patientId")]
        public string PatientId { get; set; }

        [JsonProperty("fhitPatientId")]
        public string FhirPatientId { get; set; }
        [JsonProperty("name")]
        public List<NameInfo> Names { get; set; }
        [JsonProperty("address")]
        public List<AddressInfo> Addresses { get; set; }

        [JsonProperty("photoId")]
        public string PhotoId { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }
    }

    
}
