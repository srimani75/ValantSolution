﻿using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{

    public class ClinicalStatus
    {
        public List<Coding> Coding { get; set; }
    }

    public class VerificationStatus
    {
        public List<Coding> Coding { get; set; }
    }

    public class Severity
    {
        public List<Coding> Coding { get; set; }
    }


    public class BodySite
    {
        public List<Coding> Coding { get; set; }
        public string Text { get; set; }
    }

    public class ProblemInfo
    {
        public string ResourceType { get; set; }
        public string Id { get; set; }
        public Text Text { get; set; }
        public ClinicalStatus clinicalStatus { get; set; }
        public VerificationStatus VerificationStatus { get; set; }
        public List<Category> Category { get; set; }
        public Severity Severity { get; set; }
        public Code Code { get; set; }
        public List<BodySite> BodySite { get; set; }
        public Subject Subject { get; set; }
        public string OnsetDateTime { get; set; }
    }

}
