﻿using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{
    public class Function
    {
        public List<Coding> coding { get; set; }
    }
}
