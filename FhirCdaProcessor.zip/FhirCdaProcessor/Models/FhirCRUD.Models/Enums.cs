﻿using System.ComponentModel;

namespace FhirCronService
{
        public enum PatientRelationship
        {
          
            [Description("Self")]
            Self = 1,
            [Description("Spouse")]
            Spouse = 2,
            [Description("Child")]
            Child = 3,
            [Description("Other")]
            Other = 4,
            [Description("Grandparent")]
            Grandparent = 5,
            [Description("Grandchild")]
            Grandchild = 6,
            [Description("Nephew or Niece")]
            NepheworNiece = 7,
            [Description("Foster Child")]
            FosterChild = 9,
            [Description("Ward")]
            Ward = 10,
            [Description("Stepson or Stepdaughter")]
            StepsonorStepdaughter = 11,
            [Description("Employee")]
            Employee = 12,
            [Description("Unknown")]
            Unknown = 13,
            [Description("Handicapped Dependent")]
            HandicappedDependent = 14,
            [Description("Sponsored Dependent")]
            SponsoredDependent = 15,
            [Description("Dependent of a Minor Dependent")]
            DependentofMinor = 16,
            [Description("Significant Other")]
            SignificantOther = 17,
            [Description("Mother")]
            Mother = 18,
            [Description("Father")]
            Father = 19,
            [Description("Emancipated Minor")]
            EmancipatedMinor = 21,
            [Description("Organ Donor")]
            OrganDonor = 22,
            [Description("Cadaver Donor")]
            CadaverDonor = 23,
            [Description("Injured Plaintiff")]
            InjuredPlaintiff = 24,
            [Description("Child (Ins. not Financially Respons.)")]
            ChildInsnot = 25,
            [Description("Life Partner")]
            LifePartner = 26,
            [Description("Child (Mother's Insurance)")]
            ChildMothersInsurance	=27,
            [Description("Child (Father's Insurance)")]
            ChildFathersInsurance	=28,
            [Description("Child (of Mother, Ins. not Financially Respons.)")]
            ChildMother = 29,
            [Description("Child (of Father, Ins. not Financially Respons.)")]
            ChildofFather = 30,
            [Description("Stepson or Stepdaughter (Stepmother's Insurance)")]
            StepmothersInsurance = 31,
            [Description("Stepson or Stepdaughter (Stepfather's Insurance)")]
            StepfathersInsurance = 32

        }
        
}
