﻿namespace FhirCdaProcessor.Models
{
    public class Location
    {
        public string reference { get; set; }
    }
}
