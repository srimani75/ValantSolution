﻿namespace FhirCdaProcessor.Models
{
    public class Actor
    {
        public string reference { get; set; }
    }
}
