﻿using System.Collections.Generic;

namespace FhirCronService
{
    public class CoverageInformation
    {
        public string id { get; set; }
        public string InsuranceId { get; set; }
        //public List<Extension> extension { get; set; }
        public bool Active { get; set; }
        public CoveragePeriod Period { get; set; }
        public string Payor { get; set; }

        public List<CodingInfo> PlanInfo { get; set; }

        public CodingInfo PlanType { get; set; }

        public List<IdentifierInfo> Ids { get; set; }
        public string RelationshipToPatient { get; set; }
        public string insurancepolicyholder { get; set; }

        public string BeneficiaryId { get; set; }
        public bool Status { get; set; }

        public string PatientResourceId { get; set; }

    }
}
