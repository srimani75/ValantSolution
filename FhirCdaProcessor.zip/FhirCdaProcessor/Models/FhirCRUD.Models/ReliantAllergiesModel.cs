﻿using System;
using System.Collections.Generic;
using System.Text;
namespace FhirSave.Models
{
    public class ReliantAllergiesModel
    {
        public class Link
        {
            public string relation { get; set; }
            public string url { get; set; }
        }

        public class Coding
        {
            public string system { get; set; }
            public string version { get; set; }
            public string code { get; set; }
            public string display { get; set; }
        }

        public class ClinicalStatus
        {
            public List<Coding> coding { get; set; }
        }

        public class VerificationStatus
        {
            public List<Coding> coding { get; set; }
        }

        public class Code
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Patient
        {
            public string reference { get; set; }
            public string display { get; set; }
        }

        public class Manifestation
        {
            public string text { get; set; }
        }

        public class Reaction
        {
            public List<Manifestation> manifestation { get; set; }
            public string description { get; set; }
            public string severity { get; set; }
        }

        public class Details
        {
            public List<Coding> coding { get; set; }
            public string text { get; set; }
        }

        public class Issue
        {
            public string severity { get; set; }
            public string code { get; set; }
            public Details details { get; set; }
        }

        public class Resource
        {
            public string resourceType { get; set; }
            public string id { get; set; }
            public ClinicalStatus clinicalStatus { get; set; }
            public VerificationStatus verificationStatus { get; set; }
            public List<string> category { get; set; }
            public Code code { get; set; }
            public Patient patient { get; set; }
            public string recordedDate { get; set; }
            public List<Reaction> reaction { get; set; }
            public List<Issue> issue { get; set; }
        }

        public class Search
        {
            public string mode { get; set; }
        }

        public class Entry
        {
            public List<Link> link { get; set; }
            public string fullUrl { get; set; }
            public Resource resource { get; set; }
            public Search search { get; set; }
        }

        public class ReliantAllergies
        {
            public string resourceType { get; set; }
            public string type { get; set; }
            public int total { get; set; }
            public List<Link> link { get; set; }
            public List<Entry> entry { get; set; }
        }


    }
}
