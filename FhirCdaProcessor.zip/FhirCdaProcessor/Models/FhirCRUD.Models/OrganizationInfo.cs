﻿using System.Collections.Generic;

namespace FhirCronService.Models
{
    public class OrganizationInfo
    {
        public List<IdentifierInfo> Ids { get; set; }
        public bool IsActive { get; set; }
        public List<CodingInfo> OrgType { get; set; }
        public string Name { get; set; }
        public List<string> Alias { get; set; }
        public List<TelecomInfo> ContactInfo { get; set; }
        public List<AddressInfo> Addresses { get; set; }
        //"partOf" : { Reference(Organization) }, // The organization of which this organization forms a part
        //"contact" : [{ // Contact for the organization for a certain purpose
        //  "purpose" : { CodeableConcept }, // The type of contact
        //  "name" : { HumanName }, // A name associated with the contact
        //  "telecom" : [{ ContactPoint }], // Contact details (telephone, email, etc.)  for a contact
        //  "address" : { Address } // Visiting or postal addresses for the contact
        //}],
        //"endpoint" : [{ Reference(Endpoint) }] // Technical endpoints providing access to services operated for the organization
        //  }
    }
}
