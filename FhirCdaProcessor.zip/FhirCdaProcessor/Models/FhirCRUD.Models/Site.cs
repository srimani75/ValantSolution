﻿using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{
    public class Site
    {
        public List<Coding> coding { get; set; }
    }
}
