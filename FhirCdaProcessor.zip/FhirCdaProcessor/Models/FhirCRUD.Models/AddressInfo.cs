﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text;

namespace FhirCronService
{
    public class AddressInfo
    {
        [JsonProperty("use")]
        public string AddressUse { get; set; }
        [JsonProperty("line")]
        public List<string> Lines { get; set; }
        [JsonProperty("city")]
        public string City { get; set; }
        [JsonProperty("state")]
        public string State { get; set; }
        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }
        [JsonProperty("country")]
        public string Country { get; set; }

        public override string ToString()
        {
            StringBuilder bldrAddress = new StringBuilder();
            if (Lines != null)
                foreach (string lin in Lines)
                {
                    if (!string.IsNullOrEmpty(lin))
                        bldrAddress.Append(lin);
                }
            if (!string.IsNullOrEmpty(City))
                bldrAddress.AppendFormat("{0}", City);
            if (!string.IsNullOrEmpty(State))
                bldrAddress.AppendFormat(",{0}", State);
            if (!string.IsNullOrEmpty(PostalCode))
                bldrAddress.AppendFormat(",{0}", PostalCode);
            if (!string.IsNullOrEmpty(Country))
                bldrAddress.AppendFormat(",{0}", Country);
            return bldrAddress.ToString();
        }
    }
}
