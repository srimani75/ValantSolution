﻿using System.Collections.Generic;

namespace FhirCronService
{
    public class PractitionerInformation
    {

        //public string resourceType { get; set; }
        
        public string id { get; set; }
        //public List<Extension> extension { get; set; }
        public bool active { get; set; }
        public List<NameInfo> name { get; set; }
        public List<TelecomInfo> telecom { get; set; }
        public string gender { get; set; }
        public string birthDate { get; set; }
        public List<AddressInfo> address { get; set; }
        public List<IdentifierInfo> Ids { get; set; }
    }
}
