﻿namespace FhirCronService
{
    public class IdentifierInfo
    {
        public string IdName { get; set; }
        public string IdValue { get; set; }
    }
}
