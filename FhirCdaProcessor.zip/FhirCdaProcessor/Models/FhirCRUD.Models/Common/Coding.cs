﻿namespace FhirCdaProcessor.Models
{
    public class Coding
    {
        public string system { get; set; }
        public string code { get; set; }
        public string display { get; set; }

        public string codingSystemName { get; set; }
    }

}
