﻿using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{
    public class Code
    {
        public List<Coding> coding { get; set; }
    }
}
