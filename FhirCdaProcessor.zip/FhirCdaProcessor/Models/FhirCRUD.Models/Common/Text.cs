﻿namespace FhirCdaProcessor.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Text
    {
        public string status { get; set; }
        public string div { get; set; }
    }

}
