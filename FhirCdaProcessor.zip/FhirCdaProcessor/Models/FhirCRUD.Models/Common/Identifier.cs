﻿namespace FhirCdaProcessor.Models
{   public class IdentifierInfo
    {
        public string use { get; set; }
        public string system { get; set; }
        public string value { get; set; }
    }
}
