﻿using System.Collections.Generic;

namespace FhirCronService
{
    public class Details
    {
        public List<CodingInfo> coding { get; set; }
        public string text { get; set; }
    }
}
