﻿using System;
using System.Collections.Generic;

namespace FhirCdaProcessor.Models
{
    //public class Identifier
    //{
    //    public string system { get; set; }
    //    public string value { get; set; }
    //}

    public class PatientRef
    {
        public string reference { get; set; }
    }

    public class Recorder
    {
        public string reference { get; set; }
    }

    public class Asserter
    {
        public string reference { get; set; }
    }

    //public class Note
    //{
    //    public string text { get; set; }
    //}

    public class Substance
    {
        public List<Coding> coding { get; set; }
    }

    public class Manifestation
    {
        public List<Coding> coding { get; set; }
    }

    public class ExposureRoute
    {
        public List<Coding> coding { get; set; }
    }

    public class Reaction
    {
        public Substance substance { get; set; }
        public List<Manifestation> manifestation { get; set; }
        public string description { get; set; }
        public string onset { get; set; }
        public string severity { get; set; }
        public ExposureRoute exposureRoute { get; set; }
        public List<Note> note { get; set; }
    }

    public class AllergyInfo
    {
        public string resourceType { get; set; }
        public string id { get; set; }
        public Text text { get; set; }
        public List<IdentifierInfo> identifier { get; set; }
        public ClinicalStatus clinicalStatus { get; set; }
        public VerificationStatus verificationStatus { get; set; }
        public string type { get; set; }
        public List<string> category { get; set; }
        public string criticality { get; set; }
        public Code code { get; set; }
        public PatientRef patient { get; set; }
        public string onsetDateTime { get; set; }
        public DateTime recordedDate { get; set; }
        public Recorder recorder { get; set; }
        public Asserter asserter { get; set; }
        public string lastOccurrence { get; set; }
        public List<Note> note { get; set; }
        public List<Reaction> reaction { get; set; }
    }

}
