﻿using System;

namespace FhirCRUD.Models
{
    public class Class1
    {
    }
}
