using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Optum.Fhir.Processors.Cda;

namespace CdaProcessor
{
    public static class CdaProcessor
    {
        [FunctionName("FhirCdaProcessor")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log?.LogInformation($"CdaProcessor Http trigger function started execution at: {DateTime.Now}");
            
            var query = System.Web.HttpUtility.ParseQueryString(req.QueryString.Value);
            var patientId = query.Get("patientID"); 
            await ClinicalDocumentProcessor.RetrieveAndProcessCda(patientId, log);
            
            log?.LogInformation($"CdaProcessor Http trigger function finished execution at: {DateTime.Now}");

            return new OkObjectResult(string.Format("Successfully processed patientId: {0}", patientId));
        }
    }
}
