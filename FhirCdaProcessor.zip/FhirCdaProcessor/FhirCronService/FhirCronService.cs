using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Optum.Fhir.Processors;
using System;

namespace FhirCronService
{
    public static class FhirCronService
    {
        [FunctionName("FhirCronService")]
        public static void Run([TimerTrigger("0 */15 * * * *", RunOnStartup = true, UseMonitor = true)] TimerInfo myTimer, ILogger log)
        {
            //"0 */5 * * * *"
            //"0 10 0 * * *"

            log?.LogInformation($"FhirCronService Timer trigger function started execution at: {DateTime.Now}");
            string strPracticeId = "195900";
            ApppointmentProcessor.RetrieveAndSaveAppointments(strPracticeId, log);
            log?.LogInformation($"FhirCronService Timer trigger function finished execution at: {DateTime.Now}");
        }
    }
}
