using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Optum.Fhir.Processors;

namespace FhirCronService
{
    public static class FhirHttpCronJob
    {
        [FunctionName("FhirHttpCronJob")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log?.LogInformation($"FhirCronService Timer trigger function started execution at: {DateTime.Now}");
            string strPracticeId = "195900";
            var isSuccess = ApppointmentProcessor.RetrieveAndSaveAppointments(strPracticeId, log);
            log?.LogInformation($"FhirCronService Timer trigger function finished execution at: {DateTime.Now}");

            return new OkObjectResult(isSuccess);
        }
    }
}
